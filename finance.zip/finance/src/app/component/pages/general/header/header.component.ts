import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';
import { PasswordMatchValidator, TermsValidator } from './validator';

import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators, } from '@angular/forms';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [TooltipModule, DialogModule, ButtonModule, InputTextModule, CommonModule, FormsModule, ReactiveFormsModule, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  visible = signal<boolean>(false);
  isSignInActive = signal<boolean>(true);
  showDialog() {
    this.visible.set(true);
    console.log(this.visible);
  }
  //signin form
  emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
  integerRegex = /^\s*[0-9]+\s*$/;

  signInform = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
    password: new FormControl('', [Validators.required, Validators.pattern(this.passwordRegex)]),
    confirmPassword: new FormControl('', Validators.required),
  })

  get controls() {
    return this.signInform.controls;
  }
  passwordFieldType = 'password';
  togglePasswordVisibility() {
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }
  signInUser() {

  }
  toggleView() {
    this.isSignInActive.update(value => !value); 
  }

  form = new FormGroup({
    organizationName: new FormControl('', Validators.required),
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
    password: new FormControl('', [Validators.required, Validators.pattern(this.passwordRegex)]),
    confirmPassword: new FormControl('', Validators.required),
    selectRoll: new FormControl('', Validators.required),
    phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(this.integerRegex)]),
    postCode: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(this.integerRegex)]),
    terms: new FormControl(false, Validators.requiredTrue),
  },
    { validators: [PasswordMatchValidator(), TermsValidator()] }
  );
  get signUpControl() {
    return this.form.controls;
  }
  onSubmitForm(event: Event) {
    event.preventDefault();
    if (this.form.valid) {
      alert('Form submitted successfully');
    } else {
      alert('Please insert values correctly');
    }
  }
}
