import { Routes } from '@angular/router';
export const routes: Routes = [
    // {
    //     path: '',
    //     pathMatch: 'full',
    //     title: 'Anwit-Finance'
    // },
    // {
    //     path: 'home',
    //     title: 'Anwit-Finance'
    // },
    // {
    //     path: 'signIn',
    //     title: 'signIn'
    // },
    // {
    //     path: 'dashboard',
    //     title: 'dashboard'
    // },
    // {
    //     path: 'policy',
    //     title: 'policy'
    // },
    // {
    //     path: 'customers',
    //     title: 'customers'
    // },
    // {
    //     path: 'records',
    //     title: 'records'
    // },
    // {
    //     path: 'members',
    //     title: 'members'
    // },
    //     {
    //         path: '**',
    //         component: NotFoundComponent,
    //     },
]
