import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./component/pages/general/header/header.component";
import { FooterComponent } from "./component/pages/general/footer/footer.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent,  CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'demo';
  sections = ['a', 'b', 'c', 'd', 'e', 'f'];

  // Initially, only 'a' is active
  activeSection: string = 'a'; // 'a' is active initially

  // Function to set the active section
  setActiveSection(section: string): void {
    this.activeSection = section;
    console.log('Clicked section:', section);
  }

  // Function to check if a section is active
  isActive(section: string): boolean {
    return this.activeSection === section;
  }

}

