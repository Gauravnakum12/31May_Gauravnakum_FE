import { Component, inject, OnInit } from '@angular/core';
import { NgClass, NgFor } from '@angular/common';
import { WalletService } from './wallet-data.service';
import { Transaction } from './transaction.model';

@Component({
  selector: 'app-wallet-table',
  templateUrl: './wallet-table.component.html',
  styleUrls: ['./wallet-table.component.css'],
  standalone: true,
  imports: [ NgFor,NgClass],
})
export class WalletTableComponent {

  private useWalletService = inject(WalletService)

  transactions: Array<Transaction> = this.useWalletService.transactionsSignal()

  expandedRow: number | null = null;

  isExpanded(index: number): boolean {
    return this.expandedRow === index;
  }

  toggleRow(index: number): void {
    this.expandedRow = (this.expandedRow === index ? null : index);
  }

}
