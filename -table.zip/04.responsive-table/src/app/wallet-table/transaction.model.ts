// transaction.model.ts
export interface TransactionItem {
  TransactionType:string
    hash?: string;
    withdrawalAddress?: string;
    feesPaid?: string;
  }
  
  export interface Transaction {
    type: string;
    amount: number;
    date: string;
    status: string;
    transactionItems: TransactionItem[];
  }
  