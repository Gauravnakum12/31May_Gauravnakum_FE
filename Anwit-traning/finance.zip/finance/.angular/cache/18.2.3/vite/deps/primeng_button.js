import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-LKXL7AYD.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-AI64BHRD.js";
import "./chunk-X7PCTTRX.js";
import "./chunk-PZ7RRS6P.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
