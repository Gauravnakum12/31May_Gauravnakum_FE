import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
  // https://media.istockphoto.com/id/989794366/it/vettoriale/tic-tac-toe-torniamo-al-background-scolastico-doodle-tic-tac-punta-gioco-penna-e-matita.jpg?s=170667a&w=0&k=20&c=20ILWxCTb8z-7cWO6Uv5kJyD6idCYOp-Xa7BRNb6FVk=
  // https://cdn.dribbble.com/users/1310166/screenshots/4239811/tictactoe-dribbble-small.jpg