import { Component, DoCheck, inject, OnChanges, signal } from '@angular/core';
import { GameService } from '../game.service';
import { NgFor, NgClass } from '@angular/common';
import { TicTacCellComponent } from './tic-tac-cell/tic-tac-cell.component';

@Component({
  selector: 'app-tic-tac-toe',
  templateUrl: './tic-tac-toe.component.html',
  styleUrls: ['./tic-tac-toe.component.css'],
  standalone: true,
  providers: [GameService],
  imports: [NgFor, NgClass, TicTacCellComponent]
})
export class TicTacToeComponent {

  winVertical: number[] | undefined;
  winHorizontal: number[] | undefined;
  winCross: number[] | undefined;

  private gameService = inject(GameService);
  gameData = this.gameService.board;
  myMove = (i: number) => {
    this.gameService.makeMove(i)
  }
  myMessage: string = this.gameService.message
  myResetFunction = this.gameService.resetGame()

  constructor() {
    this.winCombo = this.gameService.winNumberArr()

   
  }

  
}
