import { Component } from '@angular/core';
import { GameService } from '../game.service';
import { NgFor, NgClass } from '@angular/common'; // Import NgFor and NgClass

@Component({
  selector: 'app-tic-tac-toe',
  templateUrl: './tic-tac-toe.component.html',
  styleUrls: ['./tic-tac-toe.component.css'],
  standalone:true,
  providers: [GameService],
  imports: [NgFor,NgClass] // Add NgFor and NgClass to the imports array
})
export class TicTacToeComponent {
  constructor(public gameService: GameService) { }

  onCellClick(index: number) {
    this.gameService.makeMove(index);
  }

}
