import { Injectable, signal } from '@angular/core';

@Injectable()
export class GameService {
  board = signal<string[]>(['', '', '', '', '', '', '', '', '']);
  currentPlayer: string = 'X';
  winNumberArr = signal<any>([]);
  message = 'Your turn!';
  gameActive: boolean = true;

  winningCombinations: number[][] = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];
  makeMove(index: number): void {
    if (this.board()[index] === '' && this.gameActive) {
      //update in signal 
      this.board.update((value) => {
        value[index] = this.currentPlayer
        return value
      })
      this.checkWinner();
      if (this.gameActive) {
        this.switchPlayer();
        if (this.currentPlayer === 'O') {
          this.computerMove();
        }
      }
    }
  }

  switchPlayer(): void {
    this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
    this.message = this.currentPlayer === 'X' ? 'Your turn!' : 'Computer\'s turn...';
  }

  computerMove(): void {
    
    const emptyIndexes: number[] = [];
    for (let i = 0; i < this.board().length; i++) {
      if (this.board()[i] === '') {
        emptyIndexes.push(i);
      }
    }
    
    if (emptyIndexes.length > 0) {
      const randomIndex = emptyIndexes[Math.floor(Math.random() * emptyIndexes.length)];
      this.board.update((value) => {
        value[randomIndex] = 'O';
        return value
      })
      this.checkWinner();
      if (this.gameActive) {
        this.switchPlayer();
      }
    }
  }

  checkWinner(): void {
    for (let combo of this.winningCombinations) {
      const [a, b, c] = combo;
      if (this.board()[a] && this.board()[a] === this.board()[b] && this.board()[a] === this.board()[c]) {
        this.gameActive = false;
        this.message = `${this.board()[a]} wins!`;
        this.winNumberArr.set(combo)
        console.log(this.winNumberArr);
        // this.drawWinningLine(combo);
        // alert(`${this.board[a]} wins!`);
        return;
      }
    }

    if (!this.board().includes('')) {
      this.message = 'It\'s a draw!';
      this.gameActive = false;
      //   alert('It\'s a draw!');
    }
  }

  drawWinningLine(combo: number[]): void {
    // Add a class to highlight the winning cells
    for (let index of combo) {
      document.getElementById(`cell-${index}`)?.classList.add('winning-cell');
    }
  }

  resetGame(): void {
    this.board.set(['', '', '', '', '', '', '', '', '']);
    this.currentPlayer = 'X';
    this.message = 'Your turn!';
    this.gameActive = true;
    this.winNumberArr.set([]);
  }
}
