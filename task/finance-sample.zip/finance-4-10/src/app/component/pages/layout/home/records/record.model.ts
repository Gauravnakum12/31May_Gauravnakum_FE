import { GenericResponse } from '../../../../../shared/interfaces';
import { CustomerData } from '../customers/customer.model';
import { Policy } from '../policies/policy.model';

export type RecordResponse = GenericResponse<Record>;

export interface Record {
  recordId: string;
  recordNumber: string;
  createdAt: Date;
  policy_info: Policy;
  customer_info: CustomerData;
  isMarkable: false;
  records: RecordFiled[];
}

export interface RecordFiled {
  policyFieldId: string;
  record: string;
}

export interface SendTempRecord {
  customerId?: string,
  policyId?: string,
  recordData?: {
    records?: TempRecord[],
  },
  recordId?: string
}
export interface TempRecord {
  policyFieldId?: string,
  record?: string | undefined,
}
