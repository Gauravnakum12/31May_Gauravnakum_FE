export interface GenericResponse<T> {
  message: string;
  currentPage: number;
  totalRecord: number;
  totalPage: number;
  totalPages: number;
  data: T[];
}

export interface GenericPostResponse<T> {
  message: string;
  data: T;
}

export interface DeleteError {
  error: {
    message: string,
    timestamp: string,
    traceId: string
  }

}

export interface PostError {
  message: string,
  traceId: string,

}