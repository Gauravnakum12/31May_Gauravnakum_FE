import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-6JNPZ5CT.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-NEZ32UOM.js";
import "./chunk-3GXVZPYI.js";
import "./chunk-VZD2ANCY.js";
import "./chunk-2CVCC5YH.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
