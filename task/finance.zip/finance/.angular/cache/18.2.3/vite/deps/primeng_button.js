import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-P55F47NF.js";
import "./chunk-FIFGOI3N.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-HE5PWX4F.js";
import "./chunk-4XBA7G65.js";
import "./chunk-D3IQWCZR.js";
import "./chunk-PIQKY2LV.js";
import "./chunk-SZQPEDTI.js";
import "./chunk-Q3R3BXB2.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
