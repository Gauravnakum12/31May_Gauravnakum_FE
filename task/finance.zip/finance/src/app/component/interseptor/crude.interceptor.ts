import { HttpInterceptorFn } from '@angular/common/http';
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('financeToken');
  const organizationId = localStorage.getItem('id');
  if (token) {
    const clonedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        organizationId: `${organizationId}`
      }
    });
    return next(clonedReq);
  } else {
    return next(req);
  }
};
// organization_id
