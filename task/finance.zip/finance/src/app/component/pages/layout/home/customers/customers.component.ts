import { Component, inject, signal } from '@angular/core';
import { customerData, customerResponse } from '../../../../../finance.model';
import { CommonModule } from '@angular/common';
import { CustomersService } from '../../../../services/api/customers.service';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [TableModule, CommonModule, ButtonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent {
  private CustomerDataService = inject(CustomersService);
  customers: customerData[] = [];
  totalCustomerRecord: number = 0;
  row: number = 10;
  totalPage: number = 0;

  loadCustomerLazy(event: TableLazyLoadEvent) {
    this.CustomerDataService.getCustomerData(event.first || 10).subscribe({
      next: (response: customerResponse) => {
        this.customers = response.data;
        this.totalCustomerRecord = response.totalRecord;
        this.totalPage = response.totalPage;
        console.log(event);
        // console.log(response);
      }
    });
  }
  
  // visible = signal(false);
  // userForm: FormGroup = new FormGroup({
  //   id: new FormControl<number | null>(null),
  //   avatar: new FormControl('', Validators.required),
  //   first_name: new FormControl('', Validators.required),
  //   last_name: new FormControl('', Validators.required),
  //   email: new FormControl('', [Validators.required, Validators.email]),
  // });


  // get controls() {
  //   return this.userForm.controls;
  // }

  // saveUser(): void {
  //   if (this.userForm.valid) {
  //     const tempData: User = this.userForm.value;
  //     if (tempData.id) {
  //       // Update existing user
  //       this.userDataService.updateUser(tempData).subscribe({
  //         next: () => {
  //           // recall current page of user list
  //           this.visible.set(false);
  //         },
  //         error: (error: Error) => this.err.set(error.message),
  //       });
  //     } else {
  //       // Create new user
  //       const newUser = { ...tempData, id: this.getNewUserId() };
  //       this.userDataService.postNewUserData(newUser).subscribe({
  //         next: (response) => {
  //           console.log(response);
  //           this.visible.set(false);
  //         },
  //         error: (error: Error) => this.err.set(error.message),
  //       });
  //     }
  //     this.imgSrc = tempData.avatar || 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
  //   }
  // }
}
