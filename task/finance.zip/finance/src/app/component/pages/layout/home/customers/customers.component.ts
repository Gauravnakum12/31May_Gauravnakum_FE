import { Component, inject, OnInit } from '@angular/core';
import { customerData } from '../../../../../finance.model';
import { CustomerDataService } from '../../../../services/api/customer-data.service';
import { TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [TableModule, CommonModule],
  templateUrl: './customers.component.html',
  styleUrl: './customers.component.scss'
})
export class CustomersComponent implements OnInit {
  private CustomerDataService = inject(CustomerDataService);
  customers: customerData[] = [];
  ngOnInit() {
    this.CustomerDataService.getCustomerData().subscribe({
      next: (response: any) => {
        this.customers = response;
        console.log(response);

      }
    })
  }
}
