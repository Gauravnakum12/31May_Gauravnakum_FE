import { Component } from '@angular/core';
import { SidebarService } from '../../../../services/sidebarService';

import { MenuItem } from 'primeng/api';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
@Component({
  selector: 'app-dashboard-header',
  standalone: true,
  imports: [MenuModule, ButtonModule],
  templateUrl: './dashboard-header.component.html',
  styleUrl: './dashboard-header.component.scss'
})
export class DashboardHeaderComponent {
  constructor(private sidebarService: SidebarService) { }
  items: MenuItem[] | undefined;

  ngOnInit() {
    this.items = [
      {
        label: 'Options',
        items: [
          {
            icon: 'pi  pi-sign-out',
            label: 'log-out',
          }
        ]
      }
    ];
  }

  toggleSidebar() {
    this.sidebarService.toggleSidebar();
  }
}
