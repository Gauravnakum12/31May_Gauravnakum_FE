import { Component, signal } from '@angular/core';
import { SidebarService } from '../../../../services/sidebarService';
// import { }
import { MenuItem } from 'primeng/api';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { AuthService } from '../../../../services/login.service';
import { fetchedUser } from '../../../../../finance.model';
@Component({
  selector: 'app-dashboard-header',
  standalone: true,
  imports: [MenuModule, ButtonModule],
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss']
})
export class DashboardHeaderComponent {
  constructor(private sidebarService: SidebarService, private authService: AuthService) { }

  organiZationInfo = this.authService.organizationInfo();
  UserInfo = this.authService.signInInfo();

  items: MenuItem[] | undefined;

  // OrganiZationName: string | undefined = this.organiZationInfo[0].name;
  // username :string = this.UserInfo().firstName

  ngOnInit() {
    // this.OrganiZationName = this.organiZationInfo[0].name;
    // console.log('dashboard  called');
    console.log(`log from dashboard ${this.organiZationInfo}`)
    console.log(`log from dashboard ${this.UserInfo}`);
    // console.log(`log from dashboard ${this.UserInfo().firstName}`);

    this.items = [
      {
        label: 'Options',
        items: [
          {
            icon: 'pi pi-sign-out',
            label: 'log-out',
          },
          {
            icon: 'pi pi-sign-out',
            label: 'log-out',
            // click: ,
          }
        ]
      }
    ];
  }
  logOutFunction() {
    localStorage.clear();
  }
  toggleSidebar() {
    this.sidebarService.toggleSidebar();
  }
}
