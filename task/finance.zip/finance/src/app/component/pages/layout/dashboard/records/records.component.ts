import { Component } from '@angular/core';

@Component({
  selector: 'app-records',
  standalone: true,
  imports: [],
  templateUrl: './records.component.html',
  styleUrl: './records.component.scss'
})
export class RecordsComponent {

}
