import { Message } from 'primeng/api';

export interface topPolicy {
    Message: string,
    totalPages: number,
    totalRecord: number,
    currentPage: number
    data: topPolicyData[]
}
export interface topPolicyData {
    subscribedCount: number,
    name: string
}

export interface MostValuableCustomer {
    Message: string,
    totalPages: number,
    totalRecord: number,
    currentPage: number
    data: MostValuableCustomerData[]
}

export interface MostValuableCustomerData {
    customerName: string,
    email: string,
    phoneNumber: number,
    total: number
    policies: MostValuableCustomerPolicies[]
}
export interface MostValuableCustomerPolicies {
    name: string,
    count: number
}

export interface ExpirationPolicy {
    message: string,
    totalPages: number,
    limit: number,
    currentPage: number,
    data: ExpirationPolicyData[]
}
export interface ExpirationPolicyData {
    policyName: string,
    customerName: string,
    expireDate: Date
}