import { Component } from '@angular/core';

@Component({
  selector: 'app-custommer',
  standalone: true,
  imports: [],
  templateUrl: './custommer.component.html',
  styleUrl: './custommer.component.scss'
})
export class CustommerComponent {

}
