
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';
import { PasswordMatchValidator, TermsValidator } from '../../../services/auth/validator';
import { HttpClient, } from '@angular/common/http';

import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators, } from '@angular/forms';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [TooltipModule, DialogModule, ButtonModule, InputTextModule, CommonModule, FormsModule, ReactiveFormsModule, RouterLink, RouterLinkActive,],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  constructor(private http: HttpClient) { }

  visible = signal<boolean>(false);
  isSignInActive = signal<boolean>(true);
  showDialog() {
    this.visible.set(true);
  }
  //signin form
  emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
  integerRegex = /^\s*[0-9]+\s*$/;

  signInform = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
    password: new FormControl('', [Validators.required, Validators.pattern(this.passwordRegex)]),
  })

  get controls() {
    return this.signInform.controls;
  }
  passwordFieldType = 'password';
  togglePasswordVisibility() {
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }
  signInUser(event: Event) {
    event.preventDefault();
    if (this.signInform.valid) {
      this.http.post("https://ctwvk1rh-3001.inc1.devtunnels.ms/auth/login", this.signInform.value)
        .subscribe({
          next: response => {
            console.log('Sign In :', response);
          },
          error: error => {
            console.error('Sign In Error:', error);
          }
        });
    }
  }
  toggleView() {
    this.isSignInActive.update(value => !value);
  }

  form = new FormGroup({
    organizationName: new FormControl('', Validators.required),
    organizationLocation: new FormControl('', Validators.required),
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
    password: new FormControl('', [Validators.required, Validators.pattern(this.passwordRegex)]),
    confirmPassword: new FormControl('', Validators.required),
    phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(this.integerRegex)]),
    terms: new FormControl(false, Validators.requiredTrue),
  },
    { validators: [PasswordMatchValidator(), TermsValidator()] }
  );
  get signUpControl() {
    return this.form.controls;
  }
  signupUser(event: Event) {
    event.preventDefault();
    if (this.form.valid) {
      const formValues = this.form.value;
      this.http.post("https://ctwvk1rh-3001.inc1.devtunnels.ms/auth/signup", formValues)
        .subscribe({
          next: response => {
            console.log(formValues ,"sent");
          },
          error: error => {
            console.error('SignUpError:', error);
          }
        });
    }
  }
}
