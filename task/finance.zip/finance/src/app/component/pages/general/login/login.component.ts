import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../services/login.service';
import { PasswordMatchValidator, TermsValidator } from '../../../services/auth/validator';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators, } from '@angular/forms';
@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    standalone: true,
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink, RouterLinkActive,],
})
export class LoginComponent {

    visible = signal<boolean>(false);
    isSignInActive = signal<boolean>(true);
    showDialog() {
        this.visible.set(true);
    }
    signInform = new FormGroup({
        email: new FormControl('', [Validators.required, Validators.email]),
        password: new FormControl('', [Validators.required]),
    });

    form = new FormGroup({
        organizationName: new FormControl('', Validators.required),
        organizationLocation: new FormControl('', Validators.required),
        firstName: new FormControl('', Validators.required),
        lastName: new FormControl('', Validators.required),
        email: new FormControl('', [Validators.required, Validators.email]),
        password: new FormControl('', [Validators.required]),
        confirmPassword: new FormControl('', Validators.required),
        phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
        terms: new FormControl(false, Validators.requiredTrue),
    }, { validators: [PasswordMatchValidator(), TermsValidator()] });

    constructor(private authService: AuthService, private router: Router) { }
    passwordFieldType = 'password';
    togglePasswordVisibility() {
        this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
    }

    signInUser(event: Event) {
        event.preventDefault();
        if (this.signInform.valid) {
            const credentials = {
                email: this.signInform.value.email ?? '',
                password: this.signInform.value.password ?? ''
            };
            this.authService.signIn(credentials).subscribe({
                next: response => {
                    console.log(response);
                    this.router.navigate(['/home']);
                },
                error: error => {
                    console.error('Sign In Error:', error);
                }
            });
        }
    }
    get controls() {
        return this.signInform.controls;
    }

    toggleView() {
        this.isSignInActive.update(value => !value);
    }

    get signUpControl() {
        return this.form.controls;
    }

    signupUser(event: Event) {
        event.preventDefault();
        if (this.form.valid) {
            const userData = {
                organizationName: this.form.value.organizationName,
                organizationLocation: this.form.value.organizationLocation,
                firstName: this.form.value.firstName,
                lastName: this.form.value.lastName,
                email: this.form.value.email,
                password: this.form.value.password,
                confirmPassword: this.form.value.confirmPassword,
                phoneNumber: this.form.value.phoneNumber,
                terms: this.form.value.terms ?? false,
            };
            this.authService.signUp(userData).subscribe({
                next: response => {
                    console.log(response);
                    this.router.navigate(['/login']);
                },
                error: error => {
                    console.error('SignUpError:', error);
                }
            });
        }
    }
    logoutOwner() {
        this.authService.logout();
        this.router.navigate(['/lo']);
    }
}

