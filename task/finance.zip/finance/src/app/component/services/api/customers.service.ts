import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { customerData, customerResponse } from '../../../finance.model';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {

  constructor(private http: HttpClient) { }
  getCustomerData(skip: number): Observable<customerResponse> {
    return this.http.get<customerResponse>(`https://ctwvk1rh-3001.inc1.devtunnels.ms/customer/list?limit=`);
  }
}

