import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { customerData } from '../../../finance.model';


@Injectable({
  providedIn: 'root'
})
export class CustomerDataService {
  constructor(private http: HttpClient) { }

  getCustomerData() {
    return this.http.get('https://ctwvk1rh-3001.inc1.devtunnels.ms/customer/list');
  }
}
