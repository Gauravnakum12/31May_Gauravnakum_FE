import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn = signal<boolean>(false);
  private apiUrl = 'https://ctwvk1rh-3001.inc1.devtunnels.ms/auth';

  constructor(private http: HttpClient) { }

  signIn(credentials: { email: string, password: string }) {
    return this.http.post(`${this.apiUrl}/login`, credentials)
      .pipe(tap((response: any) => {
        if (response.accessToken) {
          localStorage.setItem('financeToken', response.accessToken);
          this.isLoggedIn.update(() => true)
        }
      })
      );
  }

  signUp(userData: any) {
    return this.http.post(`${this.apiUrl}/signup`, userData)
      .pipe(tap((response: any) => {
        if (response.organization._id) {
          localStorage.setItem('id', response.organization._id)
        }
      }))
  }

  logout() {
    this.isLoggedIn.update(() => false)
    localStorage.removeItem('financeToken');
  }
}



