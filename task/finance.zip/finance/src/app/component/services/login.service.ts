// import { Injectable, signal } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { tap } from 'rxjs/operators';
// import { LoginResponse } from '../../finance.model';
// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   isLoggedIn = signal<boolean>(false);
//   private apiUrl = 'https://ctwvk1rh-3001.inc1.devtunnels.ms/auth';

//   constructor(private http: HttpClient) { }

//   signIn(credentials: { email: string, password: string }) {
//     return this.http.post(`${this.apiUrl}/login`, credentials)
//       .pipe(tap((response: LoginResponse) => {
//         if (response.accessToken) {
//           localStorage.setItem('financeToken', response.accessToken);
//           this.isLoggedIn.update(() => true)
//         }
//       })
//       );
//   }
//   signUp(userData: any) {
//     return this.http.post(`${this.apiUrl}/signup`, userData)
//       .pipe(tap((response: any) => {
//         if (response.organization._id) {
//           localStorage.setItem('id', response.organization._id)
//         }
//       }))
//   }

//   logout() {
//     this.isLoggedIn.update(() => false)
//     localStorage.removeItem('financeToken');
//   }
// }



import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoginResponse, SignUpResponse } from '../../finance.model';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  isLoggedIn = signal<boolean>(false);
  private apiUrl = 'https://ctwvk1rh-3001.inc1.devtunnels.ms/auth';

  constructor(private http: HttpClient) {}

  // Login method with strict typing for the response
  signIn(credentials: { email: string; password: string }): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(tap((response: LoginResponse) => {
          if (response.accessToken) {
            localStorage.setItem('financeToken', response.accessToken);
            this.isLoggedIn.update(() => true);
          }
        })
      );
  }

  // Sign-up method with strict typing for the response
  signUp(userData: SignUpResponse): Observable<SignUpResponse> {
    return this.http.post<SignUpResponse>(`${this.apiUrl}/signup`, userData)
      .pipe(
        tap((response: SignUpResponse) => {
          if (response.organizationName && response.organizationLocation) {
            localStorage.setItem('id', response.organizationName);
          }
        })
      );
  }

  logout() {
    this.isLoggedIn.update(() => false);
    localStorage.removeItem('financeToken');
  }
}
