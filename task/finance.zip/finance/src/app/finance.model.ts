
export interface fetchedUser {
    _id: number;
    createdAt: Date;
    email: string;
    firstName: string
    lastName: string
    organizationLocation: string
    organizationName: string
    phoneNumber: number;
    registerCode: number;
    resetToken: null
    updatedAt: Date;
    verificationCode: null
    verificationCodeExpiry: null
    verified: boolean;
}
export interface LoginResponse {
    accessToken: string;
    message: string;
    user: fetchedUser[]
}
export interface SignUpResponse {
    organizationLocation?: string;
    organizationName: string;
    email: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    terms: boolean;
    password: string;
    confirmPassword: string;
}

export interface customerData {
    email: string;
    name: string;
    phoneNumber: number;
    birthDate: Date;
}