export interface signUpResponse {

}

export interface loginResponse {

}