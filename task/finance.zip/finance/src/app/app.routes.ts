import { Routes } from '@angular/router';
import { LoginComponent } from './component/pages/general/login/login.component';
export const routes: Routes = [
    {
        path:'',
        title: 'Anwit-home',
        redirectTo: 'login',
        pathMatch: 'full',
    },
    {
        path: 'login',
        title: 'login',
        component: LoginComponent,
    },
]
