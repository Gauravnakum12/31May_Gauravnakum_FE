import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-UALZ67EQ.js";
import "./chunk-EGQO4OIA.js";
import "./chunk-YP33PSG5.js";
import "./chunk-BJ3RULPZ.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
