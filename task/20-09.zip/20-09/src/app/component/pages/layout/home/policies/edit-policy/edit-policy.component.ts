import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { PolicesService } from '../../../../../services/api/polices.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';

import { RippleModule } from 'primeng/ripple';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
// import { policeResponseData, PolicyField } from '../../../../../model/policy.model';
@Component({
  selector: 'app-edit-policy',
  standalone: true,
  imports: [ButtonModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, RippleModule, ToastModule],
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class EditPolicyComponent implements OnInit {
  policy: any = '';
  policyIdFromRoute: any = '';
  cardData: any = [];
  policyName: string = '';
  policyDescription: string = '';
  policyExpirable: boolean = false;
  constructor(
    private policyDataService: PolicesService,
    private activeRoute: ActivatedRoute,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private router: Router
  ) { }


  ngOnInit(): void {
    this.policyIdFromRoute = this.activeRoute.snapshot.paramMap.get('id');
    this.getPolicy();

  }

  getPolicy() {
    this.policyDataService.getSinglePolicy(this.policyIdFromRoute).subscribe({
      next: (response: any) => {
        this.policy = response.data;
        this.policyDescription = this.policy.description;
        this.policyName = this.policy.name;
        this.policyExpirable = this.policy.isExpirable;

        let temFelids = this.policy.policyFields.map((element: any) => {
          if (element.dropdown) {
            element.options = element.dropdown.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          else if (element.radio) {
            element.options = element.radio.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          return { ...element };
        })
        this.cardData.push(...temFelids);
        console.log()
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }

  updatePolicy() {
    let updatedData = {
      name: this.policyName,
      description: this.policyDescription,
      isExpirable: this.policyExpirable
    };

    this.policyDataService.updatePolicy(this.policyIdFromRoute, updatedData).subscribe({
      next: (response) => {
        console.log(response);
        this.router.navigate(['/home/policy']);
      },
      error: (error: any) => {
        console.error('Error updating policy:', error);
        // Optionally show an error message to the user
      }
    });
  }




  // --------------------------------------------temple-form--------------------------------------
  addCard() {
    const newField: any = {
      label: '',
      type: 'text',
      name: '',
      description: '',
      instruction_hints: '',
      isExpirable: false,
      text: {
        value: '',
        placeholder: '',
      },
      options: [{
        value: ''
      }]
    }

    this.policyDataService.postInputField(this.policyIdFromRoute, newField).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response.data);
        // this.messageService.add({ severity: 'success', summary: 'Success', detail: response.message });   //ToastModule 
      },
      error: (error: any) => { console.error(error) }
    })
  }
  updateField(card: any) {

    console.log(card);

    let tempAry: any = []

    if (card.options) {
      tempAry = card.options.map((data: any) => data.value)
    }

    const updatedField: any = {
      type: card.type,
      label: card.label,
      isExpirable: false,
      instruction_hints: card.instruction_hints,
      [card.type]: {
        values: tempAry,
        placeholder: card.placeholder || '',
      }
    };

    const passData = {
      formData: updatedField,
      cardId: card._id,
      policyId: this.policyIdFromRoute,
    };

    this.policyDataService.postUpdatedInputField(passData).subscribe({
      next: (response: any) => {
        console.log(response);

        this.messageService.add({ severity: 'success', summary: 'Success', life: 2000, detail: response.message });
      },
      error: (error: any) => { console.error(error); }
    });

  }

  deleteField(card: any, ind: number) {
    // console.log(event);

    // this.confirmationService.confirm({
    //   target: event.target as EventTarget,
    //   message: 'Are you sure that you want to proceed?',
    //   header: 'Confirmation',
    //   icon: 'pi pi-exclamation-triangle',
    //   acceptIcon: "none",
    //   rejectIcon: "none",
    //   rejectButtonStyleClass: "p-button-text",
    //   accept: () => {
    //     this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'message' });

    const passData = {
      cardId: card._id,
      policyId: this.policyIdFromRoute,
    }
    this.policyDataService.deleteInputField(passData).subscribe({
      next: (response: any) => {
        this.cardData.splice(ind, 1);
        console.log(response);

      },
      error: (error: any) => { console.error(error); }
    });

    //   }
    // })

  }

  // ------------------felid-options--------------------
  addOption(card: any) {
    if (!card.options) {
      card['options'] = [];
    }
    card.options.push({
      value: ''
    })
  }
  removeOption(card: any, index: number) {
    card.options.splice(index, 1)
  }

}
