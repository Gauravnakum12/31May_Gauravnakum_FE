import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';

import { DropdownFilterOptions } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { SelectItem } from 'primeng/api';
import { CustomersService } from '../../../../services/api/customers.service';
import { PolicesService } from '../../../../services/api/polices.service';
import { customerData, customerResponse } from '../../../../../finance.model';
import { FloatLabelModule } from 'primeng/floatlabel';
@Component({
  selector: 'app-records',
  standalone: true,
  imports: [BreadcrumbModule, RouterModule, CommonModule, ButtonModule, DialogModule, FormsModule, DropdownModule, FloatLabelModule],
  templateUrl: './records.component.html',
  styleUrl: './records.component.scss'
})
export class RecordsComponent implements OnInit {
  items: MenuItem[] | undefined;
  ngOnInit() {
    this.items = [{ icon: 'pi pi-home', route: '/home' }, { label: 'record', route: '/home/record' },];
    this.loadCustomerData();
    this.getPolicyNameList();
    console.log(this.selectedCustomers);
  }
  visible: boolean = true;
  recordPopupOpen() {
    this.visible = true;
  }
  filterCustomers: string | undefined = '';
  selectedCustomers: any;
  customers: any = [];

  filterPolicy: string | undefined = '';
  selectedPolicy: any;
  polices: any = [];

  policyFormData: any;
  cardData: any = [];
  buttonVisible: boolean = false;

  constructor(private CustomerDataService: CustomersService, private policyService: PolicesService) {
  }

  private loadCustomerData() {
    this.CustomerDataService.allCustomer().subscribe({
      next: (response: any) => {
        this.customers = response.data
      },
      error: (error: Error) => console.error(error),
    });
  }

  getPolicyNameList() {
    this.policyService.getPolicyNameList().subscribe({
      next: (response: any) => {
        console.log(response.data);
        this.polices = (response.data);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }
  callCustomer() {

  }
  getPolicy() {
 
    // this.cardData = '';
    const singlePolicyId = this.selectedPolicy._id
    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: any) => {
        this.policyFormData = response.data;
        console.log(this.policyFormData);
        let temFelids = this.policyFormData.policyFields.map((element: any) => {
          if (element.dropdown) {
            element.options = element.dropdown.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          else if (element.radio) {
            element.options = element.radio.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          return { ...element };
        })
        // this.cardData = '';
        this.cardData.push(...temFelids);
        console.log()
      },
      error: (error: any) => {
        console.error(error);
      }
    });
    this.buttonVisible = true;
  }

}
