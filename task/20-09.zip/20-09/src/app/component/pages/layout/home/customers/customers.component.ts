import { Component, inject, OnInit, signal } from '@angular/core';
import { customerData, customerResponse } from '../../../../../finance.model';
import { CommonModule, DatePipe } from '@angular/common';
import { CustomersService } from '../../../../services/api/customers.service';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, } from 'primeng/api';
import { MessagesModule } from 'primeng/messages';

import { MessageService, Message } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [TableModule,ConfirmDialogModule, CommonModule, ButtonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, ToastModule, RippleModule],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
  providers: [ConfirmationService, MessageService]
})
export class CustomersComponent {

  constructor(private confirmationService: ConfirmationService, private messageService: MessageService) { }

  visible = signal(false);
  private CustomerDataService = inject(CustomersService);
  customers: customerData[] = [];

  totalCustomerRecord: number = 0;
  totalPage: number = 0;
  currentPage: number = 1;
  limit: number = 10;

  messages: Message[] = [];

  customerForm: FormGroup = new FormGroup({
    _id: new FormControl(''), // during edits
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    birthDate: new FormControl('', Validators.required),
  });

  get controls() {
    return this.customerForm.controls;
  }
  loadCustomerLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.loadCustomerData();
  }


  openNewUserDialog() {
    this.visible.set(true);
    this.customerForm.reset();
  }
  private loadCustomerData() {
    this.CustomerDataService.getCustomerData(this.currentPage, this.limit).subscribe({
      next: (response: customerResponse) => {
        // console.log(response.data);
        this.customers = response.data;
        this.totalCustomerRecord = response.totalRecord;
        this.totalPage = response.totalPage;
      },
      error: (error: Error) => console.error(error),
    });
  }

  editCustomer(customer: customerData) {
    this.visible.set(true);
    this.customerForm.setValue({
      _id: customer._id,
      name: customer.name,
      email: customer.email,
      phoneNumber: customer.phoneNumber,
      birthDate: customer.birthDate ? new Date(customer.birthDate).toLocaleDateString('en-CA') : '',
    });
  }

  saveCustomer(): void {
    if (this.customerForm.valid) {
      const tempData: customerData = this.customerForm.value;
      if (tempData._id) {
        // Update existing user
        this.CustomerDataService.UpdateCustomer(tempData).subscribe({
          next: () => {
            this.visible.set(false);
            this.loadCustomerData();
          },
          error: (error: any) => {
            console.error(error)
            this.messages = [{ severity: 'error', summary: 'Delete Error:', detail: error.error.message }]
          }
        });
      } else {
        // Create new user
        this.CustomerDataService.postNewCustomer(tempData).subscribe({
          next: (response) => {
            this.visible.set(false);
            this.loadCustomerData();
          },
          error: (error: any) => {
            console.log(error),
              this.messages = [{ severity: 'error', summary: 'Delete Error:', detail: error.error.message,life:3000}]
          }
        });
      }
    }
  }

  // deleteCustomer(customerId: string) {
  //   this.CustomerDataService.deleteCustomer(customerId).subscribe({
  //     next: () => {
  //       this.loadCustomerData();
  //     },
  //     error: (error: any) =>
  //       // console.log(error)
  //       this.messages = [{ severity: 'error', summary: 'Delete Error:', detail: error.error.message }]
  //   });
  // }

  deleteCustomerConformation( customerId: string) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.CustomerDataService.deleteCustomer(customerId).subscribe({
          next: () => {
            this.loadCustomerData();
          },
          error: (error: any) =>
            this.messages = [{ severity: 'error', summary: 'Delete Error:', detail: error.error.message }]
        });

        this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'customer deleted' });
      },
    });
  }
}



