import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { policeCreationData, policeResponse } from '../../../../../finance.model';
import { PolicesService } from '../../../../services/api/polices.service';
import { DropdownModule } from 'primeng/dropdown';
import { Router } from '@angular/router';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { Message, ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [RippleModule, TableModule, ButtonModule, DropdownModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, Button, ConfirmDialogModule, ToastModule,],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class PoliciesComponent implements OnInit {
  constructor(
    private router: Router,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,

  ) { }

  ngOnInit(): void {
    this.getPolicy();
  }

  private policyService = inject(PolicesService);
  visible = signal(false);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyData = signal<policeResponse | null>(null);
  policyName: string = '';
  policyId: string = '';

  policyDataFetched = signal<[]>([]);
  cardData: any = [];
  optionData: string[] = [];

  // -------table----
  totalPage: number = 0;
  currentPage: number = 1;
  limit: number = 10;
  totalPoliciesRecord: number = 0;
  // messages: any = [];

  // ------------------------------- get policy -------------------------------------//
  loadPolicyLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.getPolicy();
  }

  getPolicy() {
    this.policyService.getPolicy(this.currentPage, this.limit).subscribe({
      next: (response: any) => {
        // console.log(response.data);
        this.policyDataFetched.set(response.data);
        this.totalPoliciesRecord = response.totalRecord;
        this.totalPage = response.totalPage;
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }


  editPolicy(policy: any) {
    const policyId = policy._id
    this.router.navigate([`/home/policy/${policyId}`])
  }

  deletePolicyConformation(policy: any) {
    console.log(policy)
    const policyId = policy._id
    this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.policyService.deletePolicy(policyId).subscribe({
          next: (response: any) => {
            console.log(response);
          },
          error: (error: any) => {
            console.error(error);
          }
        });

        this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'Policy deleted' });
      }
    });
  }


  // ------------------------------card---------------------------------------

  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }

  // -----------------------------------------------poly-creation---------------------------------
  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [Validators.required, Validators.minLength(10)]),
    expirable: new FormControl(false),
  });
  savepolicies() {
    const sendPolicy: policeCreationData = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    }
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: policeResponse) => {
        this.policyData.set(response);
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName = response.data.name;
        this.policyId = response.data._id;
        console.log(response.data);
        this.policesForm.reset();
        this.router.navigate([`/home/policy/${this.policyId}`])
      },
      error: (error: any) => { console.error(error) }
    });
  }

  // deleteConformation
}



