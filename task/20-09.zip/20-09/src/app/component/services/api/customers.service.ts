import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { customerData, customerResponse } from '../../../finance.model';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {

  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/customer';

  constructor(private http: HttpClient) { }

  allCustomer(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  getCustomerData(page: number, limit: number): Observable<customerResponse> {
    const url = `${this.apiUrl}/list/?page=${page}&limit=${limit}`;
    return this.http.get<customerResponse>(url);
  }

  postNewCustomer(customer: customerData): Observable<customerData> {
    return this.http.post<customerData>(this.apiUrl, customer);
  }

  UpdateCustomer(customer: customerData): Observable<customerData> {
    return this.http.put<customerData>(`${this.apiUrl}/${customer._id}`, customer);
  }

  deleteCustomer(customerId: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${customerId}`);
  }
}
