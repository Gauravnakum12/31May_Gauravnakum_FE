import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-MZVAB33V.js";
import "./chunk-N2TTVKKL.js";
import "./chunk-4XBA7G65.js";
import "./chunk-HE5PWX4F.js";
import "./chunk-D3IQWCZR.js";
import "./chunk-SZQPEDTI.js";
import "./chunk-PIQKY2LV.js";
import "./chunk-Q3R3BXB2.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
