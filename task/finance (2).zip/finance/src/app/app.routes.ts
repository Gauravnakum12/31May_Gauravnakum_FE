import { Routes } from '@angular/router';
import { LoginComponent } from './component/pages/general/login/login.component';
import { DashboardComponent } from './component/pages/layout/home/dashboard.component';
import { CustomersComponent } from './component/pages/layout/home/customers/customers.component';
import { NotfoundComponent } from './component/pages/general/notfound/notfound.component';
import { authGuard } from './component/services/auth/guard/auth.guard';
export const routes: Routes = [
    {
        path: '',
        title: 'login',
        redirectTo: 'login',
        pathMatch: 'full',
    },
    {
        path: 'login',
        title: 'login',
        component: LoginComponent,
    },
    {
        path: 'home',
        title: 'Anwit-Finance',
        component: DashboardComponent,
        // canActivate:[authGuard],
        children: [
            {
                path: 'customer',
                component: CustomersComponent,
            },
        ]
    },
    {
        path: '**',
        component: NotfoundComponent,
    },

    // {
    //     path:'',
    //     title:'Admin-software',
    //     canActivate:[authGuard],
    // }
]

