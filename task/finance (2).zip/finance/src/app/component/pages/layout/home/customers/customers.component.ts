import { Component, inject, OnInit, signal } from '@angular/core';
import { customerData, customerResponse } from '../../../../../finance.model';
import { CommonModule } from '@angular/common';
import { CustomersService } from '../../../../services/api/customers.service';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [TableModule, CommonModule, ButtonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent implements OnInit{
  private CustomerDataService = inject(CustomersService);
  customers: customerData[] = [];
  totalCustomerRecord: number = 0;
  row: number = 10;
  totalPage: number = 0;
  currentPage: number = 1;

  loadCustomerLazy(event: TableLazyLoadEvent) {
    this.CustomerDataService.getCustomerData(event.first || 10).subscribe({
      next: (response: customerResponse) => {
        this.customers = response.data;
        this.totalCustomerRecord = response.totalRecord;
        this.totalPage = response.totalPage;
        console.log(event);
        // console.log(response);
      }
    });
  }
ngOnInit(){
  this.loadCustomerData();
}
  loadCustomerData(){
    this.CustomerDataService.getCustomerData(this.currentPage).subscribe({
      next: (response: customerResponse) => {
        this.customers = response.data;
      },
      error: (error: Error) => {
        // this.err.set(error.message);
      },
    });
  }
  
  visible = signal(true);
  customerForm: FormGroup = new FormGroup({
  name: new FormControl('', Validators.required),
  email: new FormControl('', [Validators.required, Validators.email]),
  phoneNumber: new FormControl(',',[Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
  birthDate: new FormControl('', Validators.required),
  });


  get controls() {
    return this.customerForm.controls;
  }

  openNewUserDialog() {
    this.visible.set(true);
    this.customerForm.reset();
  }

  editUser(customer: customerData){
    this.visible.set(true);
    this.customerForm.setValue(customer); 
  }

  saveUser(): void {
      if (this.customerForm.valid) {
        const tempData: customerData = this.customerForm.value;
        if (tempData._id) {
          // Update existing user
          this.CustomerDataService.UpdateCustomer(tempData).subscribe({
            next: () => {
              this.visible.set(false);
            },
            // error: (error: Error) => this.err.set(error.message),
          });
        } else {
          // Create new user
          const newUser = { ...tempData, id: 1 };
          this.CustomerDataService.postNewCustomer(newUser).subscribe({
            next: (response) => {
              console.log(response);
              this.visible.set(false);
            },
            // error: (error: Error) => this.err.set(error.message),
          });
        }
      }
    }
    deleteUser(customerId: number): void {
      this.CustomerDataService.deleteCustomer(customerId).subscribe({
        next: (response) => {
          console.log(response);
        },
        // error: (error: Error) => this.err.set(error.message),
      });
    }
 
    // goToPage(page: number) {
    //   if (page < 1 || page > this.totalPages) return;
    //   this.router.navigate([], {
    //     relativeTo: this.route,
    //     queryParams: { page: page },
    //   });
    // }
  
    // pageChange(event: { first: number; rows: number; }) {
    //   this.first = event.first;
    //   this.rows = event.rows;
    // }
  
    // calculatePages() {
    //   for (let i = 1; i <= this.totalPages; i++) {
    //     this.pages.push(i);
    //   }
    // }

}
