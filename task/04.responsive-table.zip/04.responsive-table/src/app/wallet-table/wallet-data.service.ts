import { Injectable } from '@angular/core';
import { signal } from '@angular/core';
import { Transaction } from './transaction.model';

@Injectable({
  providedIn: 'root',
})
export class WalletService {
  private staticData: Transaction[] = [
    {
      "type": "Deposit",
      "amount": 100,
      "date": "2024-08-01 1:00",
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Deposit",
      "amount": 200,
      "date": "2024-08-04 3:30",
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
          "withdrawalAddress": "B-509,Decora 9Square Nana Mava Road, Rajkot 360003, Gujarat, India.",
        }

      ]
    },
    {
      "type": "Transfer",
      "amount": 300,
      "date": "2024-08-06 5:30",
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": " Nesciunt molestiae totam similique tenetur eaque fugit? Illum, in quisquam.",
          "withdrawalAddress": "Reliance Mega Mall, 150 Feet Ring Road, Rajkot - 360005 (Opposite Big Bazar, Near Nana Mauva Circle)",
        }
      ]
    },
    {
      "type": "Transfer",
      "amount": 75,
      "date": "2024-08-03 4:30",
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Withdrawal",
      "amount": 50,
      "date": "2024-08-02 6:30",
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Deposit",
      "amount": 400,
      "date": "2024-08-07 3:30",
      "status": "Failed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Withdrawal",
      "amount": 250,
      "date": "2024-08-08 4:30",
      "status": "Failed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Transfer",
      "amount": 125,
      "date": "2024-08-09 5:30",
      "status": "Failed",
      "transactionItems": []
    },
    {
      "type": "Transfer",
      "amount": 300,
      "date": "2024-08-06 6:30",
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "4",
          "hash": "Eos harum ex natus, assumenda placeat a doloribus minus id ducimus! Similique.",
          "withdrawalAddress": " Crystal Mall Rajkot, Kalavad Rd, Opposite Rani Tower, Ghanshyam Nagar - 2 East, Rajkot, Gujarat 360005",
        }
      ]
    },
  ];

  transactionsSignal = signal<Transaction[]>(this.staticData);
}
