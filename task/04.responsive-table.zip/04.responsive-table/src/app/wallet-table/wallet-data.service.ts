import { Injectable } from '@angular/core';
import { signal } from '@angular/core';
import { Transaction } from './transaction.model';

@Injectable({
  providedIn: 'root',
})
export class WalletService {
  private staticData: Transaction[] = [
    {
      "type": "Deposit",
      "amount": 100,
      "date": "2024-08-01",
      "status": "Completed",
      "transactionItems": []
    },
    {
      "type": "Withdrawal",
      "amount": 50,
      "date": "2024-08-02",
      "status": "Completed",
      "transactionItems": []
    },
    // ... other data
  ];

  // Define a Signal to hold the data
  transactionsSignal = signal<Transaction[]>(this.staticData);

  getTransactions() {
    return this.transactionsSignal;
  }
}
