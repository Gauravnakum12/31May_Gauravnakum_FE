import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Transaction } from '../transaction.model';
import { NgClass, NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-wallet-table-row',
  templateUrl: './wallet-table-row.component.html',
  styleUrls: ['./wallet-table-row.component.css'],
  imports:[NgClass,NgIf,NgFor],
  standalone:true,
})
export class WalletTableRowComponent {
  @Input() transaction!: Transaction;
  @Input() index!: number;
  @Input() expandedRow!: number | null;
  @Output() toggle = new EventEmitter<number>();

  isExpanded(): boolean {
    return this.expandedRow === this.index;
  }

  toggleRow(): void {
    this.toggle.emit(this.index);
  }

  copyToClipboard(text: string | undefined): void {
    if (text) {
      navigator.clipboard.writeText(text).then(
        () => {
          console.log('Text copied to clipboard');
        },
        (err) => {
          console.error('Could not copy text: ', err);
        }
      );
    }
  }
}
