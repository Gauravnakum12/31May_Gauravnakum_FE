import { Component, OnInit } from '@angular/core';
import { WalletService } from './wallet-data.service';
import { Transaction } from './transaction.model';
import { signal } from '@angular/core';
import { WalletTableRowComponent } from "./wallet-table-row/wallet-table-row.component";
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-wallet-table',
  templateUrl: './wallet-table.component.html',
  styleUrls: ['./wallet-table.component.css'],
  standalone: true,
  imports: [WalletTableRowComponent,NgFor],

})
export class WalletTableComponent implements OnInit {
  expandedRow: number | null = null;
  transactionsSignal: any;

  constructor(private walletService: WalletService) {
    // Get the Signal from the service
    this.transactionsSignal = this.walletService.getTransactions();
  }

  ngOnInit(): void {}

  toggleRow(index: number): void {
    this.expandedRow = this.expandedRow === index ? null : index;
  }
}
