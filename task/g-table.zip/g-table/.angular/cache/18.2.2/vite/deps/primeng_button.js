import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-AUW23PUF.js";
import "./chunk-GTUCESPA.js";
import "./chunk-MINMG2VS.js";
import "./chunk-3W2WHAOB.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
