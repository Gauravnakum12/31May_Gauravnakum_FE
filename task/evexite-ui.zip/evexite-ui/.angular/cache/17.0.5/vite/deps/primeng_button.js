import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-5GIHUWRE.js";
import "./chunk-3U6SZDML.js";
import "./chunk-EHOBKZ27.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-PFSBGZRB.js";
import "./chunk-2SFJ3DLA.js";
import "./chunk-GHTSNRWU.js";
import "./chunk-T6OEQNTN.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-EBXC6MJI.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
