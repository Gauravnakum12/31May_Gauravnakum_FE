import { AfterContentChecked, AfterViewInit, Component } from '@angular/core';
import { LoaderService } from '../common/services/loader.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent {
  isLoading$: Observable<boolean> = this.LoaderService.isLoading$;
  constructor(public LoaderService: LoaderService) {}
}
