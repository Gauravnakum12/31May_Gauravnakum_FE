import { from } from 'rxjs';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { EventService } from '../../../common/services/event.service';
import { ClientService } from '../../../common/services/client.service';
import { CommonPaginationResponse, EventType, GetAllClientsResponse, IEvent } from '../../../common/models';
import { LoaderService } from '../../../common/services/loader.service';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss'],
})
export class EventComponent implements OnInit, OnDestroy {
  events: IEvent[] = [];
  clients: any[] = [];
  eventTypes = EventType;
  page = 1;
  pagination!: CommonPaginationResponse;

  constructor(
    private router: Router,
    private readonly eventService: EventService,
    private confirmationService: ConfirmationService,
    private _loaderService: LoaderService,
    private _messageService: MessageService
  ) { }

  ngOnInit() {
    this.fetchEvents();
  }

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }

  searchEvents(searchTerm: string) {
    this.events = [];
    this.page = 1;
    this.fetchEvents(searchTerm.trim());
  }

  fetchEvents(search?: string) {
    this._loaderService.showLoader();
    this.eventService.getAllEvents({ page: this.page, limit: 10, search: search }).subscribe({
      next: events => {
        this.events = [...this.events, ...events.events];
        this.pagination = {
          total: events.total,
          page: events.page,
          limit: events.limit,
          totalPages: events.totalPages,
          message: events.message,
        };
        this._loaderService.hideLoader();
      },
      error: error => {
        this._loaderService.hideLoader();
        console.error('Error fetching events:', error);
      },
    });
  }

  clickOnUpdate(event: IEvent) {
    this.router.navigate(['app/events', event.id]);
  }

  confirmDelete(event: IEvent) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${event.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (event.id) this.deleteEvent(event.id);
      },
    });
  }

  deleteEvent(eventId: string) {
    this._loaderService.showLoader();
    this.eventService.deleteEvent(eventId).subscribe({
      next: response => {
        this.events = this.events.filter(event => event.id !== eventId);
        this._loaderService.hideLoader();
        this._messageService.add({ severity: 'success', summary: 'Success', detail: 'Event deleted successfully' });
      },
      error: error => {
        this._loaderService.hideLoader();
      },
    });
  }
  pageChange(event: any) {
    if (event.first === 0) {
      this.page = 1;
      this.fetchEvents();
    } else {
      if (event.first && event.rows) {
        this.page = Math.floor(event.first / event.rows) + 1;
        this.fetchEvents();
      }
    }
  }
  scrolled(event: any) {
    this.page++;
    this.fetchEvents();
  }

  ngOnDestroy() {
    this._loaderService.hideLoader();
  }
}
