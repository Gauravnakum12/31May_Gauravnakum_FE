import { Component, Input } from '@angular/core';
import { EventSegment } from '../../../../../../common/models';
import { SegmentTotalPricePipe } from "../../../../../../common/pipes/segment.total.pipe";
import { MultiplyThemeAreaPipe } from "../../../../../../common/pipes/area.total.pipe";
import { DecimalPipe } from '@angular/common';
import { EventTotalPipe } from "../../../../../../common/pipes/event.total.pipe";

@Component({
  selector: 'app-download-quotation-sheet',
  standalone: true,
  imports: [SegmentTotalPricePipe, MultiplyThemeAreaPipe, DecimalPipe, EventTotalPipe],
  templateUrl: './download-quotation-sheet.component.html',
})
export class DownloadQuotaionSheetComponent {
  @Input() heading: string = '';
  @Input() addressData: string = '';
  @Input() coverImage: string = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTU3HFVnkYFJ_OIogo__Qv58bmhwRqZJcQhOA&s';

  @Input() chooseImage_First: string = '';
  @Input() chooseImage_Second: string = '';
  @Input() chooseImage_Third: string = '';
  @Input() chooseImage_Fourth: string = '';
  @Input() chooseImage_Fifth: string = '';

  @Input() editorTextArea: string = '';
  @Input() eventSegments!: EventSegment[];

  @Input() eventName!: string | undefined;
  @Input() totalArea!: number;
}

