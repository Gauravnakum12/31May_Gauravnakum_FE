import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-download-quotation-sheet',
  standalone: true,
  imports: [],
  templateUrl: './download-quotation-sheet.component.html',
})
export class DownloadQuotaionSheetComponent {
  @Input() heading: string = '';
  @Input() addressData: string = '';
  @Input() coverImage: string = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTU3HFVnkYFJ_OIogo__Qv58bmhwRqZJcQhOA&s';

  @Input() chooseImage_First: string = '';
  @Input() chooseImage_Second: string = '';
  @Input() chooseImage_Third: string = '';
  @Input() chooseImage_Fourth: string = '';
  @Input() chooseImage_Fifth: string = '';

  @Input() editorTextArea: string = '';
  
}
