import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { NgClass, NgForOf, NgIf, TitleCasePipe } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { FormsModule } from '@angular/forms';
import {
  EventVendor,
  EventThirdPartyConfirmationStatusType,
  ArtistType,
  VendorType,
  EventArtist,
  VendorResponse,
} from '../../../../common/models';
import { from } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { OrganizationService } from '../../../../common/services/organization.service';
import { VendorService } from '../../../../common/services/vendor.service';
import { EventVendorService } from '../../../../common/services/event.vendor.service';
import { TagModule } from 'primeng/tag';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { SidebarModule } from 'primeng/sidebar';
import { SearchInputComponent } from '../../../../common/components/search-input/search-input.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AddVendorComponent } from '../../vendor/add-vendor.component';
import { ActionIconsComponent } from '../../../../common/components/action-icons/action-icons.component';

@Component({
  selector: 'app-event-vendor',
  standalone: true,
  imports: [
    ButtonModule,
    NgForOf,
    DialogModule,
    DropdownModule,
    InputTextareaModule,
    FormsModule,
    TagModule,
    NgIf,
    ConfirmDialogModule,
    ToastModule,
    SidebarModule,
    SearchInputComponent,
    NgClass,
    TitleCasePipe,
    InfiniteScrollModule,
    AddVendorComponent,
    ActionIconsComponent,
  ],
  providers: [MessageService],
  templateUrl: './event-vendor.component.html',
  styleUrl: './event-vendor.component.scss',
})
export class EventVendorComponent implements OnInit {
  @Input() eventId: string = '';
  vendors: VendorResponse[] = [];
  displayVendorModal = false;
  @Input() eventVendors: Array<EventVendor & { vendor: VendorResponse }> = [];
  thirdPartyStatus = Object.values(EventThirdPartyConfirmationStatusType).map(d => {
    return {
      name: d,
      id: d,
    };
  });
  eventVendorTypes = Object.values(VendorType).map(d => {
    return {
      name: d,
      id: d,
    };
  });
  currentEventVendor: EventVendor & { vendor?: VendorResponse } = {
    vendorId: '',
    eventId: '',
    id: '',
    notes: '',
    organizationId: '',
    status: EventThirdPartyConfirmationStatusType.PENDING,
  };
  vendorType = '';
  page = 1;
  @ViewChild(AddVendorComponent) addVendorComponent!: AddVendorComponent;
  constructor(
    private readonly vendorService: VendorService,
    private eventVendorService: EventVendorService,
    private readonly organizationService: OrganizationService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {}
  ngOnInit() {
    this.fetchVendor();
  }

  clearCurrentVendor() {
    this.vendorType = '';
    this.currentEventVendor = {
      vendorId: '',
      eventId: '',
      id: '',
      notes: '',
      organizationId: '',
      status: EventThirdPartyConfirmationStatusType.PENDING,
    };
  }

  fetchVendor(isFresh?: boolean) {
    if (isFresh) {
      this.page = 1;
      this.vendors = [];
    }
    this.vendorService.getAllVendors({ page: this.page, limit: 20 }).subscribe({
      next: vendors => {
        this.vendors = [...this.vendors, ...vendors.vendors];
      },
      error: error => {
        console.error('Error fetching events:', error);
      },
    });
  }
  async saveEventVendor() {
    if (this.currentEventVendor.id) {
      const organizationId = this.organizationService.CurrentOrganization;
      let eventVendor = {
        ...this.currentEventVendor,
        organizationId,
        eventId: this.eventId,
      };
      delete eventVendor['vendor'];
      this.eventVendorService.updateEventVendor(this.eventId, eventVendor, this.currentEventVendor.id).subscribe({
        next: response => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Vendor updated',
          });
          this.displayVendorModal = false;
          this.clearCurrentVendor();
        },
        error: error => {
          console.error('Error creating event artist:', error);
        },
      });
    } else {
      const organizationId = this.organizationService.CurrentOrganization;
      let eventVendor = {
        ...this.currentEventVendor,
        organizationId,
        eventId: this.eventId,
      };
      this.eventVendorService.createEventVendor(this.eventId, eventVendor).subscribe({
        next: response => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Vendor added',
          });

          this.displayVendorModal = false;
          this.clearCurrentVendor();
          if (response.event.eventVendors) {
            this.eventVendors = [...response.event.eventVendors];
          }
        },
        error: error => {
          console.error('Error creating event artist:', error);
        },
      });
    }
  }

  filterVendor(event: any) {
    this.vendors = this.vendors.filter(art => art.type === event.value);
  }
  editArtist(artist: EventVendor & { vendor: VendorResponse }) {
    this.currentEventVendor = artist;
    if (artist.vendor) {
      this.vendors = [artist.vendor];
    }
    this.displayVendorModal = true;
  }

  deleteArtist(vendor: EventArtist & { vendor: VendorResponse }, index: number) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${vendor.vendor.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        if (vendor.id) {
          this.eventVendorService.deleteEventVendor(vendor.id).subscribe({
            next: response => {
              this.eventVendors = this.eventVendors.filter(eA => eA.id !== vendor.id);
              this.messageService.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Vendor Removed',
              });
            },
            error: error => {
              console.error(error);
            },
          });
        }
      },
    });
  }
  scrolled() {
    this.page++;
    this.fetchVendor();
  }
  selectArtist(vendor: VendorResponse) {
    this.currentEventVendor.vendorId = vendor.id;
  }
  openSelectArtistModal() {
    this.vendors = [];
    this.clearCurrentVendor();
    this.fetchVendor();
    this.displayVendorModal = true;
  }
  openAddVendor() {
    this.addVendorComponent.resetForm();
    this.addVendorComponent.visible = true;
  }
}
