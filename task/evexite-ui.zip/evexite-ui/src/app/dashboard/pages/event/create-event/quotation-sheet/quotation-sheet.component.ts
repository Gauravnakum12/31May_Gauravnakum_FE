import { Component, Input, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { EditorModule } from 'primeng/editor';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { BreadcrumbsComponent } from '../../../../components/breadcrums/breadcrumbs.component';
import { UploadEventImgComponent } from '../../../../components/upload-event-img/upload-event-img.component';
import { LoaderService } from '../../../../../common/services/loader.service';
import { UploadMediaService } from '../../../../../common/services/upload.service';
import { DownloadQuotaionSheetComponent } from './download-quotaion-sheet/download-quotaion-sheet.component';
import { FormsModule } from '@angular/forms';
import { EventSegment } from '../../../../../common/models';
import { EventService } from '../../../../../common/services/event.service';
import { EventTotalPipe } from "../../../../../common/pipes/event.total.pipe";
import { DecimalPipe } from '@angular/common';
import { TableModule } from 'primeng/table';
import { MultiplyThemeAreaPipe } from "../../../../../common/pipes/area.total.pipe";
import { SegmentTotalPricePipe } from "../../../../../common/pipes/segment.total.pipe";

@Component({
  selector: 'app-quotation-sheet',
  standalone: true,
  imports: [
    BreadcrumbsComponent,
    UploadEventImgComponent,
    EditorModule,
    ButtonModule,
    RippleModule,
    RouterModule,
    DownloadQuotaionSheetComponent,
    FormsModule,
    EventTotalPipe,
    DecimalPipe,
    TableModule,
    MultiplyThemeAreaPipe,
    SegmentTotalPricePipe
  ],
  templateUrl: './quotation-sheet.component.html',
  styleUrl: './quotation-sheet.component.scss',
})
export class QuotationSheetComponent implements OnInit {
  [x: string]: any;
  heading: string = '';
  addressData: string = '';
  coverImage: string = '';
  eventId = '';
  eventName: string | undefined = 'event';
  eventSegments!: EventSegment[];
  totalArea = 0;
  currentEventId: string = '';
  printWindow: Window | null = null;

  chooseImage_First: string = '';
  chooseImage_Second: string = '';
  chooseImage_Third: string = '';
  chooseImage_Fourth: string = '';
  chooseImage_Fifth: string = '';
  editorTextArea: string = '';

  constructor(
    private route: ActivatedRoute,
    private _loaderService: LoaderService,
    private _uploadMediaService: UploadMediaService,
    private messageService: MessageService,
    private readonly eventService: EventService,
  ) { }
  ngOnInit(): void {
    this.getSingleEventDetails();
  }

  onBannerImageUpload(imageUrl: string) {
    this.coverImage = imageUrl;
  }
  onChooseImage_First(imageUrl: string) {
    this.chooseImage_First = imageUrl;
  }
  onChooseImage_Second(imageUrl: string) {
    this.chooseImage_Second = imageUrl;
  }
  onChooseImage_Third(imageUrl: string) {
    this.chooseImage_Third = imageUrl;
  }
  onChooseImage_Fourth(imageUrl: string) {
    this.chooseImage_Fourth = imageUrl;
  }
  onChooseImage_Fifth(imageUrl: string) {
    this.chooseImage_Fifth = imageUrl;
  }
  onDownloadSheet() {
    const printContents = document.getElementById('downloadSheet')?.innerHTML;
    const styles =
      '<style>' + `
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap");
      html,
      body {
        margin: 0;
        padding: 0 ;
        height: 100%;
        font-family: Quicksand, sans-serif;
      }
          img {
    height: 100%;
    width: 100%;
  }

  #webPage {
    width: 100vw;
    max-width: 794px;
    margin: auto;
    background-color: var(--white);
    border-top: 0px;
    height: auto;
    font-family: Quicksand, sans-serif !important;
  }

  .gradint-hr {
    width: 100%;
    background: linear-gradient(180deg, #1a3460 -83.33%, #5090f8 66.67%);
  }

  .gradint-hr:nth-of-type(1) {
    height: 7px;
  }

  .gradint-hr-2 {
    height: 2px;
    margin: 12px 0;
  }

  .title {
    display: flex;
    justify-content: space-between;
    padding: 0 24px;
  }

  .title .colum:nth-of-type(1) {
    max-width: 40%;
    margin-top: 27px;
  }

  .title .colum:nth-of-type(1) h2 {
    font-size: 24px;
    line-height: 32px;
    font-weight: 700;
    margin: 0;
  }

  .title .colum:nth-of-type(1) p {
    font-weight: 700;
    font-size: 14px;
    margin-top: 6px;
    line-height: 13.75px;
  }

  .title .colum:nth-of-type(2) {
    text-align: right;
    margin-top: 26px;
    font-size: 14px;
    max-width: 40%;
    line-height: 20px;
    font-weight: 600;
  }
  .title .colum:nth-of-type(2) p {
    margin-top: 2px;
  }

  .banner {
    padding: 0 24px;
    margin-top: 0px;
    border-radius: 4px;
  }

  .banner img {
    border-radius: 4px;
    max-height: 185px;
  }

  #section-1 {
    padding: 0 24px;
    margin-top: 22px;
    display: flex;
    justify-content: space-between;
    gap: 22px;
  }

  #section-1 .col:nth-of-type(1) {
    width: 49%;
    max-width: 50vw;
    max-width: 400px;
    display: grid;
    padding: 12px;
    grid-template-rows: 80px 97px 97px;
    grid-template-columns: 45% 24% 24%;
    background-color: #e6dfd1;
    border-radius: 4px;
    gap: 10px;
    height: auto;
  }

  .col:nth-of-type(1) .image-box-1 {
    grid-area: 1/1/2/4;
  }

  .col:nth-of-type(1) .image-box-2 {
    grid-area: 2/1/4/2;
  }

  .col:nth-of-type(1) .image-box-3 {
    grid-area: 2/2/3/4;
  }

  .col:nth-of-type(1) .image-box-4 {
    grid-area: 3/2/4/3;
  }

  .col:nth-of-type(1) .image-box-5 {
    grid-area: 3/3/4/4;
  }

  .col:nth-of-type(2) {
    max-width: 47%;
  }

  .col:nth-of-type(2) h2 {
    font-size: 20px;
    font-weight: 700;
    line-height: 28px;
  }

  .col:nth-of-type(2) .description {
    margin-top: 3px;
    text-align: justify;
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
  }

  .col:nth-of-type(2) .data {
    margin-top: 16px;
    text-align: justify;
  }


  #section-2 {
    padding: 0 24px;
    margin-top: 10px;
    gap: 11px;
    display: flex;
    flex-wrap: wrap;
  }

  #section-2 .image-box {
    width: 140px;
    height: 140px;
    border-radius: 3px;
  }

  #section-2 .image-box img {
    border-radius: 3px;
  }

  .event-date {
	 display: flex;
	 justify-content: space-between;
	 padding: 0 3px;
	 font-size: 12px;
	 font-weight: 600;
}
 .event-date p {
	 margin-bottom: 0%;
}
 .upload-container {
	 padding: 0 24px 16px 24px;
}
 .upload-container .row:nth-of-type(1) {
	 height: 150px;
	 margin: 16px 0;
}
 .upload-container .row:nth-of-type(2) {
	 margin-bottom: 16px;
	 height: 300px;
	 display: flex;
	 justify-content: space-between;
	 gap: 12px;
}
 .upload-container .row:nth-of-type(2) .colum {
	 width: 49%;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) {
	 display: grid;
	 padding: 10px;
	 grid-template-rows: 80px 87px 87px;
	 grid-template-columns: 45% 24.5% 24.5%;
	 background-color: #e6dfd1;
	 border-radius: 4px;
	 gap: 10px;
	 height: auto;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) .col-section:nth-of-type(1) {
	 grid-area: 0.125;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) .col-section:nth-of-type(2) {
	 grid-area: 0.25;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) .col-section:nth-of-type(3) {
	 grid-area: 0.0833333333;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) .col-section:nth-of-type(4) {
	 grid-area: 0.125;
}
 .upload-container .row:nth-of-type(2) .colum:nth-of-type(1) .col-section:nth-of-type(5) {
	 grid-area: 0.0625;
}
 .upload-container .row:nth-of-type(3) {
	 margin-top: 12px;
	 min-height: 140px;
	 display: flex;
	 flex-wrap: wrap;
	 gap: 10.7px;
}
 .upload-container .row:nth-of-type(3) .colum {
	 width: 140px;
	 height: 140px;
}
 .event-data {
	 background: #f0f0f0;
	 display: flex;
	 justify-content: space-between;
	 padding: 12px 24px;
}
 .event-data .colum {
	 font-size: 20px;
	 font-weight: 700;
	 line-height: 28px;
	 margin: 0%;
}
 .event-data .colum:nth-of-type(2) {
	 font-size: 16px;
	 font-weight: 600;
}
 .event-segment-container {
	 border: 0.6px solid #898989;
	 margin: 16px 24px;
	 border-radius: 3px;
}
 .event-segment-container:last-of-type {
	 margin: 24px;
}
 .event-segment-container .data-row {
	 display: flex;
	 justify-content: space-between;
	 align-items: center;
	 background: #f8f8f8;
	 border-radius: 4px;
}
 .event-segment-container .data-row .colum {
	 padding: 8px;
}
 .event-segment-container .data-row .colum:nth-of-type(1) {
	 font-size: 20px;
	 font-weight: 700;
	 line-height: 28px;
	 border: none;
	 margin: 0%;
}
 .event-segment-container .data-row .colum:nth-of-type(2) {
	 border: 0.05px solid #d4d4d4;
	 font-size: 12px;
	 font-weight: 600;
	 margin-right: 6px;
	 border-radius: 4px;
	 background-color: #fff;
}
 .event-segment-container .row .colum {
	 border: 0.05px solid #d4d4d4;
	 border-radius: 4px;
	 margin: 12px 8px;
}
 .event-segment-container .row .colum .area-table {
	 background: #f8f8f8;
	 width: 100%;
	 border-top-left-radius: 4px;
	 border-top-right-radius: 4px;
	 border-bottom: 0.05px solid #d4d4d4;
}
 .event-segment-container .row .colum .area-table tr th {
	 font-weight: 600;
	 font-size: 0.8rem;
	 padding: 8px 6px 0px 6px;
}
 .event-segment-container .row .colum .area-table tr th:nth-of-type(1) {
	 min-width: 49%;
	 text-align: left;
}
 .event-segment-container .row .colum .area-table tr th:nth-of-type(2), .event-segment-container .row .colum .area-table tr th:nth-of-type(3) {
	 min-width: 17%;
	 text-align: center;
}
 .event-segment-container .row .colum .area-table tr th:nth-of-type(4) {
	 min-width: 17%;
	 text-align: right;
}
 .event-segment-container .row .colum .area-table tr:nth-of-type(2) th {
	 font-size: 1rem;
	 font-weight: 700;
	 padding: 0px 8px 8px 6px;
}
 .event-segment-container .row .colum .item-table {
	 width: 100%;
	 border-bottom-left-radius: 4px;
	 border-bottom-right-radius: 4px;
}
 .event-segment-container .row .colum .item-table tr {
	 border-bottom: 0.05px solid #d4d4d4;
}
 .event-segment-container .row .colum .item-table tr:last-of-type {
	 border-bottom: none;
}
 .event-segment-container .row .colum .item-table tr:last-of-type td {
	 text-align: justify !important;
}
 .event-segment-container .row .colum .item-table tr th, .event-segment-container .row .colum .item-table tr td {
	 border-collapse: collapse;
	 padding-left: 16px;
	 padding: 6px;
	 font-size: 0.8rem;
}
 .event-segment-container .row .colum .item-table tr th:nth-of-type(1), .event-segment-container .row .colum .item-table tr td:nth-of-type(1) {
	 min-width: 49%;
	 text-align: left;
}
 .event-segment-container .row .colum .item-table tr th:nth-of-type(2), .event-segment-container .row .colum .item-table tr td:nth-of-type(2), .event-segment-container .row .colum .item-table tr th:nth-of-type(3), .event-segment-container .row .colum .item-table tr td:nth-of-type(3) {
	 min-width: 17%;
	 text-align: center;
}
 .event-segment-container .row .colum .item-table tr th:nth-of-type(4), .event-segment-container .row .colum .item-table tr td:nth-of-type(4) {
	 min-width: 17%;
	 text-align: right;
	 padding: 4px 6px;
}
 .event-segment-container table, .event-segment-container tr {
	 border-collapse: collapse;
}
 
 
  ` +
      '</style>';
    this.printWindow = window.open('', '', '_blank');
    if (this.printWindow && printContents) {
      this.printWindow.document.write('<html><head>');
      this.printWindow.document.write(styles);
      this.printWindow.document.write('</head><body>');
      this.printWindow.document.write(printContents);
      this.printWindow.document.write('</body></html>');
      this.printWindow.document.close();
      this.printWindow.print();
    }
  }

  getSingleEventDetails(): void {
    if (this.route.snapshot.params['id']) {
      if (this.route.snapshot.params['id'] !== 'create') {
        this.eventId = this.route.snapshot.params['id'];
        this._loaderService.showLoader();
        this.eventService.fetchEventById(this.eventId).subscribe(response => {
          console.log(response.event);
          this.eventName = response.event.name;
          this.eventSegments = response.event.eventSegments;
          this.totalArea = this.eventSegments.length;
          this._loaderService.hideLoader();
        });
      }
    }
  }
}
