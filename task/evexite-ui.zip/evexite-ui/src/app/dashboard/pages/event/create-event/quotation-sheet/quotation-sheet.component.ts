import { Component, Input, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { EditorModule } from 'primeng/editor';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { BreadcrumbsComponent } from '../../../../components/breadcrums/breadcrumbs.component';
import { UploadEventImgComponent } from '../../../../components/upload-event-img/upload-event-img.component';
import { LoaderService } from '../../../../../common/services/loader.service';
import { UploadMediaService } from '../../../../../common/services/upload.service';
import { DownloadQuotaionSheetComponent } from './download-quotaion-sheet/download-quotaion-sheet.component';
import { FormsModule } from '@angular/forms';
import { EventSegment, IEvent } from '../../../../../common/models';
import { EventService } from '../../../../../common/services/event.service';
import { EventTotalPipe } from "../../../../../common/pipes/event.total.pipe";
import { DecimalPipe } from '@angular/common';
import { TableModule } from 'primeng/table';

@Component({
  selector: 'app-quotation-sheet',
  standalone: true,
  imports: [
    BreadcrumbsComponent,
    UploadEventImgComponent,
    EditorModule,
    ButtonModule,
    RippleModule,
    RouterModule,
    DownloadQuotaionSheetComponent,
    FormsModule,
    EventTotalPipe,
    DecimalPipe,
    TableModule,
    
  ],
  templateUrl: './quotation-sheet.component.html',
  styleUrl: './quotation-sheet.component.scss',
})
export class QuotationSheetComponent implements OnInit {
[x: string]: any;
  heading: string = '';
  addressData: string = '';
  coverImage: string = '';
  eventId = '';
  eventName: string | undefined = 'event';
  eventSegments!: EventSegment[];
  totalArea = 0;
  currentEventId: string = '';
  printWindow: Window | null = null;

  chooseImage_First: string = '';
  chooseImage_Second: string = '';
  chooseImage_Third: string = '';
  chooseImage_Fourth: string = '';
  chooseImage_Fifth: string = '';
  editorTextArea: string = '';



  constructor(
    private route: ActivatedRoute,
    private _loaderService: LoaderService,
    private _uploadMediaService: UploadMediaService,
    private messageService: MessageService,
    private readonly eventService: EventService,
  ) { }
  ngOnInit(): void {
    this.getSingleEventDetails();
  }

  onBannerImageUpload(imageUrl: string) {
    this.coverImage = imageUrl;
  }
  onChooseImage_First(imageUrl: string) {
    this.chooseImage_First = imageUrl;
  }
  onChooseImage_Second(imageUrl: string) {
    this.chooseImage_Second = imageUrl;
  }
  onChooseImage_Third(imageUrl: string) {
    this.chooseImage_Third = imageUrl;
  }
  onChooseImage_Fourth(imageUrl: string) {
    this.chooseImage_Fourth = imageUrl;
  }
  onChooseImage_Fifth(imageUrl: string) {
    this.chooseImage_Fifth = imageUrl;
  }
  onDownloadSheet() {
    const printContents = document.getElementById('downloadSheet')?.innerHTML;
    const styles =
      '<style>' +
      `
      @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap");
      html,
      body {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: Quicksand, sans-serif;
      }
          img {
    height: 100%;
    width: 100%;
  }

  #webPage {
    width: 100vw;
    max-width: 794px;
    margin: auto;
    background-color: var(--white);
    border-top: 0px;
    height: auto;
    font-family: Quicksand, sans-serif !important;
  }

  .gradint-hr {
    width: 100%;
    background: linear-gradient(180deg, #1a3460 -83.33%, #5090f8 66.67%);
  }

  .gradint-hr:nth-of-type(1) {
    height: 7px;
  }

  .gradint-hr-2 {
    height: 2px;
    margin: 12px 0;
  }

  .title {
    display: flex;
    justify-content: space-between;
    padding: 0 24px;
  }

  .title .colum:nth-of-type(1) {
    max-width: 40%;
    margin-top: 27px;
  }

  .title .colum:nth-of-type(1) h2 {
    font-size: 24px;
    line-height: 32px;
    font-weight: 700;
    margin: 0;
  }

  .title .colum:nth-of-type(1) p {
    font-weight: 700;
    font-size: 14px;
    margin-top: 6px;
    line-height: 13.75px;
  }

  .title .colum:nth-of-type(2) {
    text-align: right;
    margin-top: 26px;
    font-size: 14px;
    max-width: 40%;
    line-height: 20px;
    font-weight: 600;
  }
  .title .colum:nth-of-type(2) p {
    margin-top: 2px;
  }

  .banner {
    padding: 0 24px;
    margin-top: 0px;
    border-radius: 4px;
  }

  .banner img {
    border-radius: 4px;
    max-height: 185px;
  }

  #section-1 {
    padding: 0 24px;
    margin-top: 22px;
    display: flex;
    justify-content: space-between;
    gap: 22px;
  }

  #section-1 .col:nth-of-type(1) {
    width: 49%;
    max-width: 50vw;
    max-width: 400px;
    display: grid;
    padding: 12px;
    grid-template-rows: 80px 97px 97px;
    grid-template-columns: 45% 24% 24%;
    background-color: #e6dfd1;
    border-radius: 4px;
    gap: 10px;
    height: auto;
  }

  .col:nth-of-type(1) .image-box-1 {
    grid-area: 1/1/2/4;
  }

  .col:nth-of-type(1) .image-box-2 {
    grid-area: 2/1/4/2;
  }

  .col:nth-of-type(1) .image-box-3 {
    grid-area: 2/2/3/4;
  }

  .col:nth-of-type(1) .image-box-4 {
    grid-area: 3/2/4/3;
  }

  .col:nth-of-type(1) .image-box-5 {
    grid-area: 3/3/4/4;
  }

  .col:nth-of-type(2) {
    max-width: 47%;
  }

  .col:nth-of-type(2) h2 {
    font-size: 20px;
    font-weight: 700;
    line-height: 28px;
  }

  .col:nth-of-type(2) .description {
    margin-top: 3px;
    text-align: justify;
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
  }

  .col:nth-of-type(2) .data {
    margin-top: 16px;
    text-align: justify;
  }


  #section-2 {
    padding: 0 24px;
    margin-top: 10px;
    gap: 11px;
    display: flex;
    flex-wrap: wrap;
  }

  #section-2 .image-box {
    width: 140px;
    height: 140px;
    border-radius: 3px;
  }

  #section-2 .image-box img {
    border-radius: 3px;
  }
 
  ` +
      '</style>';
    this.printWindow = window.open('', '', '_blank');
    if (this.printWindow && printContents) {
      this.printWindow.document.write('<html><head>');
      this.printWindow.document.write(styles);
      this.printWindow.document.write('</head><body>');
      this.printWindow.document.write(printContents);
      this.printWindow.document.write('</body></html>');
      this.printWindow.document.close();
      this.printWindow.print();
    }
  }

  getSingleEventDetails(): void {
    if (this.route.snapshot.params['id']) {
      if (this.route.snapshot.params['id'] !== 'create') {
        this.eventId = this.route.snapshot.params['id'];
        this._loaderService.showLoader();
        this.eventService.fetchEventById(this.eventId).subscribe(response => {
          console.log();
          this.eventName = response.event.name;
          this.eventSegments = response.event.eventSegments;
          this.totalArea = this.eventSegments.length;
          console.log(this.eventSegments);
          this._loaderService.hideLoader();
        });
      }
    }
  }
}
