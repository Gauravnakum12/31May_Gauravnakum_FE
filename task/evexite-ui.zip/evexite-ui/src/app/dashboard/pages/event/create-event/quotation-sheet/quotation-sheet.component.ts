import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { EditorModule } from 'primeng/editor';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { RouterModule } from '@angular/router';
import { BreadcrumbsComponent } from '../../../../components/breadcrums/breadcrumbs.component';
import { UploadEventImgComponent } from '../../../../components/upload-event-img/upload-event-img.component';
import { LoaderService } from '../../../../../common/services/loader.service';
import { UploadMediaService } from '../../../../../common/services/upload.service';
import { DownloadQuotaionSheetComponent } from "./download-quotaion-sheet/download-quotaion-sheet.component";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-quotation-sheet',
  standalone: true,
  imports: [BreadcrumbsComponent, UploadEventImgComponent, EditorModule, ButtonModule, RippleModule, RouterModule, DownloadQuotaionSheetComponent, FormsModule],
  templateUrl: './quotation-sheet.component.html',
  styleUrl: './quotation-sheet.component.scss'
})
export class QuotationSheetComponent implements OnInit {
  heading: string = '';
  addressData: string = '';
  coverImage: string = '';

  chooseImage_First: string = '';
  chooseImage_Second: string = '';
  chooseImage_Third: string = '';
  chooseImage_Fourth: string = '';
  chooseImage_Fifth: string = '';
  editorTextArea: string = '';

  printWindow: Window | null = null;

  constructor(
    private _loaderService: LoaderService,
    private _uploadMediaService: UploadMediaService,
    private messageService: MessageService
  ) {
  }
  ngOnInit(): void {
    this.stopLoader();
  }

  stopLoader() {
    this._loaderService.hideLoader();
    console.log('loader stope');
  }

  onBannerImageUpload(imageUrl: string) {
    this.coverImage = imageUrl;
  }
  onChooseImage_First(imageUrl: string) {
    this.chooseImage_First = imageUrl;
  }
  onChooseImage_Second(imageUrl: string) {
    this.chooseImage_Second = imageUrl;
  }
  onChooseImage_Third(imageUrl: string) {
    this.chooseImage_Third = imageUrl;
  }
  onChooseImage_Fourth(imageUrl: string) {
    this.chooseImage_Fourth = imageUrl;
  }
  onChooseImage_Fifth(imageUrl: string) {
    this.chooseImage_Fifth = imageUrl;
  }


  onDownloadSheet() {
    const printContents = document.getElementById('downloadSheet')?.innerHTML;
    const styles =
      '<style>' +
      `
  img {
    height: 100%;
    width: 100%;
  }
  #webPage {
    width: 100vw;
    max-width: 794px;
    margin: auto;
    background-color: var(--white);
    border-top: 0px;
    height: auto;
  }
  .gradint-hr {
    width: 100%;
    background: linear-gradient(180deg, #1a3460 -83.33%, #5090f8 66.67%);
  }
  .gradint-hr:nth-of-type(1) {
    height: 7px;
  }
  .gradint-hr-2 {
    height: 2px;
    margin: 12px 0;
  }
  .title {
    display: flex;
    justify-content: space-between;
    padding: 0 24px;
  }
  .title .col:nth-of-type(1) {
    max-width: 40%;
    margin-top: 27px;
  }
  .title .col:nth-of-type(1) h2 {
    font-size: 24px;
    line-height: 32px;
    font-weight: 800;
  }
  .title .col:nth-of-type(1) p {
    font-weight: 700;
    font-size: 14px;
    margin-top: 6px;
    line-height: 13.75px;
  }
  
  .title .col:nth-of-type(2) {
    text-align: right;
    margin-top: 26px;
    font-size: 14px;
    max-width: 40%;
    line-height: 20px;
    font-weight: 600px;
  }
  
  .banner {
    padding: 0 24px;
    margin-top: 16px;
    border-radius: 4px;
  }
  .banner img {
    border-radius: 4px;
    max-height: 250px;
  }
  #section-1 {
    padding: 0 24px;
    margin-top: 26px;
    display: flex;
    justify-content: space-between;
    gap: 22px;
  }
  #section-1 .col:nth-of-type(1) {
    width: 49%;
    max-width: 50vw;
    max-width: 400px;
    display: grid;
    padding: 12px;
    grid-template-rows: 80px 97px 97px;
    grid-template-columns: 45% 24% 24%;
    background-color: #e6dfd1;
    border-radius: 4px;
    gap: 10px;
    height: auto;
  }
  
  .col:nth-of-type(1) .image-box-1 {
    grid-area: 1/1/2/4;
  }
  .col:nth-of-type(1) .image-box-2 {
    grid-area: 2/1/4/2;
  }
  .col:nth-of-type(1) .image-box-3 {
    grid-area: 2/2/3/4;
  }
  .col:nth-of-type(1) .image-box-4 {
    grid-area: 3/2/4/3;
  }
  
  .col:nth-of-type(1) .image-box-5 {
    grid-area: 3/3/4/4;
  }
  .col:nth-of-type(2) {
    max-width: 47%;
  }
  .col:nth-of-type(2) h2 {
    font-size: 20px;
    font-weight: 700;
    line-height: 28px;
  }
  .col:nth-of-type(2) .description {
    margin-top: 3px;
    text-align: justify;
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
  }
  .col:nth-of-type(2) .data {
    margin-top: 16px;
  }
  
  .col:nth-of-type(2) .data p {
    font-weight: 400;
    font-size: 12px;
    line-height: 20px;
  }
  .col:nth-of-type(2) .data span:nth-of-type(1) {
    margin-right: 4px;
  }
  .col:nth-of-type(2) .data span:nth-of-type(2) {
    margin-left: 6px;
  }
  #section-2 {
    padding: 0 24px;
    margin-top: 10px;
    gap: 11px;
    display: flex;
    flex-wrap: wrap;
  }
  #section-2 .image-box {
    width: 140px;
    height:140px ;
    border-radius: 3px;
  }
  #section-2 .image-box img {
    border-radius: 3px;
  }
  
  #section-3 {
    padding: 0 24px;
  }
  #section-3 table {
    width: 100%;
  }
  #section-3 table,
  #section-3 table tr th,
  #section-3 table tr td {
    border-collapse: collapse;
  }
  #section-3 table th {
    padding: 8px;
    text-align: left;
    font-size: var(--fontSize-5);
    background-color: var(--bluryWood);
    border-bottom: 0.2px solid var(--E_Gray, #898989);
    border-top: 0.2px solid var(--E_Gray, #898989);
  }
  th:first-of-type {
    border-radius: 3px 0 0 3px;
    border-left: 0.2px solid var(--E_Gray, #898989);
    font-size: var(--fontSize-5);
  }
  #section-3 table th:last-of-type {
    border-radius: 0 3px 3px 0;
  }
  
  #section-3 table tbody tr {
    font-size: var(--fontSize-4);
    border-bottom: 0.6px solid var(--E_Gray, #898989);
  }
  #section-3 table tbody tr td {
    padding: 8px;
  }
  #section-3 table tbody tr:last-of-type {
    border: none;
  }
  
  .property-data {
    font-size: var(--fontSize-4);
    padding: 8px;
    margin-top: 8px;
    line-height: 12.5px;
    border-radius: 3px;
    border: 0.6px solid var(--E_Gray, #898989);
  }
  ` +
      '</style>';
    this.printWindow = window.open('', '', '_blank');
    if (this.printWindow && printContents) {
      this.printWindow.document.write('<html><head>');
      this.printWindow.document.write(styles);
      this.printWindow.document.write('</head><body>');
      this.printWindow.document.write(printContents);
      this.printWindow.document.write('</body></html>');
      this.printWindow.document.close();
      this.printWindow.print();
    }
  }
}

