import { v4 as uuidv4 } from 'uuid';
import { from } from 'rxjs';
import { ConfirmationService } from 'primeng/api';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { WhatsappCloudConfigService } from '../../../common/services/whatsapp-cloud.service';

interface WhatsappCloudConfig {
  id: string;
  number: string;
  phoneNumberId: string;
  businessAccountId: string;
  appId: string;
  accessToken: string;
  businessId: string;
  verifyToken: string;
  templateSyncToken: string;
  callbackUrl: string;
}

@Component({
  selector: 'app-event',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss'],
})
export class SettingComponent implements OnInit {
  whatsappCloudConfigForm: FormGroup;
  whatsappCloudConfigs: any[] = [];
  eventTypes = [
    { label: 'Social', value: 'SOCIAL' },
    { label: 'Corporate', value: 'CORPORATE' },
    { label: 'Special', value: 'SPECIAL' },
  ];

  CALLBACK_URL = 'https://bx5vhm2s-4009.inc1.devtunnels.ms/chatterbox/whatsapp-cloud/';

  constructor(
    private formBuilder: FormBuilder,
    private readonly whatsappCloudConfigService: WhatsappCloudConfigService,
    private confirmationService: ConfirmationService
  ) {
    this.whatsappCloudConfigForm = this.formBuilder.group({
      id: '',
      number: ['', Validators.required],
      phoneNumberId: ['', Validators.required],
      businessAccountId: ['', Validators.required],
      appId: ['', Validators.required],
      accessToken: ['', Validators.required],
      businessId: ['', Validators.required],
      verifyToken: '',
      templateSyncToken: '',
      callbackUrl: '',
    });
    this.whatsappCloudConfigForm.get('callbackUrl')?.disable();
  }

  ngOnInit() {
    this.fetchWhatsappCloudConfig();
  }

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }

  async fetchWhatsappCloudConfig() {
    const organizationId = this.fetchOrganizationId();
    try {
      // const whatsappCloudConfigs = await this.whatsappCloudConfigService.getWhatsappCloudConfig(organizationId);
      // console.log('whatsappCloudConfigs', whatsappCloudConfigs);
      // if (whatsappCloudConfigs?.data?.length === 0) {
      //   await this.insertNewWhatsappCloudConfig(organizationId);
      // } else {
      //   this.whatsappCloudConfigs = whatsappCloudConfigs.data as any[];
      //   this.openUpdateDialog(this.whatsappCloudConfigs[0]);
      // }
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  }

  async insertNewWhatsappCloudConfig(organizationId: string) {
    const whatsappCloudConfigData = this.createWhatsappCloudConfigData(organizationId);
    try {
      await this.whatsappCloudConfigService.insertWhatsappCloudConfig(whatsappCloudConfigData);
      this.fetchWhatsappCloudConfig();
    } catch (error) {
      console.log('ERROR', error);
    }
  }

  createWhatsappCloudConfigData(organizationId: string) {
    return {
      id: uuidv4(),
      organizationId,
      number: '',
      phoneNumberId: '',
      businessAccountId: '',
      appId: '',
      accessToken: '',
      businessId: '',
      verifyToken: uuidv4(),
      templateSyncToken: uuidv4(),
      callbackUrl: `${this.CALLBACK_URL}${organizationId}`,
    };
  }

  openUpdateDialog(whatsappCloudConfig: WhatsappCloudConfig) {
    this.whatsappCloudConfigForm.patchValue(whatsappCloudConfig);
  }

  copyToClipboard() {
    navigator.clipboard.writeText(this.whatsappCloudConfigForm.get('callbackUrl')?.value).then(
      () => {
        // You can show a success message here
      },
      err => {
        // You can show an error message here
      }
    );
  }

  updateWhatsappCloudSetting() {
    if (this.whatsappCloudConfigForm.valid) {
      const organizationId = this.fetchOrganizationId();

      const whatsappCloudConfigData = {
        ...this.whatsappCloudConfigForm.value,
        organizationId,
        updatedAt: new Date().toISOString(),
      };

      from(this.whatsappCloudConfigService.updateWhatsappCloudConfig(organizationId, whatsappCloudConfigData)).subscribe({
        next: response => {
          this.fetchWhatsappCloudConfig();
        },
        error: error => {
          console.log('ERROR', error);
        },
      });
    }
  }
}
