import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { InventoryService } from '../../../../common/services/inventory.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Inventory } from '../../../../common/models';
import { TableLazyLoadEvent } from 'primeng/table';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inventory-list',
  templateUrl: './inventory-list.component.html',
  styleUrl: './inventory-list.component.scss',
})
export class InventoryListComponent implements OnInit, OnChanges {
  inventories: Inventory[] = [];
  totalRecords = 0;
  page = 1;
  @Input() searchTerm: string = '';
  constructor(
    private readonly stockService: InventoryService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    //this.fetchStocks();
  }
  openUpdateDialog(stock: Inventory) {
    this._router.navigate([`app/inventory/${stock.id}`]);
  }
  pageChange(event: TableLazyLoadEvent) {
    if (event.first === 0) {
      this.page = 1;
      this.fetchStocks();
    } else {
      if (event.first && event.rows) {
        this.page = event.first / event.rows + 1;
        this.fetchStocks();
      }
    }
  }
  confirmDelete(stock: Inventory) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${stock.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteStock(stock);
      },
    });
  }

  async deleteStock(stock: Inventory) {
    try {
      this.stockService.deleteInventory(stock.id).subscribe(message => {
        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Inventory Deleted' });

        this.fetchStocks();
      });
    } catch (error) {
      console.error('Error deleting stock or image:', error);
    }
  }
  fetchStocks() {
    this.stockService.getAllInventory({ page: this.page, search: this.searchTerm }).subscribe({
      next: stocks => {
        this.inventories = stocks.inventories;
        this.totalRecords = stocks.total;
      },
      error: error => {
        console.error('Error fetching stocks:', error);
      },
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['searchTerm'].currentValue !== changes['searchTerm'].previousValue) {
      this.fetchStocks();
    }
  }
}
