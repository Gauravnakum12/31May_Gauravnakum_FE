import { OrganizationService } from './../../../../common/services/organization.service';
import { Component, OnInit } from '@angular/core';
import { Inventory, InventoryVariant, InventoryVariantGroup } from '../../../../common/models';
import { v4 as uuidv4 } from 'uuid';
import { ChipsAddEvent } from 'primeng/chips';
import { InventoryService } from '../../../../common/services/inventory.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { UploadMediaService } from '../../../../common/services/upload.service';
@Component({
  selector: 'app-create-inventory',
  templateUrl: './create-inventory.component.html',
  styleUrl: './create-inventory.component.scss',
})
export class CreateInventoryComponent implements OnInit {
  variants: InventoryVariant[] = [];
  variantGroups: InventoryVariantGroup[] = [];
  varinatOptions = '';
  currentInventoryObj: Inventory = {
    name: '',
    image: '',
    description: '',
    location: '',
    organizationId: '',
    id: '',
    price: 0,
    quantity: 0,
  };
  blockedPanel: boolean = true;
  constructor(
    private _uploadMediaService: UploadMediaService,
    private organizationService: OrganizationService,
    private _inventoryService: InventoryService,
    private _activatedRoute: ActivatedRoute,
    private messageService: MessageService,
    private _router: Router
  ) {}

  ngOnInit() {
    let params = this._activatedRoute.snapshot.params;
    if (params['id'] !== 'create') {
      this._inventoryService.getInventory(params['id']).subscribe(
        (data: any) => {
          this.currentInventoryObj = data.inventory;
          this.variants = data.inventory.inventoryVariants;
          this.variantGroups = data.inventory.inventoryVariantGroups;
        },
        error => {
          console.error(error);
        }
      );
    }
  }
  addVariant() {
    this.variants.push({
      name: '',
      inventoryVariantValues: [],
      organizationId: this.organizationService.CurrentOrganization,
      id: uuidv4(),
    });
  }

  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImage(file);
    }
  }

  uploadImage(file: File) {
    this._uploadMediaService.uploadFile(file, 'Inventory').subscribe(
      response => {
        this.currentInventoryObj.image = response.url;
      },
      err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
      }
    );
  }
  deleteVariant(index: number) {
    this.variants.splice(index, 1);
    this.processVariantGroup();
  }

  deleteGroupVariant(index: number) {
    this.variantGroups.splice(index, 1);
  }

  insertAndSetInventory() {
    let inventoryObj: any = {
      ...this.currentInventoryObj,
      organizationId: this.organizationService.CurrentOrganization,
      id: uuidv4(),
    };
    if (!this.variants.length) {
      inventoryObj['price'] = this.currentInventoryObj.price;
      inventoryObj['quantity'] = this.currentInventoryObj.quantity;
    }
    this._inventoryService.createInventory(inventoryObj).subscribe(
      data => {
        this.currentInventoryObj = data.inventory;
        inventoryObj['id'] = data.inventory.id;
      },
      error => {
        console.error(error);
      }
    );
  }

  async onSaveClick() {
    try {
      if (!this.currentInventoryObj?.id) {
        await this.insertAndSetInventory();
      } else {
        let inventoryObj: any = { ...this.currentInventoryObj };
        inventoryObj['inventoryVariants'] = this.variants;
        inventoryObj['inventoryVariantGroups'] = this.variantGroups;
        this._inventoryService.createInventoryVariant(inventoryObj).subscribe(
          data => {
            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Inventory Updated' });
            this._router.navigate(['/app/inventory']);
          },
          errr => {
            console.error(errr);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while updating inventory' });
          }
        );
      }
    } catch (e) {
      console.error(e);
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while updating inventory' });
    }
  }
  cartesian = (arrays: any[][]) => {
    // If only one array is passed, convert each element into an array.
    if (!arrays.length) {
      return [];
    }
    if (arrays.length === 1) {
      return arrays[0].map(element => [element]);
    }

    // Proceed with the original cartesian product logic for multiple arrays.
    return arrays.reduce((a, b) => a.flatMap(d => b.map(e => [d, e].flat())));
  };
  onChipAdded(variant: InventoryVariant, event: ChipsAddEvent) {
    variant.inventoryVariantValues?.pop();
    if (!variant.inventoryVariantValues?.filter(v => v.value.toLowerCase() == event.value.toLowerCase()).length)
      variant.inventoryVariantValues?.push({
        value: event.value,
        id: uuidv4(),
      });
    this.processVariantGroup();
  }

  processVariantGroup() {
    const allVariantsArr = this.variants.filter(vr => vr.inventoryVariantValues?.length).map(vr => vr.inventoryVariantValues);
    const allComb = this.cartesian(allVariantsArr);
    const allCombIdSet = new Set(
      allComb.map(element =>
        element
          .map((el: { id: any }) => el.id)
          .sort()
          .join()
      )
    );

    this.variantGroups = this.variantGroups.filter(
      vg =>
        vg.inventoryVariantValues &&
        allCombIdSet.has(
          vg.inventoryVariantValues
            .map(iv => iv.id)
            .sort()
            .join()
        )
    );

    allComb.forEach(element => {
      const elementId = element
        .map((el: { id: any }) => el.id)
        .sort()
        .join();
      if (
        !this.variantGroups.some(
          vg =>
            vg.inventoryVariantValues &&
            vg.inventoryVariantValues
              .map(iv => iv.id)
              .sort()
              .join() === elementId
        )
      ) {
        this.variantGroups.push({
          inventoryVariantValues: element,
          organizationId: this.organizationService.CurrentOrganization,
          price: 0,
          quantity: 0,
          id: uuidv4(),
        });
      }
    });
  }

  onChipRemoved(variant: InventoryVariant, event: ChipsAddEvent) {
    this.processVariantGroup();
  }
}
