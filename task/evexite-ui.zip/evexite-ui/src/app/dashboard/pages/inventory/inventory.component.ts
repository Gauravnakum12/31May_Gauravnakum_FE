import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.scss'],
})
export class InventoryComponent implements OnInit {
  searchTerm: string = '';

  constructor(private _router: Router) {}

  ngOnInit() {}

  searchStocks(event: string) {
    this.searchTerm = event;
  }

  navigateToCreation() {
    this._router.navigate(['app/inventory/create']);
  }
}
