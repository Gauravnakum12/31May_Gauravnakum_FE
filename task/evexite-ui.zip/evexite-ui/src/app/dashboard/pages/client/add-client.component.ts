import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { v4 as uuidv4 } from 'uuid';
import { ClientService } from '../../../common/services/client.service';
import { ClientResponse } from '../../../common/models';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-add-client',
  template: `
    <p-dialog
      header="Add Client"
      [(visible)]="visible"
      [modal]="true"
      [style]="{ width: '50vw' }"
      [baseZIndex]="10000"
      [draggable]="false"
      [resizable]="false"
      [closable]="true">
      <form [formGroup]="clientForm" (ngSubmit)="createClient()" class="mt-3 mb-3">
        <label for="name" class="block text-900 font-medium mb-2 required">Name</label>
        <input id="name" type="text" placeholder="Enter full name" pInputText class="w-full mb-3" formControlName="name" />
        <div class="flex align-items-center gap-3 mb-3">
          <div class="w-full">
            <label for="primaryContact" class="block text-900 font-medium mb-2"
              >Primary Contact
              <i
                class="pi pi-info-circle"
                pTooltip="Start with country code. E.g., '91XXXXXXXXXX' for a '91' code. WhatsApp number preferred."
                tooltipPosition="right"></i
            ></label>
            <p-inputNumber
              class="w-full"
              styleClass="w-full"
              [useGrouping]="false"
              formControlName="primaryContact"
              [maxlength]="12"
              placeholder="Enter primary contact number">
            </p-inputNumber>
          </div>
          <div class="w-full">
            <label for="secondaryContact" class="block text-900 font-medium mb-2">Secondary Contact</label>
            <p-inputNumber
              class="w-full"
              styleClass="w-full"
              [useGrouping]="false"
              formControlName="secondaryContact"
              [maxlength]="12"
              placeholder="Enter secondary contact number">
            </p-inputNumber>
          </div>
        </div>
        <div class="flex align-items-center gap-3 mb-3">
          <div class="w-full">
            <label for="email" class="block text-900 font-medium mb-2">Email</label>
            <input id="email" type="email" placeholder="Enter email address" pInputText class="w-full" formControlName="email" />
          </div>
          <div class="w-full">
            <label for="location" class="block text-900 font-medium mb-2">Location</label>
            <input id="location" type="text" placeholder="Enter location" pInputText class="w-full" formControlName="location" />
          </div>
        </div>

        <label for="notes" class="block text-900 font-medium mb-2">Notes</label>
        <textarea id="notes" placeholder="Enter notes" pInputTextarea class="w-full mb-3" formControlName="notes"> </textarea>

        <div class="w-full flex align-items-center justify-content-end gap-2">
          <p-button label="Cancel" [raised]="true" class="mr-2" severity="secondary" (onClick)="visible = false"></p-button>
          <p-button label="Add" [raised]="true" type="submit" [disabled]="!clientForm.valid"></p-button>
        </div>
      </form>
    </p-dialog>
  `,
  styles: [``],
})
export class AddClientComponent {
  visible = false;
  clientForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', [Validators.required]),
    primaryContact: new FormControl('', [Validators.required, Validators.maxLength(12), Validators.minLength(10)]),
    email: new FormControl(''),
    secondaryContact: new FormControl(null),
    location: new FormControl(''),
    notes: new FormControl(''),
    organizationId: new FormControl(''),
  });
  @Output() clientAdded: EventEmitter<boolean> = new EventEmitter();
  constructor(
    private clientService: ClientService,
    private messageService: MessageService
  ) {}

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }
  createClient() {
    if (this.clientForm.valid) {
      // Call your service here to create the client

      const organizationId = this.fetchOrganizationId();
      const clientData: any = {
        ...this.clientForm.value,
        primaryContact: this.clientForm.value.primaryContact?.toString(),
        id: uuidv4(),
        organizationId,
      };
      Object.keys(clientData).forEach(key => {
        if (clientData[key] === '') {
          delete clientData[key];
        }
      });
      this.clientService.createClient(clientData).subscribe({
        next: (response: ClientResponse) => {
          this.clientForm.reset();
          this.visible = false;
          this.messageService.add({ severity: 'success', detail: 'Client added successfully: ' });

          this.clientAdded.emit(true); // Fetch the updated list of clients
        },
        error: error => {
          this.messageService.add({ severity: 'error', detail: 'Error while creating client: ' + error.error.message });
          console.log('ERROR', error);
        },
      });
    }
  }

  resetForm() {
    this.clientForm.reset();
  }
}
