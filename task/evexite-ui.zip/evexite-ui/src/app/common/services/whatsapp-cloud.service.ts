import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class WhatsappCloudConfigService {
  constructor(private _http: HttpClient) {}

  getWhatsappCloudConfig(organizationId: string) {
    return this._http.get('WhatsappCloudConfig');
  }

  updateWhatsappCloudConfig(organizationId: string, data: any) {
    return this._http.get('WhatsappCloudConfig');
  }

  insertWhatsappCloudConfig(data: any) {
    return this._http.get('WhatsappCloudConfig');
  }
}
