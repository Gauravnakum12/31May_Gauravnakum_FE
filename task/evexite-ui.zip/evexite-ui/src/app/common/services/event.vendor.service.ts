import { Injectable } from '@angular/core';
import { EventVendor, IEvent } from '../models';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class EventVendorService {
  API_URL = `${environment.API_URL}/event/`;

  constructor(private http: HttpClient) {}

  createEventVendor(eventId: string, Vendor: EventVendor): Observable<{ message: string; event: IEvent }> {
    return this.http.post<{ message: string; event: IEvent }>(this.API_URL + eventId + '/vendor', Vendor);
  }

  updateEventVendor(eventId: string, Vendor: EventVendor, eventVendorId: string): Observable<{ message: string; event: IEvent }> {
    return this.http.put<{ message: string; event: IEvent }>(this.API_URL + eventId + '/vendor/' + eventVendorId, Vendor);
  }

  deleteEventVendor(eventVendorId: string) {
    return this.http.delete<{ message: string }>(this.API_URL + 'vendor/' + eventVendorId);
  }
}
