import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { LoginResponse } from '../models';
import { Observable, catchError, map, tap } from 'rxjs';
import { Router } from '@angular/router';

const URL = environment.API_URL + '/auth';
export interface Profile {
  id?: string;
  username: string;
  website: string;
  avatar_url: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  currentUser!: any;

  constructor(
    private http: HttpClient,
    private router: Router
  ) { }

  get CurrentUser(): any {
    let user = this.currentUser;
    if (!user && localStorage.getItem('current-user')) {
      user = JSON.parse(localStorage.getItem('current-user') || '');
    }
    return user;
  }

  set CurrentUser(user) {
    this.currentUser = user;
    localStorage.setItem('current-user', JSON.stringify(user));
  }

  signIn(email: string, password: string): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${URL}/login`, {
        email,
        password,
      })
      .pipe(
        map(data => {
          localStorage.setItem('organizationId', data.user.organizationId);
          localStorage.setItem('accessToken', data.accessToken);
          return data;
        }),
        catchError((error: any): Observable<never> => {
          return error;
        })
      );
  }

  getUserData() {
    return this.http.get(`${environment.API_URL}/access/me`).pipe(tap(user => { }));
  }

  changePassword(data: { currentPassword?: string | null; newPassword?: string | null }) {
    return this.http.post<{ accessToken: string }>(`${URL}/change-password`, data).pipe(
      tap(data => {
        localStorage.setItem('accessToken', data.accessToken);
      })
    );
  }

  signOut() {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('organizationId');
    localStorage.removeItem('current-user');
    this.CurrentUser = null;
    this.router.navigate(['/'], {
      queryParams: {},
    });
  }
}
