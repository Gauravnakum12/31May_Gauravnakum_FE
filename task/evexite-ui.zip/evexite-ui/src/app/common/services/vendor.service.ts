import { Injectable } from '@angular/core';
import { VendorResponse, CommonPaginationParams, CommonPaginationResponse } from '../models';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class VendorService {
  API_URL = `${environment.API_URL}/vendor`;
  constructor(private http: HttpClient) {}

  getAllVendors(params: CommonPaginationParams = {}) {
    const { page = 1, limit = 10, search = '' } = params;
    return this.http.get<CommonPaginationResponse & { vendors: VendorResponse[] }>(this.API_URL + '/list', {
      params: {
        page: page.toString(),
        limit: limit.toString(),
        search,
      },
    });
  }

  createVendor(vendor: any) {
    return this.http.post<{ message: string; vendors: VendorResponse }>(this.API_URL, vendor);
  }

  getVendorById(vendorId: any) {
    return this.http.get<{ message: string; vendors: VendorResponse }>(this.API_URL + `/${vendorId}`);
  }

  updateVendor(vendor: any) {
    return this.http.put<{ message: string; vendors: VendorResponse }>(this.API_URL + `/${vendor.id}`, vendor);
  }

  deleteVendor(vendorId: string) {
    return this.http.delete<{ message: string; vendors: VendorResponse }>(this.API_URL + `/${vendorId}`);
  }
}
