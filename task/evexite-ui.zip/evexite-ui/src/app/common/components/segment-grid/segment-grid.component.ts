import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { EventSegment, ThemeAreaSegment } from '../../models';
import { ConfirmationService } from 'primeng/api';
import { ThemeService } from '../../services/theme.service';
import { DecimalPipe, NgClass, NgFor, NgIf } from '@angular/common';
import { ActionIconsComponent } from '../action-icons/action-icons.component';
import { SegmentTotalPricePipe } from '../../pipes/segment.total.pipe';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Theme } from '../../models/theme';

@Component({
  selector: 'app-segment-grid',
  standalone: true,
  imports: [NgFor, NgClass, NgIf, ActionIconsComponent, SegmentTotalPricePipe, DecimalPipe, FormsModule, ButtonModule, InputTextModule],
  templateUrl: './segment-grid.component.html',
  styleUrl: './segment-grid.component.scss',
})
export class SegmentGridComponent {
  @ViewChild('newSegmentInput') newSegmentInput!: ElementRef;
  newSegment: null | ThemeAreaSegment | EventSegment = null;
  currentActiveSegment: null | ThemeAreaSegment | EventSegment = null;
  @Input() segments: Array<ThemeAreaSegment | EventSegment> = [];
  @Input() isTheme = false;
  @Output() segmentDeleted = new EventEmitter<string>();
  @Output() saveTheme = new EventEmitter();
  @Output() newSegmentAdded = new EventEmitter<ThemeAreaSegment | EventSegment>();
  @Output() changeCurrentSegment = new EventEmitter<ThemeAreaSegment | null | EventSegment>();
  constructor(
    private confirmationService: ConfirmationService,
    private _themeService: ThemeService
  ) {}

  removeSegment(segment: ThemeAreaSegment | EventSegment) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${segment.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (segment.id) {
          this.segmentDeleted.emit(segment.id);
        }
      },
    });
  }

  editSegment(themeSegment: ThemeAreaSegment | EventSegment) {
    this.currentActiveSegment = themeSegment as ThemeAreaSegment;
    this.changeCurrentSegment.emit(themeSegment as ThemeAreaSegment);
  }

  createNewSegment() {
    if (this.newSegment) {
      this.newSegmentAdded.emit(this.newSegment);
      this.newSegment = null;
      // this.saveTheme.emit();
    }
  }
  addNewSegment() {
    this.newSegment = {
      name: '',
      areaGroups: [],
      image: '',
    };
    setTimeout(() => {
      if (this.newSegmentInput) {
        this.newSegmentInput.nativeElement.focus();
      }
    }, 0);
  }
}
