import { NgClass, NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-action-icons',
  standalone: true,
  imports: [NgIf, NgClass],
  templateUrl: './action-icons.component.html',
  styleUrl: './action-icons.component.scss',
})
export class ActionIconsComponent {
  @Input() icon: 'edit' | 'delete' | 'add' = 'edit';
  @Input() size: 'sm' | 'md' | 'lg' = 'sm';
}
