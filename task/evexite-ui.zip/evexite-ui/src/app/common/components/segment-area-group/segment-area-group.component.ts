import { DecimalPipe, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { EventAreaGroup, EventSegment, ThemeAreaGroup, ThemeAreaSegment } from '../../models';
import { ActionIconsComponent } from '../action-icons/action-icons.component';
import { MultiplyThemeAreaPipe } from '../../pipes/area.total.pipe';
import { FormsModule } from '@angular/forms';
import { UploadMediaService } from '../../services/upload.service';
import { ThemeService } from '../../services/theme.service';
import { DialogModule } from 'primeng/dialog';
import { AreaItemsComponent } from '../area-items/area-items.component';
import { MessageService } from 'primeng/api';
import { EventSegmentService } from '../../services/event.segment.service';
type SegmentType = EventSegment | ThemeAreaSegment;
type AreaType = EventAreaGroup | ThemeAreaGroup;

@Component({
  selector: 'app-segment-area-group',
  standalone: true,
  imports: [
    NgIf,
    ButtonModule,
    InputTextModule,
    NgFor,
    ActionIconsComponent,
    MultiplyThemeAreaPipe,
    FormsModule,
    DecimalPipe,
    DialogModule,
    NgClass,
    AreaItemsComponent,
  ],
  templateUrl: './segment-area-group.component.html',
  styleUrl: './segment-area-group.component.scss',
})
export class SegmentAreaGroupComponent {
  @ViewChild('newAreaInput') newAreaInput!: ElementRef;
  @Input() currentActiveSegment: null | SegmentType = null;
  @Input() eventId: string = '';
  @Input() type: 'Theme' | 'Event' = 'Theme';
  @Output() updateSegment: EventEmitter<SegmentType | null> = new EventEmitter<SegmentType | null>();

  newArea: null | AreaType = null;
  currentActiveArea: null | AreaType = null;
  isShowAreaDialog = false;
  isSegmentImageUploaded = false;
  constructor(
    private _uploadMediaService: UploadMediaService,
    private _themeService: ThemeService,
    private _eventSegmentService: EventSegmentService,
    private messageService: MessageService
  ) {}

  // Helper method to determine if the segment is of type EventSegment
  isEventSegment(segment: SegmentType): segment is EventSegment {
    return (segment as EventSegment).areaGroups !== undefined && this.type === 'Event';
  }

  // Helper method to determine if the segment is of type ThemeAreaSegment
  isThemeAreaSegment(segment: SegmentType): segment is ThemeAreaSegment {
    return (segment as ThemeAreaSegment).areaGroups !== undefined && this.type === 'Theme';
  }

  // Helper method to determine if the segment is of type EventArea
  isEventArea(segment: AreaType): segment is EventAreaGroup {
    return (segment as EventAreaGroup).eventInventories !== undefined && this.type === 'Event';
  }

  // Helper method to determine if the segment is of type ThemeArea
  isThemeArea(segment: AreaType): segment is ThemeAreaGroup {
    return (segment as ThemeAreaGroup).areaInventories !== undefined && this.type === 'Theme';
  }
  addNewArea() {
    this.newArea = {
      name: '',
      areaInventories: [],
      images: [],
      eventInventories: [],
      roundOffAmount: 0,
      notes: '',
    };
    setTimeout(() => {
      if (this.newAreaInput) {
        this.newAreaInput.nativeElement.focus();
      }
    }, 0);
  }
  saveNewArea() {
    if (this.newArea) {
      this.currentActiveSegment?.areaGroups.push(this.newArea as ThemeAreaGroup & EventAreaGroup);
      this.newArea = null;
      this.updateSegment.emit(this.currentActiveSegment);
    }
  }
  openEditArea(area: ThemeAreaGroup) {
    this.currentActiveArea = area;
    this.isShowAreaDialog = true;
  }
  openEditAreaEvent(area: EventAreaGroup) {
    this.currentActiveArea = area;
    this.isShowAreaDialog = true;
  }
  removeArea(area: ThemeAreaGroup) {
    if (area.id) {
      this._themeService.deleteThemeAreaGroup(area.id).subscribe(res => {
        if (this.currentActiveSegment) {
          this.currentActiveSegment.areaGroups = this.currentActiveSegment?.areaGroups.filter(ag => ag.id !== area.id) as ThemeAreaGroup[];
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Area Removed' });
        }
      });
    }
  }

  removeEventArea(area: EventAreaGroup) {
    if (area.id) {
      this._eventSegmentService.deleteEventAreaGroup(area.id).subscribe(res => {
        if (this.currentActiveSegment) {
          this.currentActiveSegment.areaGroups = this.currentActiveSegment?.areaGroups.filter(ag => ag.id !== area.id) as EventAreaGroup[];
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Area Removed' });
        }
      });
    }
  }

  updateArea(area: any) {
    this.currentActiveSegment?.areaGroups.forEach(ag => {
      if (ag.id === area.id) {
        ag = { ...area };
      }
    });
    this.updateSegment.emit(this.currentActiveSegment);
    this.isShowAreaDialog = false;
  }

  closeAreaDialog() {
    this.isShowAreaDialog = false;
  }

  onGroupNameBlur(areaGroup: ThemeAreaGroup | EventAreaGroup) {
    if (!areaGroup.name) {
      areaGroup.name = 'Default Group';
    }
  }

  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImageInventory(file);
    }
  }

  uploadImageInventory(file: File) {
    this.isSegmentImageUploaded = true;
    this._uploadMediaService.uploadFile(file, 'Theme').subscribe(
      response => {
        if (this.currentActiveSegment) {
          this.currentActiveSegment.image = response.url;
          this.updateSegment.emit(this.currentActiveSegment);
        }
        this.isSegmentImageUploaded = false;
      },
      err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
        this.isSegmentImageUploaded = false;
      }
    );
  }
  deleteImage() {
    if (this.currentActiveSegment) {
      this.currentActiveSegment.image = '';
      this.updateSegment.emit(this.currentActiveSegment);
    }
  }
}
