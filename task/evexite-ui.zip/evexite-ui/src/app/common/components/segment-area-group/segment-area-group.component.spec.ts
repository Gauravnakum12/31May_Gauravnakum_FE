import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentAreaGroupComponent } from './segment-area-group.component';

describe('SegmentAreaGroupComponent', () => {
  let component: SegmentAreaGroupComponent;
  let fixture: ComponentFixture<SegmentAreaGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SegmentAreaGroupComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SegmentAreaGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
