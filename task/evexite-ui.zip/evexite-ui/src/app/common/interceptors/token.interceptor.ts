import { Inject, Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { MessageService } from 'primeng/api';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(
    private auth: AuthService,
    private messageService: MessageService
  ) {}
  // Token interceptor for passing accessToken in request
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = localStorage.getItem('accessToken');
    const authRequest = request.clone({
      setHeaders: { Authorization: `Bearer ${token}` },
    });
    return next.handle(authRequest).pipe(
      catchError(err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error : ' + err.error.message || err.message });

        if (!(request.url.includes('login') || request.url.includes('signup'))) {
          if (err instanceof HttpErrorResponse && err.status === 401) {
            // otherwise logout and redirect to login page
            return this.logoutAndRedirect(err);
          }

          // in case of 403 http error (refresh token failed)
          if (err instanceof HttpErrorResponse && err.status === 403) {
            // logout and redirect to login page
            return this.logoutAndRedirect(err);
          }
        }
        // in case of 401 http error
        // if error has status neither 401 nor 403 then just return this error
        return throwError(err);
      })
    );
  }
  private logoutAndRedirect(err: HttpErrorResponse): Observable<HttpEvent<any>> {
    this.auth.signOut();
    return throwError(err);
  }
}
