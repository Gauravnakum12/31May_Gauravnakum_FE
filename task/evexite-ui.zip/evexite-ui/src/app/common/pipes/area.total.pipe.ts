import { Pipe, PipeTransform } from '@angular/core';
import { EventAreaGroup, EventAreaInventory, ThemeAreaGroup, ThemeAreaInventory } from '../models';

@Pipe({
  name: 'areaTotal',
  pure: false,
  standalone: true,
})
export class MultiplyThemeAreaPipe implements PipeTransform {
  transform(areaGroup: ThemeAreaGroup | EventAreaGroup): number | string {
    let inventories: (ThemeAreaInventory | EventAreaInventory)[];

    if ('areaInventories' in areaGroup) {
      inventories = areaGroup.areaInventories;
    } else if ('eventInventories' in areaGroup) {
      inventories = areaGroup.eventInventories;
    } else {
      return ''; // return empty string for invalid input
    }

    let total = 0;
    for (let item of inventories) {
      if (typeof item.rate !== 'number' || typeof item.unit !== 'number') {
        return ''; // return empty string for invalid input
      }
      total += item.rate * item.unit;
    }

    return total;
  }
}
