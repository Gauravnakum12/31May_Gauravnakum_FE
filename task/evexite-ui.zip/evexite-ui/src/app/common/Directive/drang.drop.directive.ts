import { Directive, Output, EventEmitter, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appDnd]', // This selector allows you to use this directive as an attribute [appDnd] in your components,
  standalone: true,
})
export class DndDirective {
  @HostBinding('class.fileover') fileOver: boolean = false; // Binds to the class 'fileover' for styling when a file is being dragged over
  @Output() fileDropped = new EventEmitter<FileList>(); // Emits the event with the list of files dropped

  // Dragover listener to add styling & prevent default behavior
  @HostListener('dragover', ['$event']) onDragOver(evt: DragEvent): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileOver = true;
  }

  // Dragleave listener to remove styling & prevent default behavior
  @HostListener('dragleave', ['$event']) onDragLeave(evt: DragEvent): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileOver = false;
  }

  // Drop listener to handle the dropped files, remove styling, & prevent default behavior
  @HostListener('drop', ['$event']) onDrop(evt: DragEvent): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileOver = false;

    const files = evt.dataTransfer?.files;
    if (files && files.length > 0) {
      this.fileDropped.emit(files);
    }
  }
}
