import { Directive, ElementRef, EventEmitter, HostListener, Output, Renderer2 } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Directive({
  selector: '[appDebounce]',
  standalone: true,
})
export class DebounceDirective {
  @Output() debounce: EventEmitter<string> = new EventEmitter();
  private debouncer: Subject<string> = new Subject();

  constructor(
    private el: ElementRef,
    private renderer: Renderer2
  ) {
    this.debouncer.pipe(debounceTime(500), distinctUntilChanged()).subscribe(value => this.debounce.emit(value));
  }

  @HostListener('input', ['$event'])
  onInput(event: KeyboardEvent) {
    this.debouncer.next((event.target as HTMLInputElement).value);
  }
}
