export interface fetchedUser {
    email: string,
    firstName: string,
    lastName: string,
    phoneNumber: number,
    resetToken: null,
    verificationCode: null,
    verificationCodeExpiry: null;
    verified: boolean,
    registerCode: number,
}
export interface fetchedOrganization {
    location: string,
    name: string,
    createdAt: string,
    _id: string,
    // updatedAt: Date,
}
export interface LoginResponse {
    accessToken: string;
    message: string;
    _id: string,
    createdAt: Date,
    user: fetchedUser[]
}
export interface SignUpResponse {
    organizationLocation?: string;
    organizationName: string;
    email: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    terms: boolean;
    password: string;
    confirmPassword: string;
}

export interface customerResponse {
    message: string;
    totalPage: number,
    limit: number,
    totalRecord: number,
    currentPage: number
    data: customerData[],
}

export interface customerData {
    _id: string
    birthDate: Date
    createdAt: Date
    email: string
    name: string
    organization: string
    phoneNumber: number
}
// ------------------------------------------------------------------polices------------------------------------
export interface policeCreationData {
    name: string,
    description: string,
    isExpirable: boolean,
}


export interface policeResponse {
    message: string,
    data: policeResponseData
}

export interface policeResponseData {
    name: string,
    description: string,
    isExpirable: true,
    organization: string,
    policyFields: [],
    createdAt: Date,
    _id: string,
}
export interface simplePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    placeholder: string,
    value: string
}

export interface complexPolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    value: string[]
}
export interface DatePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
}

export interface PolicyField {
    _id: string,
    createdAt: Date,
    description: string,
    isExpirable: boolean,
    name: string,
    organization: string,
    policyFields: [],
}

export interface PolicyFieldFormData {
    inputType: string;
    label: string;
    instruction_hints: string;
    placeholderData: string;
}










// export interface organizationDetail {
//     message: string;
//     organization: SignUpOrganizationInfo[]
// }
// export interface SignUpOrganizationInfo {
//     _id: string;
//     createdAt: Date;
//     location: string;
//     name: string;
// }