import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormArray, FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators } from '@angular/forms';
import { Message } from 'primeng/api';
import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { policeCreationData, policeResponse, policeResponseData, PolicyField } from '../../../../../finance.model';
import { PolicesService } from '../../../../services/api/polices.service';

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [ButtonModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, Button],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss'
})
export class PoliciesComponent implements OnInit {

  private policyService = inject(PolicesService);
  visible = signal(false);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyData = signal<policeResponse | null>(null);
  policyName: string = '';
  policyId: string = '';

  policyDataFetched = signal<any>('it is blank');

  // ------------------------------card---------------------------------------


  optionData: string[] = [];

  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }
  //-----------------------------------------form------------------------//
  // felidDataForm: FormGroup = new FormGroup({
  //   felidData: new FormArray([this.getUpdatedField()])
  // })
  // getUpdatedField(): FormGroup {
  //   return new FormGroup({
  //     type: new FormControl('text'),
  //     label: new FormControl(''),
  //     placeholderData: new FormControl(''),
  //     instruction_hints: new FormControl(''),
  //   })
  // }

  // UpdatedFieldArray() {
  //   return this.felidDataForm.get('felidData') as FormArray;
  // }

  // addField() {
  //   this.UpdatedFieldArray().push(this.getUpdatedField())
  // }


  // removeField(i: number) {
  //   this.UpdatedFieldArray().removeAt(i);
  // }

  // getUpdatedFieldData() {
  //   console.log(this.felidDataForm.value);
  // }


  // -----------------------------------------------poly-creation---------------------------------
  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [Validators.required, Validators.minLength(10)]),
    expirable: new FormControl(false),
  });

  savepolicies() {
    const sendPolicy: policeCreationData = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    }
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: policeResponse) => {
        this.policyData.set(response);
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName = response.data.name;
        this.policyId = response.data._id;
        console.log(response.data);
        this.policesForm.reset();
      },
      error: (error: any) => { console.error(error) }
    });

  }
  // ----------------------------------------------after-policy-created-------------------------

  // customInputDataType: string[] = ["text", "number", "date", "file", "dropdown", "radio"];
  felidsData: [] = [];

  // --------------------------------------------temple-form--------------------------------------

  cardData: any = [];

  type = 'text';
  label = '';
  instruction_hints = '';
  placeholder = '';

  addCard() {
    const newField: any = {
      label: '',
      type: 'text',
      name: '',
      description: '',
      instruction_hints: '',
      isExpirable: false,
      text: {
        value: '',
        placeholder: '',
      }
    }
    // this.cardData.push(newField);

    this.policyService.postInputField(newField, this.policyId).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response)
      },
      error: (error: any) => { console.error(error) }
    })
  }

  updateField(card: any) {

    const updatedField: any = {
      type: card.type,
      label: card.label,
      isExpirable: false,
      instruction_hints: card.instruction_hints,
      text: {
        value: '',
        placeholder: ""
      }
    }
    const passData = {
      formData: updatedField,
      cardId: card.data._id,
      policyId: this.policyId,
    }

    this.policyService.postUpdatedInputField(passData).subscribe({
      next: (response: any) => {

        this.cardData.push(response)
      },
      error: (error: any) => { console.error(error) }
    })
  }
  deleteField(card: any) {

  }

  // ------------------------------- get policy -------------------------------------//

  getPolicy() {
    this.policyService.getPolicy().subscribe({
      next: (response: any) => {
        console.log(response.data);
        // this.policyDataFetched.set('abcd');
        this.policyDataFetched.set(response.data);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }



  ngOnInit(): void {
    this.getPolicy();
    console.log('111111111');
    console.log(this.policyDataFetched()[1].name);
  }

}



