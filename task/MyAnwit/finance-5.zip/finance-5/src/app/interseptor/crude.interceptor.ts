import { HttpInterceptorFn } from '@angular/common/http';
import { LocalStorageService } from '../services/local-storage.service';
import { inject } from '@angular/core';
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('financeToken');
  const localStorageService = inject(LocalStorageService);
  const organizationId = localStorageService.getItem('id');
  if (token) {
    const clonedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        organizationId: `${organizationId}`,
      },
    });
    return next(clonedReq);
  } else {
    return next(req);
  }
};
