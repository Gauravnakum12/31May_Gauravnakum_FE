import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { PolicesService } from '../../../../../../services/api/polices.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';

import { RippleModule } from 'primeng/ripple';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import {
  BlankPolicyField,
  PoliceFiledResponse,
  Policy,
  PolicyField,
  SinglePoliceResponse,
} from '../policy.model';
import { ErrorInterface } from '../../../../../../finance.model';
@Component({
  selector: 'app-edit-policy',
  standalone: true,
  imports: [
    ButtonModule,
    CommonModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    RippleModule,
    ToastModule,
  ],
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.scss'],
  providers: [MessageService, ConfirmationService],
})
export class EditPolicyComponent implements OnInit {
  policy: Policy | undefined = undefined;
  policyIdFromRoute: string | null = '';
  fieldData: PolicyField[] = [];
  policyName: string | undefined = '';
  policyDescription: string | undefined = '';
  policyExpirable: boolean | undefined = false;
  constructor(
    private policyDataService: PolicesService,
    private activeRoute: ActivatedRoute,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.policyIdFromRoute = this.activeRoute.snapshot.paramMap.get('id');
    this.getPolicy();
  }

  addFiled() {
    const newField: BlankPolicyField = {
      label: '',
      type: 'text',
      name: '',
      description: '',
      instruction_hints: '',
      isExpirable: false,
      text: {
        value: '',
        placeholder: '',
      },
    };

    this.policyDataService
      .postInputField(this.policyIdFromRoute, newField)
      .subscribe({
        next: (response: PoliceFiledResponse) => {
          this.fieldData.push(response.data);
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: response.message,
          });
        },
        error: (error: ErrorInterface) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: error.error.message,
          });
        },
      });
  }
  getPolicy() {
    this.policyDataService.getSinglePolicy(this.policyIdFromRoute).subscribe({
      next: (response: SinglePoliceResponse) => {
        this.policy = response.data;
        this.policyDescription = this.policy?.description;
        this.policyName = this.policy?.name;
        this.policyExpirable = this.policy?.isExpirable;

        const temFelids = this.policy?.policyFields.map(
          (element: PolicyField) => {
            if (element.dropdown) {
              element.options = element.dropdown.values.map((data: string) => {
                return {
                  value: data,
                };
              });
            } else if (element.radio) {
              element.options = element.radio.values.map((data: string) => {
                return {
                  value: data,
                };
              });
            }
            return { ...element };
          },
        );
        this.fieldData.push(...(temFelids as []));
      },
      error: (error: ErrorInterface) => {
        console.error(error);
      },
    });
  }
  addOption(field: PolicyField) {
    if (!field.options) {
      field['options'] = [];
    }
    field.options.push({
      value: '',
    });
  }
  removeOption(field: PolicyField, index: number) {
    field.options?.splice(index, 1);
  }

  updatePolicy() {
    const updatedData = {
      name: this.policyName,
      description: this.policyDescription,
      isExpirable: this.policyExpirable,
    };

    this.policyDataService
      .updatePolicy(this.policyIdFromRoute, updatedData)
      .subscribe({
        next: () => {
          this.router.navigate(['/home/policy']);
        },
        error: (error: ErrorInterface) => {
          console.error('Error updating policy:', error);
        },
      });
  }

  updateField(field: PolicyField) {
    let tempAry = [''];
    if (field.options) {
      tempAry = field.options.map((data: { value: string }) => data.value);
    }

    const updatedField: PolicyField = {
      type: field.type,
      label: field.label,
      isExpirable: false,
      instruction_hints: field.instruction_hints,
      [field.type]: {
        values: tempAry,
      },
    };

    const passData = {
      formData: updatedField,
      fieldId: field._id,
      policyId: this.policyIdFromRoute,
    };

    this.policyDataService.postUpdatedInputField(passData).subscribe({
      next: (response: { message: string }) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          life: 2000,
          detail: response.message,
        });
      },
      error: (error: ErrorInterface) => {
        console.error(error);
      },
    });
  }

  deleteField(field: PolicyField, ind: number) {
    const passData = {
      fieldId: field._id,
      policyId: this.policyIdFromRoute,
    };
    this.policyDataService.deleteInputField(passData).subscribe({
      next: () => {
        this.fieldData.splice(ind, 1);
      },
      error: (error: ErrorInterface) => {
        console.error(error);
      },
    });
  }
}
