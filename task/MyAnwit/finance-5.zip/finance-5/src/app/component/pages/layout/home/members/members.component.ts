import { Component } from '@angular/core';

@Component({
  selector: 'app-members',
  standalone: true,
  imports: [],
  templateUrl: './members.component.html',
  styleUrl: './members.component.scss',
})
export class MembersComponent {}
