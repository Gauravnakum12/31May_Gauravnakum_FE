import { MenuItem } from 'primeng/api';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MenuModule } from 'primeng/menu';
import { AuthService } from '../../../../../services/login.service';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { LocalStorageService } from '../../../../../services/local-storage.service';
@Component({
  selector: 'app-side-nav',
  standalone: true,
  imports: [RouterLink, MenuModule, ButtonModule],
  templateUrl: './side-nav.component.html',
  styleUrl: './side-nav.component.scss',
})
export class SideNavComponent implements OnInit {
  items: MenuItem[] | undefined;
  constructor(
    private authService: AuthService,
    private localStorageService: LocalStorageService,
    private router: Router,
  ) { }

  organiZationInfo = this.authService.organizationInfo();
  UserInfo = this.authService.signInInfo();
  ngOnInit() {
    this.items = [
      {
        label: 'profile',
        items: [
          {
            icon: 'pi pi-user',
            label: `${this.organiZationInfo}`,
          },
          {
            icon: 'pi pi-building-columns',
            label: `${this.organiZationInfo}`,
          },
        ],
      },
    ];
  }

  logOutFunction() {
    this.localStorageService.clear();
    this.router.navigate(['/login']);
  }
}
