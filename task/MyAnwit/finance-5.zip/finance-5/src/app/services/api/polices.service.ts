import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import {
  BlankPolicyField,
  PoliceCreationResponse,
  PoliceFiledResponse,
  PoliceResponse,
  PostUpdatedInputField,
  SinglePoliceResponse,
  UpdatePolicyInfo,
} from '../../component/pages/layout/home/policies/policy.model';

@Injectable({
  providedIn: 'root',
})
export class PolicesService {
  constructor(private http: HttpClient) {}
  private apiUrl = `${environment.api}/policy`;
  getPolicyNameList(): Observable<PoliceResponse> {
    return this.http.get<PoliceResponse>(`${this.apiUrl}/name-list`);
  }
  getSinglePolicy(
    policyIdFromRoute: string | null | undefined,
  ): Observable<SinglePoliceResponse> {
    return this.http.get<SinglePoliceResponse>(
      `${this.apiUrl}/${policyIdFromRoute}`,
    );
  }

  getPolicy(
    page: number,
    limit: number,
    searchTerm: string,
  ): Observable<PoliceResponse> {
    return this.http.get<PoliceResponse>(
      `${this.apiUrl}/list/?page=${page}&limit=${limit}&query=${searchTerm}`,
    );
  }
  updatePolicy(
    policyIdFromRoute: string | null,
    updatedData: UpdatePolicyInfo,
  ) {
    return this.http.put<PoliceResponse>(
      `${this.apiUrl}/${policyIdFromRoute}`,
      updatedData,
    );
  }
  deletePolicy(policyId: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/${policyId}`);
  }

  postNewPolices(policy: {
    name: string;
    description: string;
    isExpirable: boolean;
  }): Observable<PoliceCreationResponse> {
    return this.http.post<PoliceCreationResponse>(this.apiUrl, policy);
  }

  postInputField(
    policyId: string | null,
    InputFieldCard: BlankPolicyField,
  ): Observable<PoliceFiledResponse> {
    return this.http.post<PoliceFiledResponse>(
      `${this.apiUrl}/${policyId}/policyFields`,
      InputFieldCard,
    );
  }

  postUpdatedInputField(
    passData: PostUpdatedInputField,
  ): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      `${this.apiUrl}/${passData.policyId}/policyFields/${passData.fieldId}`,
      passData.formData,
    );
  }

  deleteInputField(
    passData: PostUpdatedInputField,
  ): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.apiUrl}/${passData.policyId}/policyFields/${passData.fieldId}`,
    );
  }
}
