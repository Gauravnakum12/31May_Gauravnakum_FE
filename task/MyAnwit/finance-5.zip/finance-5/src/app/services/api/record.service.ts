import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  RecordResponse,
  sendTempRecord,
} from '../../component/pages/layout/home/records/record.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class RecordService {
  constructor(private http: HttpClient) {}
  private apiUrl = `${environment.api}`;
  getRecord(
    page: number,
    limit: number,
    isMarkable: boolean,
    isRecordExpired: boolean,
    searchTerm: string,
  ): Observable<RecordResponse> {
    return this.http.get<RecordResponse>(
      `${this.apiUrl}/record/list?page=${page}&limit=${limit}&isMarkable=${isMarkable}&isRecordExpired=${isRecordExpired}&query=${searchTerm}`,
    );
  }

  postRecord(sendRecord: sendTempRecord): Observable<RecordResponse> {
    return this.http.post<RecordResponse>(
      ` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record `,
      sendRecord.recordData,
    );
  }

  updateRecord(sendRecord: sendTempRecord): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(
      ` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record/${sendRecord.recordId} `,
      sendRecord.recordData,
    );
  }
  completeRecord(sendRecord: sendTempRecord) {
    return this.http.put<{ message: string }>(
      ` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record/${sendRecord.recordId}/renew `,
      '',
    );
  }
  reNewRecord(sendRecord: sendTempRecord): Observable<RecordResponse> {
    return this.http.put<RecordResponse>(
      ` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record/${sendRecord.recordId}/renew `,
      sendRecord.recordData,
    );
  }

  deleteRecord(
    policyID: string,
    recordId: string,
  ): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      ` ${this.apiUrl}/policy/${policyID}/record/${recordId}`,
    );
  }
  deriveExpiredRecord(Id: string): Observable<string> {
    return this.http.put<string>(`${this.apiUrl}/policyExpireUpdater/`, Id);
  }
}
