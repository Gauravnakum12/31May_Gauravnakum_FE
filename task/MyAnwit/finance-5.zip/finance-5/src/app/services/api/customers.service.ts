import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  CustomerData,
  CustomerPostResponse,
  CustomerResponse,
} from '../../component/pages/layout/home/customers/customer.model';

@Injectable({
  providedIn: 'root',
})
export class CustomersService {
  private apiUrl = `${environment.api}/customer`;
  constructor(private http: HttpClient) {}

  allCustomer(): Observable<CustomerResponse> {
    return this.http.get<CustomerResponse>(this.apiUrl);
  }

  getCustomerData(
    page: number,
    limit: number,
    searchTerm: string,
  ): Observable<CustomerResponse> {
    const url = `${this.apiUrl}/list/?page=${page}&limit=${limit}&query=${searchTerm}`;
    return this.http.get<CustomerResponse>(url);
  }

  postNewCustomer(customer: CustomerData): Observable<CustomerPostResponse> {
    return this.http.post<CustomerPostResponse>(this.apiUrl, customer);
  }

  UpdateCustomer(customer: CustomerData): Observable<CustomerPostResponse> {
    return this.http.put< CustomerPostResponse>(
      `${this.apiUrl}/${customer._id}`,
      customer,
    );
  }

  deleteCustomer(customerId: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(
      `${this.apiUrl}/${customerId}`,
    );
  }
}
