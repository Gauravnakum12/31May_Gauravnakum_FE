import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-XVDQZLY4.js";
import "./chunk-HZLC533R.js";
import "./chunk-PZCNTU33.js";
import "./chunk-E3FELGXA.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-BZ4K52LW.js";
import "./chunk-5NEEF7MH.js";
import "./chunk-DFLDKXZR.js";
import "./chunk-TKZSXASO.js";
import "./chunk-XKUCMAFN.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
