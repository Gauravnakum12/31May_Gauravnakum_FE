import {
  InputText,
  InputTextModule
} from "./chunk-ZP5UWALB.js";
import "./chunk-ALILHFGJ.js";
import "./chunk-BZ4K52LW.js";
import "./chunk-5NEEF7MH.js";
import "./chunk-DFLDKXZR.js";
import "./chunk-TKZSXASO.js";
import "./chunk-XKUCMAFN.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
