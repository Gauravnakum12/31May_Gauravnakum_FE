import {
  Ripple,
  RippleModule
} from "./chunk-PZCNTU33.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-BZ4K52LW.js";
import "./chunk-5NEEF7MH.js";
import "./chunk-DFLDKXZR.js";
import "./chunk-TKZSXASO.js";
import "./chunk-XKUCMAFN.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
