import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RecordService {

  constructor(private http: HttpClient) { }
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/record';

  getRecord(page: number, limit: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/list/?page=${page}&limit=${limit}`);
  }
}
