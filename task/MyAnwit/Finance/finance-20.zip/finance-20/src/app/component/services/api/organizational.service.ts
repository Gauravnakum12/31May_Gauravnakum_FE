import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { fetchedOrganization } from '../../../finance.model';

@Injectable({
  providedIn: 'root'
})
export class organizationDataService {
  constructor(private http: HttpClient) { }
  getOrganizationData(): Observable<fetchedOrganization[]> {
    return this.http.get<fetchedOrganization[]>(`https://ctwvk1rh-3003.inc1.devtunnels.ms/organization`);
  }
}
