import { Component, OnInit, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Message, ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';

import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { DropdownFilterOptions } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { SelectItem } from 'primeng/api';
import { CustomersService } from '../../../../services/api/customers.service';
import { PolicesService } from '../../../../services/api/polices.service';
import { customerData, customerResponse } from '../../../../../finance.model';
import { FloatLabelModule } from 'primeng/floatlabel';
import { RecordService } from '../../../../services/api/record.service';
import { SidebarModule } from 'primeng/sidebar';
@Component({
  selector: 'app-records',
  standalone: true,
  imports: [BreadcrumbModule, RouterModule, CommonModule, ButtonModule, DialogModule, TableModule,  FormsModule, DropdownModule, FloatLabelModule,SidebarModule],
  templateUrl: './records.component.html',
  styleUrl: './records.component.scss'
})
export class RecordsComponent implements OnInit {
  items: MenuItem[] | undefined;
  ngOnInit() {
    this.items = [{ icon: 'pi pi-home', route: '/home' }, { label: 'record', route: '/home/record' },];
    this.loadCustomerData();
    this.getPolicyNameList();
    // console.log(this.selectedCustomers);
  }
  visible: boolean = false;
 
  sidebarVisible(){
 this.visible = true;
  }
  filterCustomers: string | undefined = '';
  selectedCustomers: any;
  customers: any = [];

  filterPolicy: string | undefined = '';
  selectedPolicy: any;
  polices: any = [];

  policyFormData: any;
  cardData: any = [];
  buttonVisible: boolean = false;

  recordData = signal<any>(null);
  totalPage: number = 0;
  currentPage: number = 1;
  limit: number = 10;
  totalRecordDataRecord: number = 0;

  loadRecordLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.getRecord();
  }

  constructor(private CustomerDataService: CustomersService, private policyService: PolicesService,private recordService : RecordService) {
  }

  getRecord() {
    this.recordService.getRecord(this.currentPage, this.limit).subscribe({
      next: (response: any) => {
        // console.log(response.data);
        this.recordData.set(response.data);
        this.totalRecordDataRecord = response.totalRecord;
        this.totalPage = response.totalPage;
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }
  editRecord(record:any){
console.log(record);

  }

  deleteRecordConformation(record:any){
console.log(record);
  }
  private loadCustomerData() {
    this.CustomerDataService.allCustomer().subscribe({
      next: (response: any) => {
        this.customers = response.data
      },
      error: (error: Error) => console.error(error),
    });
  }

  getPolicyNameList() {
    this.policyService.getPolicyNameList().subscribe({
      next: (response: any) => {
        console.log(response.data);
        this.polices = (response.data);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }
  callCustomer() {

  }
  getPolicy() {
 
    // this.cardData = '';
    const singlePolicyId = this.selectedPolicy._id
    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: any) => {
        this.policyFormData = response.data;
        console.log(this.policyFormData);
        let temFelids = this.policyFormData.policyFields.map((element: any) => {
          if (element.dropdown) {
            element.options = element.dropdown.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          else if (element.radio) {
            element.options = element.radio.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          return { ...element };
        })
        // this.cardData = '';
        this.cardData.push(...temFelids);
        console.log()
      },
      error: (error: any) => {
        console.error(error);
      }
    });
    this.buttonVisible = true;
  }

}
