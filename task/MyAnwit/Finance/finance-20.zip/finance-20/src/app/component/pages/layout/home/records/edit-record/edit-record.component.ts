import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-record',
  standalone: true,
  imports: [],
  templateUrl: './edit-record.component.html',
  styleUrl: './edit-record.component.scss'
})
export class EditRecordComponent {

}
