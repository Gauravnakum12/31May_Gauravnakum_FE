import {
  GenericResponse,
  GenericPostResponse,
} from '../../../../../shared/interfaces';

export type PoliceResponse = GenericResponse<Policy>;

export type SinglePoliceResponse = GenericPostResponse<Policy>;
export type PoliceFiledResponse = GenericPostResponse<PolicyField>;

export interface Policy {
  _id: string;
  createdAt: Date;
  updatedAt: Date;
  description: string;
  isExpirable: boolean;
  name: string;
  organization: string;
  policyFields: PolicyField[];
}

export interface PoliceCreationData {
  name: string;
  description: string;
  isExpirable: boolean;
}

export interface PoliceCreationResponse {
  message: string;
  data: Policy;
}

export interface UpdatePolicyInfo {
  name?: string;
  description?: string;
  isExpirable?: boolean;
}

export interface DatePolicyField {
  label: string;
  type: string;
  instruction_hints?: string;
}

export interface SinglePolicyFEtched {
  message: string;
  data: Policy[];
}

export interface BlankPolicyField {
  label: string;
  type: string;
  name: string;
  description: string;
  instruction_hints: string;
  isExpirable: boolean;
  text: {
    value: string;
    placeholder: string;
  };
}

export interface PolicyField {
  _id?: string;
  organization?: string;
  policy?: string;
  createdAt?: string;
  updatedAt?: string;
  instruction_hints?: string;

  text?: {
    placeholder?: string;
    value?: string | number;
  };
  number?: {
    placeholder?: string;
    value?: string | number;
  };
  dropdown?: {
    values: string[];
  };
  radio?: {
    values: string[];
  };
  options?: { value: string }[];
  isExpirable: undefined | boolean;
  label: string;
  type: 'text' | 'number' | 'dropdown' | 'radio';
  recordValue?: string | undefined;
}

export interface PolicyFiledText {
  placeholder?: string;
  value?: string | number;
}

export interface PolicyFiledDropdown {
  values: { value: string }[];
}

export interface PolicyFiledRadio {
  values: string[];
}

export interface PolicyList {
  message: string;
  data: PolicyNameAndId[];
}
export interface PolicyNameAndId {
  _id: string;
  name: string;
}
export interface PostUpdatedInputField {
  formData?: PolicyField;
  fieldId?: string;
  policyId: string | null;
}
