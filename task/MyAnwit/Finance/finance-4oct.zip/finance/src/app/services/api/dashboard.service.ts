import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PolicyList } from '../../component/pages/layout/home/policies/policy.model';
import {
  ExpirationPolicy,
  MostValuableCustomer,
  topPolicy,
} from '../../component/pages/layout/admin-dashboard/dashboard.model';
@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  private apiUrl = environment.api;
  constructor(private http: HttpClient) {}

  getPolicyNameList(): Observable<PolicyList> {
    return this.http.get<PolicyList>(`${this.apiUrl}/name-list`);
  }
  getTopPolicies(
    startDate: string | undefined,
    endDate: string | undefined,
  ): Observable<topPolicy> {
    return this.http.get<topPolicy>(
      `${this.apiUrl}/analytics/topPolices/record/?startDate=${startDate}&endDate=${endDate}`,
    );
  }

  getValuableCustomer(
    page: number,
    limit: number,
    startDate: string | undefined,
    endDate: string | undefined,
  ): Observable<MostValuableCustomer> {
    return this.http.get<MostValuableCustomer>(
      `${this.apiUrl}/analytics/valuableCustomer?page=${page}&limit=${limit}&startDate=${startDate}&endDate=${endDate}`,
    );
  }

  getNearlyPolicyExpire(
    page: number,
    limit: number,
    startDate: string | undefined,
    endDate: string | undefined,
  ): Observable<ExpirationPolicy> {
    return this.http.get<ExpirationPolicy>(
      `${this.apiUrl}/analytics/nearlyPolicyExpire/customer?page=${page}&limit=${limit}&startDate=${startDate}&endDate=${endDate}`,
    );
  }
}
