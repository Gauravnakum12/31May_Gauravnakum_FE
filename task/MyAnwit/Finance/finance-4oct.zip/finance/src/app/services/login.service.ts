import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import {
  User,
  LoginResponse,
  FetchedOrganization,
  SignUpData,
  OrganizationData,
} from '../finance.model';
import { organizationDataService } from './api/organizational.service';
import { Router } from '@angular/router';
import { LocalStorageService } from './local-storage.service';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = `${environment.api}/auth`;
  private organizationService = inject(organizationDataService);
  private localStorageService = inject(LocalStorageService);

  signInInfo = signal<User[]>([]);
  organizationInfo = signal<OrganizationData[]>([]);
  constructor(
    private http: HttpClient,
    private router: Router,
  ) { }



  signIn(credentials: {
    email: string;
    password: string;
  }): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        tap((response: LoginResponse) => {
          if (response.accessToken) {
            this.signInInfo.set(response.user);
            this.localStorageService.setItem('financeToken', response.accessToken);
            this.organizationService.getOrganizationData().subscribe({
              next: (res: FetchedOrganization) => {
                this.organizationInfo.set(res.data);
                this.localStorageService.setItem('id', this.organizationInfo()[0]._id);
              },
              error: (error) => {
                console.error('Error fetching organization data:', error);
              },
            });
          }
        }),
      );
  }

  signUp(userData: SignUpData): Observable<{message:string}> {
    return this.http.post<{message:string}>(`${this.apiUrl}/signup`, userData);
  }

  logout() {
    this.localStorageService.removeItem('financeToken');
  }
  navigateToHome() {
    const token = this.localStorageService.getItem('financeToken');
    if (token) {
      this.router.navigate(['/home/dashboard']);
    }
  }
}
