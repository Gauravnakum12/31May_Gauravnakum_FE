import { Component, OnInit, signal } from '@angular/core';
import { CustomersService } from '../../../../services/api/customers.service';
import { PolicesService } from '../../../../services/api/polices.service';
import { RecordService } from '../../../../services/api/record.service';
import { CustomerResponse } from '../home/customers/customer.model';
import { PoliceResponse, Policy, PolicyField, SinglePoliceResponse,  } from '../home/policies/policy.model';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { DashboardService } from '../../../../services/api/dashboard.service';
import {
  ExpirationPolicyData,
  MostValuableCustomer,
  MostValuableCustomerData,
  TopPoliciesBasicData,
  TopPoliciesBasicOptions,
  TopPolicy,
  TopPolicyData,
} from './dashboard.model';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';

import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';

import { CommonModule, DatePipe } from '@angular/common';
import { keyUpDebounceDirective } from '../../../../directives/keyUp.directive';
import { ChipModule } from 'primeng/chip';
import { ErrorInterface } from '../../../../finance.model';
import { DayLeftPipe } from '../../../../shared/day-left.pipe';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SidebarModule } from 'primeng/sidebar';
import { TooltipModule } from 'primeng/tooltip';
import { Record, RecordFiled, RecordResponse } from '../home/records/record.model'
@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    ChartModule,
    FormsModule,
    CalendarModule,
    TableModule,
    ButtonModule,
    InputTextModule,
    DialogModule,
    CommonModule,
    ChipModule,
    DatePipe,
    DayLeftPipe,
    ProgressSpinnerModule,
    SidebarModule,
    TooltipModule,
  ],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss',
  providers: [ConfirmationService, MessageService, keyUpDebounceDirective,],
})
export class AdminDashboardComponent implements OnInit {
  totalCustomer = signal<number>(0);
  totalPolicy = signal<number>(0);
  totalRecord = signal<number>(0);

  searchPolicyDialogVisibility = signal<boolean>(false);
  mostValuableCustomerDialogVisibility = signal<boolean>(false);
  nearlyExitingPolicyDialogVisibility = signal<boolean>(false);
  searchPolicyStartDate = signal<Date | undefined>(undefined);
  searchPolicyEndDate = signal<Date | undefined>(undefined);
  customerRangeStartDate = signal<Date | undefined>(undefined);
  customerRangeEndDate = signal<Date | undefined>(undefined);
  nearlyExitingPolicyStartDate = signal<Date | undefined>(undefined);
  nearlyExitingPolicyEndDate = signal<Date | undefined>(undefined);
  time = signal<Date | undefined>(undefined);
  basicData = signal<TopPoliciesBasicData | undefined>(undefined);

  mostValuableCustomers = signal<MostValuableCustomerData[]>([]);
  totalMostValuableCustomersTotalRecord = 0;
  mostValuableCustomersTotalPage = 0;
  mostValuableCustomersCurrentPage = 1;
  mostValuableCustomersTotalPagePage = 1;
  mostValuableCustomersLimit = 5;
  mostValuableCustomersTableLoading = signal<boolean>(false);

  nearlyExitingPolicies = signal<ExpirationPolicyData[]>([]);
  nearlyExitingPolicyTotalRecord = 0;
  nearlyExitingPolicyTotalPage = 0;
  nearlyExitingPolicyCurrentPage = 1;
  nearlyExitingPolicyLimit = 5;
  nearlyExitingPoliciesLoading  = signal<boolean>(false);
  recordTitle = signal<string>('Update record');

  sidebarVisible  = signal<boolean>(false);
  buttonVisible = signal<boolean>(false);
  updateRecord = signal<Record | undefined>(undefined);
  policyFormData = signal<Policy | undefined>(undefined);
  fieldsArray: PolicyField[] = [];
  notEdit = signal<boolean>(false);
  reNewBtnVisibility = signal<boolean>(false);


  basicOptions: TopPoliciesBasicOptions | undefined;
  days = ' days';
  today = new Date();
  oneMonthBefore = new Date();
  chartColor_one = '#AC92EB';
  chartColor_two = '#4FC1E8';
  chartColor_three = '#A0D568';
  chartColor_four = '#FFCE54';
  chartColor_five = '#E65261';
  closeSearchBox() {
    this.searchPolicyDialogVisibility.set(false);
    this.mostValuableCustomerDialogVisibility.set(false);
    this.nearlyExitingPolicyDialogVisibility.set(false);
  }

  calculateOneMonthBefore(): void {
    this.oneMonthBefore = new Date();
    this.oneMonthBefore.setMonth(this.oneMonthBefore.getMonth() - 1);

    this.searchPolicyStartDate.set(this.oneMonthBefore);
    this.searchPolicyEndDate.set(this.today);
    this.customerRangeStartDate.set(this.oneMonthBefore);
    this.customerRangeEndDate.set(this.today);
    this.nearlyExitingPolicyStartDate.set(this.oneMonthBefore);
    this.nearlyExitingPolicyEndDate.set(this.today);
  }

  constructor(
    private customerService: CustomersService,
    private policyService: PolicesService,
    private recordService: RecordService,
    private dashboardService: DashboardService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
  ) { }

  ngOnInit(): void {
    this.getCustomerData();
    this.getPolicyData();
    this.getRecord();
    this.calculateOneMonthBefore();
    this.basicOptions = {
      plugins: {
        legend: {
          labels: {
            color: this.chartColor_one,
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: this.chartColor_two,
          },
          grid: {
            color: this.chartColor_three,
            drawBorder: false,
          },
        },
        x: {
          ticks: {
            color: this.chartColor_four,
          },
          grid: {
            color: this.chartColor_four,
            drawBorder: false,
          },
        },
      },
    };
    this.searchPolicy();
  }

  loadMostValuableCustomersLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.mostValuableCustomersCurrentPage = page;
    this.mostValuableCustomersLimit = event.rows || 20;
    this.searchMostValuableCustomer();
  }

  loadMostNearlyPolicyExpirationLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.nearlyExitingPolicyCurrentPage = page;
    this.nearlyExitingPolicyLimit = event.rows || 10;
    this.searchPolicyExpiration();
  }

  showCustomerSearchDialog() {
    this.mostValuableCustomerDialogVisibility.set(true);
  }

  showNearlyExitingPolicyDialog() {
    this.nearlyExitingPolicyDialogVisibility.set(true);
  }

  showPolicyDialogVisibility() {
    this.searchPolicyDialogVisibility.set(true);
  }

  searchPolicy() {
    const startDate = this.searchPolicyStartDate()?.toISOString();
    const endDate = this.searchPolicyEndDate()?.toISOString();

    this.dashboardService.getTopPolicies(startDate, endDate).subscribe({
      next: (response: TopPolicy) => {
        this.basicData.set({
          labels: [],
          datasets: [
            {
              label: 'polices',
              data: [],
              backgroundColor: [
                'rgba(255, 159, 64, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
              ],
              borderColor: [
                'rgb(255, 159, 64)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
              ],
              borderWidth: 1,
            },
          ],
        })
        response.data.forEach((policy: TopPolicyData) => {
          this.basicData()?.labels.push(policy.name);
          this.basicData()?.datasets[0].data.push(policy.subscribedCount);
        });
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
    this.closeSearchBox();
  }

  searchMostValuableCustomer() {
    
    this.mostValuableCustomersTableLoading.set(true);
    const startDate = this.customerRangeStartDate()?.toISOString();
    const endDate = this.customerRangeEndDate()?.toISOString();

    this.dashboardService
      .getValuableCustomer(
        this.mostValuableCustomersCurrentPage,
        this.mostValuableCustomersLimit,
        startDate,
        endDate,
      )
      .subscribe({
        next: (response: MostValuableCustomer) => {
          this.mostValuableCustomers.set(response.data);
          this.totalMostValuableCustomersTotalRecord = response.totalRecord;
          this.mostValuableCustomersTotalPage = response.totalPages;
          this.mostValuableCustomersTableLoading.set(false);
        },
        error: (error: ErrorInterface) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
          this.mostValuableCustomersTableLoading.set(false);
        },
      });
    this.closeSearchBox();
  }
  searchPolicyExpiration() {
    this.nearlyExitingPoliciesLoading.set(true);
    const startDate = this.nearlyExitingPolicyStartDate()?.toISOString();
    const endDate = this.nearlyExitingPolicyEndDate()?.toISOString();

    this.dashboardService
      .getNearlyPolicyExpire(
        this.nearlyExitingPolicyCurrentPage,
        this.nearlyExitingPolicyLimit,
        startDate,
        endDate,
      )
      .subscribe({
        next: (response) => {
          this.nearlyExitingPolicies.set(response.data);
 
          this.nearlyExitingPolicyTotalRecord = response.totalRecord;
          this.nearlyExitingPolicyTotalPage = response.totalPages;
          this.nearlyExitingPoliciesLoading.set(false);
        },
        error: (error: ErrorInterface) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
          this.nearlyExitingPoliciesLoading.set(false);
        },
      });
    this.closeSearchBox();
  }

  openEditRecordSidebar(tempRecord: Record) {
    this.sidebarVisible.set(true);
    this.buttonVisible.set(true);

    this.updateRecord.set(tempRecord);
    const singlePolicyId = tempRecord.policy_info._id;

    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: SinglePoliceResponse) => {
        this.policyFormData.set(response.data);

        this.fieldsArray = [];
        const tempFields = this.policyFormData()?.policyFields.map(
          (element: PolicyField) => {
            element['recordValue'] = '';

            if (element.dropdown) {
              element.options = element.dropdown.values.map((data: string) => ({
                value: data,
              }));
            } else if (element.radio) {
              element.options = element.radio.values.map((data: string) => ({
                value: data,
              }));
            }

            const matchedRecord = tempRecord.records.find(
              (record: RecordFiled) => record.policyFieldId === element._id,
            );
            if (matchedRecord) {
              element.recordValue = matchedRecord.record;
            }
            return { ...element };
          },
        );

        this.fieldsArray.push(...tempFields || []);
      },
      error: (error:ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Confirmed',
          detail: `${error.error.message}`,
        });;
      },
    });
  }

  deleteRecord(record: Record) {
    const recordId = record.recordId;
    const policyId = record.policy_info._id;

    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete record?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.recordService.deleteRecord(policyId, recordId).subscribe({
          next: (response: { message: string }) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Confirmed',
              detail: `${response.message}`,
            });
            this.getRecord();
          },
          error: (error: ErrorInterface) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Confirmed',
              detail: `${error.error.message}`,
            });
          },
        });
      },
    });
  }

  reNewRecord() {
    this.recordTitle.set( 'Renew record');
    this.reNewBtnVisibility.set(true);
    this.fieldsArray = [];
    const tempFields =
      this.policyFormData()?.policyFields.map((element: PolicyField) => {
        element['recordValue'] = '';

        if (element.dropdown) {
          element.options = element.dropdown.values.map((data: string) => ({
            value: data,
          }));
        } else if (element.radio) {
          element.options = element.radio.values.map((data: string) => ({
            value: data,
          }));
        }
        return { ...element };
      }) || [];

    this.fieldsArray.push(...tempFields);
  }

  getCustomerData() {
    this.customerService.getCustomerData(1, 1, '').subscribe({
      next: (response: CustomerResponse) => {
        this.totalCustomer.set(response.totalRecord);
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }

  getPolicyData() {
    this.policyService.getPolicy(1, 1, '').subscribe({
      next: (response: PoliceResponse) => {
        this.totalPolicy.set(response.totalRecord);
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }

  getRecord() {
    this.recordService.getRecord(1, 10, false, false, '').subscribe({
      next: (response: RecordResponse) => {
        this.totalRecord.set(response.totalRecord);
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }
}