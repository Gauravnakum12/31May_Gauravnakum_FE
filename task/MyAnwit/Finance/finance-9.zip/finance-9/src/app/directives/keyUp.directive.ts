import {
  Directive,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
  OnInit,
  HostListener,
} from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

@Directive({
  selector: '[keyUpDebounce]',
})
export class keyUpDebounceDirective implements OnInit, OnDestroy {
  @Input() public debounceTime = 2000;
  @Output() public input: EventEmitter<string> = new EventEmitter<string>();

  private emitEvent$: Subject<string> = new Subject<string>();
  private subscription$: Subject<void> = new Subject<void>();

  ngOnInit(): void {
    this.emitEvent$
      .pipe(
        debounceTime(this.debounceTime),
        distinctUntilChanged(),
        takeUntil(this.subscription$),
      )
      .subscribe((value) => this.emitChange(value));
  }

  @HostListener('input', ['$event'])
  onInput(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.emitEvent$.next(value);
  }

  private emitChange(value: string): void {
    this.input.emit(value);
  }

  ngOnDestroy(): void {
    this.subscription$.next();
    this.subscription$.complete();
  }
}
