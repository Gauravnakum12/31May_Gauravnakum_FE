import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dayLeft',
  standalone: true
})
export class DayLeftPipe implements PipeTransform {
  transform(futureDate: Date): string {
    if (!futureDate) return '-';
    const start = new Date();
    const end = new Date(futureDate);
    
    let years = end.getFullYear() - start.getFullYear();
    let months = end.getMonth() - start.getMonth();
    let days = end.getDate() - start.getDate();

    if (days < 0) {
      months--;
      const lastMonth = new Date(end.getFullYear(), end.getMonth(), 0);
      days += lastMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const parts = [];
    if (years > 0) parts.push(`${years} year`);
    if (months > 0) parts.push(`${months} month`);
    if (days > 0) parts.push(`${days} day`);

    return parts.length ? parts.join(', ') + ' left.' : 'expired';
  }
}
