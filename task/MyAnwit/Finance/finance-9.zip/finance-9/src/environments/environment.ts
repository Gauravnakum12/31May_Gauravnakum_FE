export const environment = {
  production: false,
  // api: 'https://ctwvk1rh-3001.inc1.devtunnels.ms',
  api: 'http://localhost:3001',
};
