import {
  InputText,
  InputTextModule
} from "./chunk-V5B36RI7.js";
import "./chunk-5VYWT3K4.js";
import "./chunk-MYKTRJAA.js";
import "./chunk-NBVZSBCN.js";
import "./chunk-5PANLZQA.js";
import "./chunk-WIWJHGHP.js";
import "./chunk-I7WWHBRH.js";
import "./chunk-54OPR74L.js";
import "./chunk-XKUCMAFN.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
