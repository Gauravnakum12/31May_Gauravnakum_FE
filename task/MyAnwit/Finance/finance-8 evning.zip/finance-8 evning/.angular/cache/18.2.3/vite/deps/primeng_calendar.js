import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-4LUOVNGH.js";
import "./chunk-E2IOBLWF.js";
import "./chunk-2HNLBTXY.js";
import "./chunk-XV4MV2YL.js";
import "./chunk-2BD4IFTM.js";
import "./chunk-GLOA2BFR.js";
import "./chunk-AKXNL5O7.js";
import "./chunk-7BISPAD7.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-QZDPIIER.js";
import "./chunk-5VYWT3K4.js";
import "./chunk-MYKTRJAA.js";
import "./chunk-76JZGST6.js";
import "./chunk-NBVZSBCN.js";
import "./chunk-5PANLZQA.js";
import "./chunk-WIWJHGHP.js";
import "./chunk-I7WWHBRH.js";
import "./chunk-54OPR74L.js";
import "./chunk-XKUCMAFN.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
