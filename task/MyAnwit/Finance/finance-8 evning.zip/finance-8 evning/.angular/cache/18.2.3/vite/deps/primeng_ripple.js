import {
  Ripple,
  RippleModule
} from "./chunk-7BISPAD7.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-MYKTRJAA.js";
import "./chunk-NBVZSBCN.js";
import "./chunk-5PANLZQA.js";
import "./chunk-WIWJHGHP.js";
import "./chunk-I7WWHBRH.js";
import "./chunk-54OPR74L.js";
import "./chunk-XKUCMAFN.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
