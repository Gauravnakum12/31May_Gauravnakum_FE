import {
  GenericResponse,
  GenericPostResponse,
} from '../../../../../shared/interfaces';

export type PoliceResponse = GenericResponse<Policy>;
export type PolicyList = GenericResponse<PolicyNameAndId>;

export type SinglePoliceResponse = GenericPostResponse<Policy>;
export type PoliceFiledResponse = GenericPostResponse<PolicyField>;
export type PoliceCreationResponse = GenericPostResponse<Policy>;

export interface Policy {
  _id: string;
  createdAt: Date;
  updatedAt: Date;
  description: string;
  isExpirable: boolean;
  name: string;
  organization: string;
  policyFields: PolicyField[];
}

export interface UpdatePolicyInfo {
  name?: string;
  description?: string;
  isExpirable?: boolean;
}

export interface DatePolicyField {
  label: string;
  type: string;
  instruction_hints?: string;
}

export interface PolicyField {
  _id?: string;
  organization?: string;
  policy?: string;
  createdAt?: string;
  updatedAt?: string;
  instruction_hints?: string;

  text?: {
    placeholder?: string;
    value?: string | number;
  };
  number?: {
    placeholder?: string;
    value?: string | number;
  };
  dropdown?: {
    values: string[];
  };
  radio?: {
    values: string[];
  };
  options?: { value: string }[];
  isExpirable: undefined | boolean;
  label: string;
  name?: string;
  description?: string;
  type: 'text' | 'number' | 'dropdown' | 'radio';
  recordValue?: string | undefined;
}

export interface PolicyFiledText {
  placeholder?: string;
  value?: string | number;
}

export interface PolicyFiledDropdown {
  values: { value: string }[];
}

export interface PolicyFiledRadio {
  values: string[];
}

export interface PolicyNameAndId {
  _id: string;
  name: string;
}
export interface PostUpdatedInputField {
  formData?: PolicyField;
  fieldId?: string;
  policyId: string | null;
}
