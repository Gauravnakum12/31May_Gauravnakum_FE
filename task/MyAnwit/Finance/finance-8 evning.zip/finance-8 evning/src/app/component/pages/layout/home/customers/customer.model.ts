import {
  GenericResponse,
  GenericPostResponse,
} from '../../../../../shared/interfaces';

export type CustomerResponse = GenericResponse<CustomerData>;
export type CustomerPostResponse = GenericPostResponse<CustomerData>;

export interface CustomerData {
  _id: string;
  birthDate: Date;
  createdAt: Date;
  email: string;
  name: string;
  organization: string;
  phoneNumber: number;
}
