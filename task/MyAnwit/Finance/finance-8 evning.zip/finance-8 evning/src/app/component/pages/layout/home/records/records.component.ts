import { Component, OnInit, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';
import { ConfirmationService, MessageService } from 'primeng/api';

import { TooltipModule } from 'primeng/tooltip';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { FormsModule } from '@angular/forms';
import { DropdownChangeEvent, DropdownModule } from 'primeng/dropdown';

import { CustomersService } from '../../../../../services/api/customers.service';
import { PolicesService } from '../../../../../services/api/polices.service';
import { FloatLabelModule } from 'primeng/floatlabel';
import { RecordService } from '../../../../../services/api/record.service';
import { SidebarModule } from 'primeng/sidebar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { CustomerData, CustomerResponse } from '../customers/customer.model';
import {
  Policy,
  PolicyField,
  PolicyList,
  PolicyNameAndId,
  SinglePoliceResponse,
} from '../policies/policy.model';
import { Record, RecordFiled, RecordResponse } from './record.model';
import { SplitButtonModule } from 'primeng/splitbutton';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { TabMenuModule } from 'primeng/tabmenu';
import { InputTextModule } from 'primeng/inputtext';
import { LocalStorageService } from '../../../../../services/local-storage.service';
import { ErrorInterface } from '../../../../../finance.model';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ChipModule } from 'primeng/chip';
import { DayLeftPipe } from '../../../../../shared/day-left.pipe';

@Component({
  selector: 'app-records',
  standalone: true,
  imports: [
    BreadcrumbModule,
    RouterModule,
    CommonModule,
    ButtonModule,
    DialogModule,
    TableModule,
    FormsModule,
    DropdownModule,
    FloatLabelModule,
    SidebarModule,
    TooltipModule,
    ConfirmDialogModule,
    ToastModule,
    RippleModule,
    IconFieldModule,
    InputIconModule,
    SplitButtonModule,
    ConfirmPopupModule,
    TabMenuModule,
    InputIconModule,
    IconFieldModule,
    InputTextModule,
    FormsModule,
    ProgressSpinnerModule,
    ChipModule,
    DayLeftPipe
  ],
  templateUrl: './records.component.html',
  styleUrl: './records.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class RecordsComponent implements OnInit {
  tableLoading = signal<boolean>(false);
  items: MenuItem[] | undefined;
  splitButtonItems: MenuItem[] | undefined;
  tabMenuItems: MenuItem[] | undefined;
  recordTitle = 'Create record';
  updateRecord = signal<Record | undefined>(undefined);
  notEdit = signal<boolean>(false);
  reNewBtnVisibility = false;
  isMarkable = false;
  isRecordExpired = false;
  activeRecordTab: MenuItem | undefined;

  filterCustomers: string | undefined = '';
  selectedCustomer: CustomerData | undefined;
  customers: CustomerData[] = [];
  createREcordVisibility = true;
  filterPolicy: string | undefined = '';
  selectedPolicy: Policy | undefined;
  polices: PolicyNameAndId[] = [];
  visible = false;

  policyFormData = signal<Policy | undefined>(undefined);
  fieldsArray: PolicyField[] = [];
  buttonVisible = false;
  days = ' days';

  recordData = signal<Record[]>([]);
  totalPage = 0;
  currentPage = 1;
  limit = 10;
  totalRecordData = 0;
  spinerLoad = false;
  ngOnInit() {
    this.items = [
      { icon: 'pi pi-home', route: '/home' },
      { label: 'records', route: '/home/record' },
    ];

    this.tabMenuItems = [
      {
        label: 'Active',
        command: () => {
          this.isRecordExpired = false;
          this.isMarkable = false;
          this.getRecord('');
          this.notEdit.set(false);
        },
      },
      {
        label: 'Reviewed ',
        command: () => {
          this.isRecordExpired = false;
          this.isMarkable = true;
          this.getRecord('');
          this.notEdit.set(true);
        },
      },
      {
        label: 'Expired',
        command: () => {
          this.isMarkable = false;
          this.isRecordExpired = true;
          this.getRecord('');
          this.notEdit.set(false);
        },
      },
    ];

    this.loadCustomerData();
    this.getPolicyNameList();
    this.activeRecordTab = this.tabMenuItems[0];
    this.deriveExpiredRecord();
  }


  constructor(
    private CustomerDataService: CustomersService,
    private policyService: PolicesService,
    private recordService: RecordService,
    private router: Router,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private localStorageService: LocalStorageService,
  ) {
    this.splitButtonItems = [
      {
        label: 'complete & Renew ',
        icon: 'pi pi-check',
        command: () => {
          this.confirmReNewRecord();
        },
      },
    ];
  }

  sidebarVisible() {
    this.recordTitle = 'Create record';
    this.visible = true;
    this.createREcordVisibility = true;
    this.fieldsArray = [];
    this.buttonVisible = false;
  }

  deriveExpiredRecord() {
    const OrganizationId = this.localStorageService.getItem('id') || '';
    this.recordService.deriveExpiredRecord(OrganizationId).subscribe({
      error: (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error}`,
        });
      },
    });
  }

  loadRecordLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.getRecord('');
  }

  onSearchInput(event: Event): void {
    const searchValue = (event.target as HTMLInputElement).value;
    this.getRecord(searchValue);
  }

  confirmCompleteRecord(event: Event) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'Do you want Mark as a complete this record?',
      header: 'RenewRecord Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.completeRecord();
      },
    });
  }

  completeRecord() {
    const sendRecord = {
      customerId: this.updateRecord()?.customer_info._id,
      policyId: this.updateRecord()?.policy_info._id,
      recordId: this.updateRecord()?.recordId,
    };
    this.recordService.completeRecord(sendRecord).subscribe({
      next: (response: { message: string }) => {
        this.visible = false;
        this.getRecord('');
        this.messageService.add({
          severity: 'success',
          summary: 'Confirmed',
          detail: `${response.message}`,
        });
      },
      error: (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error}`,
        });
      },
    });
  }
  confirmReNewRecord() {
    this.confirmationService.confirm({
      message: 'Do you want Renew this record?',
      header: 'RenewRecord Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.reNewRecord();
      },
    });
  }

  getRecord(searchTerm: string) {
    this.tableLoading.set(true);
    this.recordService
      .getRecord(
        this.currentPage,
        this.limit,
        this.isMarkable,
        this.isRecordExpired,
        searchTerm,
      )
      .subscribe({
        next: (response: RecordResponse) => {
          this.recordData.set(response.data);
          this.spinerLoad = false;
          this.totalRecordData = response.totalRecord;
          this.totalPage = response.totalPages;
          this.tableLoading.set(false);
        },
        error: (error: ErrorInterface) => {
          this.tableLoading.set(false)
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: `${error.error.message}`,
          });
        },
      });
  }

  deleteRecord(record: Record) {
    const recordId = record.recordId;
    const policyId = record.policy_info._id;

    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete record?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.recordService.deleteRecord(policyId, recordId).subscribe({
          next: (response: { message: string }) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Confirmed',
              detail: `${response.message}`,
            });
            this.getRecord('');
          },
          error: (error: ErrorInterface) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Confirmed',
              detail: `${error.error.message}`,
            });
          },
        });
      },
    });
  }

  reNewRecord() {
    this.recordTitle = 'Renew record';
    this.reNewBtnVisibility = true;
    this.fieldsArray = [];
    const tempFields =
      this.policyFormData()?.policyFields.map((element: PolicyField) => {
        element['recordValue'] = '';

        if (element.dropdown) {
          element.options = element.dropdown.values.map((data: string) => ({
            value: data,
          }));
        } else if (element.radio) {
          element.options = element.radio.values.map((data: string) => ({
            value: data,
          }));
        }
        return { ...element };
      }) || [];

    this.fieldsArray.push(...tempFields);
  }

  openEditRecordSidebar(tempRecord: Record) {
    this.recordTitle = 'Update record';
    this.visible = true;
    this.buttonVisible = true;
    this.createREcordVisibility = false;

    this.updateRecord.set(tempRecord);
    const singlePolicyId = tempRecord.policy_info._id;

    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: SinglePoliceResponse) => {
        this.policyFormData.set(response.data);

        this.fieldsArray = [];
        const tempFields = this.policyFormData()?.policyFields.map(
          (element: PolicyField) => {
            element['recordValue'] = '';

            if (element.dropdown) {
              element.options = element.dropdown.values.map((data: string) => ({
                value: data,
              }));
            } else if (element.radio) {
              element.options = element.radio.values.map((data: string) => ({
                value: data,
              }));
            }

            const matchedRecord = tempRecord.records.find(
              (record: RecordFiled) => record.policyFieldId === element._id,
            );
            if (matchedRecord) {
              element.recordValue = matchedRecord.record;
            }
            return { ...element };
          },
        );

        this.fieldsArray.push(...tempFields || []);
      },
      error: (error:ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Confirmed',
          detail: `${error.error.message}`,
        });;
      },
    });
  }
  recordSubmit() {
    const tempRecord = this.fieldsArray.map((element: PolicyField) => {
      return {
        policyFieldId: element._id,
        record: element.recordValue,
      };
    });
    const sendRecord = {
      customerId: this.selectedCustomer?._id,
      policyId: this.selectedPolicy?._id,
      recordData: {
        records: tempRecord,
      },
    };

    this.recordService.postRecord(sendRecord).subscribe({
      next: (response: RecordResponse) => {
        this.visible = false;
        this.getRecord('');
        this.fieldsArray = [];
        this.messageService.add({
          severity: 'success',
          summary: 'Confirmed',
          detail: `${response.message}`,
        });
      },
      error: (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Confirmed',
          detail: `${error.error.message}`,
        });
      },
    });
  }

  submitUpdatedRecord() {
    const tempRecord = this.fieldsArray.map((element: PolicyField) => {
      return {
        policyFieldId: element._id,
        record: element.recordValue,
      };
    });
    const sendRecord = {
      customerId: this.updateRecord()?.customer_info._id,
      policyId: this.updateRecord()?.policy_info._id,
      recordId: this.updateRecord()?.recordId,
      recordData: {
        records: tempRecord,
      },
    };
    this.recordService.updateRecord(sendRecord).subscribe({
      next: (response: { message: string }) => {
        this.visible = false;
        this.getRecord('');
        this.messageService.add({
          severity: 'success',
          summary: 'Confirmed',
          detail: `${response.message}`,
        });
      },
      error: (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error}`,
        });
      },
    });
  }

  submitRenewedRecord() {
    const tempRecord = this.fieldsArray.map((element: PolicyField) => {
      return {
        policyFieldId: element._id,
        record: element.recordValue,
      };
    });
    const sendRecord = {
      customerId: this.updateRecord()?.customer_info._id,
      policyId: this.updateRecord()?.policy_info._id,
      recordId: this.updateRecord()?.recordId,
      recordData: {
        records: tempRecord,
      },
    };
    this.recordService.reNewRecord(sendRecord).subscribe({
      next: (response: RecordResponse) => {
        this.visible = false;
        this.getRecord('');
        this.messageService.add({
          severity: 'success',
          summary: 'Confirmed',
          detail: `${response.message}`,
        });
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error}`,
        });
      },
    });
    this.reNewBtnVisibility = false;
  }

  private loadCustomerData() {
    this.CustomerDataService.allCustomer().subscribe({
      next: (response: CustomerResponse) => {
        this.customers = response.data;
      },
      error: (error: ErrorInterface) =>
        this.messageService.add({
          severity: 'error',
          summary: 'Confirmed',
          detail: `${error.error.message}`,
        }),
    });
  }
  getPolicyNameList() {
    this.policyService.getPolicyNameList().subscribe({
      next: (response: PolicyList) => {
        this.polices = response.data;
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error.error.description}`,
        });
      },
    });
  }
  callCustomer(event: DropdownChangeEvent) {
    this.selectedCustomer = event.value;
  }
  getPolicy() {
    this.fieldsArray = [];
    const singlePolicyId = this.selectedPolicy?._id;
    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: SinglePoliceResponse) => {
        this.policyFormData.set(response.data);
        const temFelids = this.policyFormData()?.policyFields.map(
          (element: PolicyField) => {
            if (element.dropdown) {
              element.options = element.dropdown.values.map((data: string) => {
                return {
                  value: data,
                };
              });
            } else if (element.radio) {
              element.options = element.radio.values.map((data: string) => {
                return {
                  value: data,
                };
              });
            }
            return { ...element };
          },
        );

        this.fieldsArray.push(...temFelids || []);
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: `${error.error.message}`,
        });
      },
    });
    this.buttonVisible = true;
  }
}
