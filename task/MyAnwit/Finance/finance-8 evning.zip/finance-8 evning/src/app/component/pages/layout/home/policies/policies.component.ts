import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { PolicesService } from '../../../../../services/api/polices.service';
import { DropdownModule } from 'primeng/dropdown';
import { Router } from '@angular/router';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import {
  Message,
  ConfirmationService,
  MessageService,
  MenuItem,
} from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { PoliceCreationResponse, PoliceResponse, Policy } from './policy.model';
import { DeleteError } from '../../../../../shared/interfaces';
import { ErrorInterface } from '../../../../../finance.model';
import { SidebarModule } from 'primeng/sidebar';

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [
    RippleModule,
    TableModule,
    ButtonModule,
    DropdownModule,
    CommonModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    FloatLabelModule,
    DialogModule,
    ReactiveFormsModule,
    DatePipe,
    MessagesModule,
    Button,
    ConfirmDialogModule,
    ToastModule,
    IconFieldModule,
    InputIconModule,
    SidebarModule,
  ],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class PoliciesComponent implements OnInit {
  items: MenuItem[] | undefined;
  constructor(
    private router: Router,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
  ) { }

  ngOnInit(): void {
    this.items = [
      { icon: 'pi pi-home', route: '/home' },
      { label: 'policies', route: '/home/policy' },
    ];
    this.getPolicy('');
  }

  private policyService = inject(PolicesService);
  visible = signal(false);
  totalPoliciesRecord = signal<number>(0);
  policyDataFetched = signal<Policy[]>([]);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyName = signal<string>('')
  policyId = signal<string>('')
  totalPage = 0;
  currentPage = 1;
  limit = 10;

  onSearchInput(event: Event): void {
    const searchValue = (event.target as HTMLInputElement).value;
    this.getPolicy(searchValue);
  }
  loadPolicyLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.getPolicy('');
  }

  getPolicy(searchTerm: string) {
    this.policyService
      .getPolicy(this.currentPage, this.limit, searchTerm)
      .subscribe({
        next: (response: PoliceResponse) => {
      
          this.policyDataFetched.set(response.data);
          this.totalPoliciesRecord.set(response.totalRecord);
          this.totalPage = response.totalPages;
        },
        error: (error: ErrorInterface) => {
          this.messageService.add({
            severity: 'error',
            summary: '',
            detail: `${error.error.message}`,
          });
        },
      });
  }

  editPolicy(policy: Policy) {
    const policyId = policy._id;
    this.router.navigate([`/home/policy/${policyId}`]);
  }

  deletePolicyConformation(policy: Policy) {
    const policyId = policy._id;
    this.confirmationService.confirm({
      message: `Are you sure that you want to Delete ${policy.name}?`,
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.policyService.deletePolicy(policyId).subscribe({
          next: (response: { message: string }) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Delete',
              detail: `${response.message}`,
            });
            this.getPolicy('');
          },
          error: (error: DeleteError) => {
            this.messageService.add({
              severity: 'error',
              summary: '',
              detail: `${error.error.message}`,
            });
          },
        });
      },
    });
  }

  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }
  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [
      Validators.required,
      Validators.minLength(10),
    ]),
    expirable: new FormControl(false),
  });
  savepolicies() {
    const sendPolicy = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    };
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: PoliceCreationResponse) => {
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName.set(response.data.name);
        this.policyId.set(response.data._id);
        this.policesForm.reset();
        this.router.navigate([`/home/policy/${this.policyId}`]);
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: '',
          detail: `${error.error.message}`,
        });
      },
    });
  }
}
