import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FetchedOrganization } from '../../finance.model';
import { environment } from '../../../environments/environment';
@Injectable({
  providedIn: 'root',
})
export class organizationDataService {
  private apiUrl = environment.api;
  constructor(private http: HttpClient) { }
  getOrganizationData(): Observable<FetchedOrganization> {
    return this.http.get<FetchedOrganization>(
      `${this.apiUrl}`,
    );
  }
}
