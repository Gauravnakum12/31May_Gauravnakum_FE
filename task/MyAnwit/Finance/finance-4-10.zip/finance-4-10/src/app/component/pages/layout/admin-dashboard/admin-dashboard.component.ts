import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../../../../services/api/customers.service';
import { PolicesService } from '../../../../services/api/polices.service';
import { RecordService } from '../../../../services/api/record.service';
import { CustomerResponse } from '../home/customers/customer.model';
import { PoliceResponse } from '../home/policies/policy.model';
import { RecordResponse } from '../home/records/record.model';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { DashboardService } from '../../../../services/api/dashboard.service';
import {
  ExpirationPolicyData,
  MostValuableCustomer,
  MostValuableCustomerData,
  TopPoliciesBasicData,
  TopPoliciesBasicOptions,
  TopPolicy,
} from './dashboard.model';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';

import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';

import { CommonModule, DatePipe } from '@angular/common';
import { keyUpDebounceDirective } from '../../../../directives/keyUp.directive';
import { ChipModule } from 'primeng/chip';
import { ErrorInterface } from '../../../../finance.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    ChartModule,
    FormsModule,
    CalendarModule,
    TableModule,
    ButtonModule,
    InputTextModule,
    DialogModule,
    CommonModule,
    DatePipe,
    ChipModule,
  ],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss',
  providers: [ConfirmationService, MessageService, keyUpDebounceDirective],
})
export class AdminDashboardComponent implements OnInit {
  searchPolicyDialogVisibility = false;
  mostValuableCustomerDialogVisibility = false;
  nearlyExitingPolicyDialogVisibility = false;
  days = ' days';

  closeSearchBox() {
    this.searchPolicyDialogVisibility = false;
    this.mostValuableCustomerDialogVisibility = false;
    this.nearlyExitingPolicyDialogVisibility = false;
  }

  chartColor_one = '#AC92EB';
  chartColor_two = '#4FC1E8';
  chartColor_three = '#A0D568';
  chartColor_four = '#FFCE54';
  chartColor_five = '#E65261';

  mostValuableCustomers: MostValuableCustomerData[] = [];
  totalMostValuableCustomersTotalRecord = 0;
  mostValuableCustomersTotalPage = 0;
  mostValuableCustomersCurrentPage = 1;
  mostValuableCustomersTotalPagePage = 1;
  mostValuableCustomersLimit = 5;

  nearlyExitingPolicies: ExpirationPolicyData[] = [];
  nearlyExitingPolicyTotalRecord = 0;
  nearlyExitingPolicyTotalPage = 0;
  nearlyExitingPolicyCurrentPage = 1;
  nearlyExitingPolicyLimit = 5;

  totalCustomer = 0;
  totalPolicy = 0;
  totalRecord = 0;

  searchPolicyStartDate: Date | undefined;
  searchPolicyEndDate: Date | undefined;
  customerRangeStartDate: Date | undefined;
  customerRangeEndDate: Date | undefined;
  nearlyExitingPolicyStartDate: Date | undefined;
  nearlyExitingPolicyEndDate: Date | undefined;
  time: Date | undefined;

  basicData: TopPoliciesBasicData | undefined;
  basicOptions: TopPoliciesBasicOptions | undefined;

  today = new Date();
  oneMonthBefore = new Date();

  calculateOneMonthBefore(): void {
    this.oneMonthBefore = new Date();
    this.oneMonthBefore.setMonth(this.oneMonthBefore.getMonth() - 1);

    this.searchPolicyStartDate = this.oneMonthBefore;
    this.searchPolicyEndDate = this.today;
    this.customerRangeStartDate = this.oneMonthBefore;
    this.customerRangeEndDate = this.today;
    this.nearlyExitingPolicyStartDate = this.oneMonthBefore;
    this.nearlyExitingPolicyEndDate = this.today;
  }

  constructor(
    private customerService: CustomersService,
    private policyService: PolicesService,
    private recordService: RecordService,
    private dashboardService: DashboardService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
  ) { }

  ngOnInit(): void {
    this.getCustomerData();
    this.getPolicyData();
    this.getRecord();
    this.calculateOneMonthBefore();
    this.basicOptions = {
      plugins: {
        legend: {
          labels: {
            color: this.chartColor_one,
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: this.chartColor_two,
          },
          grid: {
            color: this.chartColor_three,
            drawBorder: false,
          },
        },
        x: {
          ticks: {
            color: this.chartColor_four,
          },
          grid: {
            color: this.chartColor_four,
            drawBorder: false,
          },
        },
      },
    };
    this.searchPolicy();
  }

  loadMostValuableCustomersLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.mostValuableCustomersCurrentPage = page;
    this.mostValuableCustomersLimit = event.rows || 20;
    this.searchMostValuableCustomer();
  }

  loadMostNearlyPolicyExpirationLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.nearlyExitingPolicyCurrentPage = page;
    this.nearlyExitingPolicyLimit = event.rows || 10;
    this.searchPolicyExpiration();
  }

  showCustomerSearchDialog() {
    this.mostValuableCustomerDialogVisibility = true;
  }

  showNearlyExitingPolicyDialog() {
    this.nearlyExitingPolicyDialogVisibility = true;
  }

  showPolicyDialogVisibility() {
    this.searchPolicyDialogVisibility = true;
  }

  searchPolicy() {
    const startDate = this.searchPolicyStartDate?.toISOString();
    const endDate = this.searchPolicyEndDate?.toISOString();

    this.dashboardService.getTopPolicies(startDate, endDate).subscribe({
      next: (response: TopPolicy) => {
        this.basicData = {
          labels: [],
          datasets: [
            {
              label: 'polices',
              data: [],
              backgroundColor: [
                'rgba(255, 159, 64, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
              ],
              borderColor: [
                'rgb(255, 159, 64)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
              ],
              borderWidth: 1,
            },
          ],
        };
        response.data.forEach((policy) => {
          this.basicData?.labels.push(policy.name);
          this.basicData?.datasets[0].data.push(policy.subscribedCount);
        });
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
    this.closeSearchBox();
  }

  searchMostValuableCustomer() {
    const startDate = this.customerRangeStartDate?.toISOString();
    const endDate = this.customerRangeEndDate?.toISOString();

    this.dashboardService
      .getValuableCustomer(
        this.mostValuableCustomersCurrentPage,
        this.mostValuableCustomersLimit,
        startDate,
        endDate,
      )
      .subscribe({
        next: (response: MostValuableCustomer) => {
          this.mostValuableCustomers = response.data;
          this.totalMostValuableCustomersTotalRecord = response.totalRecord;
          this.mostValuableCustomersTotalPage = response.totalPages;
        },
        error: (error: ErrorInterface) => {

          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
        },
      });
    this.closeSearchBox();
  }
  searchPolicyExpiration() {
    const startDate = this.nearlyExitingPolicyStartDate?.toISOString();
    const endDate = this.nearlyExitingPolicyEndDate?.toISOString();

    this.dashboardService
      .getNearlyPolicyExpire(
        this.nearlyExitingPolicyCurrentPage,
        this.nearlyExitingPolicyLimit,
        startDate,
        endDate,
      )
      .subscribe({
        next: (response) => {
          this.nearlyExitingPolicies = response.data;
          this.nearlyExitingPolicyTotalRecord = response.totalRecord;
          this.nearlyExitingPolicyTotalPage = response.totalPages;
        },
        error: (error: ErrorInterface) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
        },
      });
    this.closeSearchBox();
  }

  getCustomerData() {
    this.customerService.getCustomerData(1, 1, '').subscribe({
      next: (response: CustomerResponse) => {
        this.totalCustomer = response.totalRecord;
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }

  getPolicyData() {
    this.policyService.getPolicy(1, 1,'').subscribe({
      next: (response: PoliceResponse) => {
        this.totalPolicy = response.totalRecord;
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }

  getRecord() {
    this.recordService.getRecord(1, 10, false, false, '').subscribe({
      next: (response: RecordResponse) => {
        this.totalRecord = response.totalRecord;
      },
      error: (error: ErrorInterface) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: error.error.message,
        });
      },
    });
  }
}
