import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
// import { environment } from 
import {
  customerData,
  customerResponse,
} from '../../component/pages/layout/home/customers/customer.model';

@Injectable({
  providedIn: 'root',
})
export class CustomersService {
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/customer';

  constructor(private http: HttpClient) {}

  allCustomer(): Observable<customerResponse> {
    return this.http.get<customerResponse>(this.apiUrl);
  }

  // searchCustomer(searchTerm: string): Observable<any> {
  //   return this.http.get<any>(`${this.apiUrl}/?query=${searchTerm}`);
  // }

  getCustomerData(
    page: number,
    limit: number,
    searchTerm: string,
  ): Observable<customerResponse> {
    const url = `${this.apiUrl}/list/?page=${page}&limit=${limit}&query=${searchTerm}`;
    return this.http.get<customerResponse>(url);
  }

  postNewCustomer(customer: customerData): Observable<customerData> {
    return this.http.post<customerData>(this.apiUrl, customer);
  }

  UpdateCustomer(customer: customerData): Observable<customerData> {
    return this.http.put<customerData>(
      `${this.apiUrl}/${customer._id}`,
      customer,
    );
  }

  deleteCustomer(customerId: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${customerId}`);
  }
}
