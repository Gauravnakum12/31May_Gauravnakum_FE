
import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { NgClass } from '@angular/common';
import { HeaderComponent } from "../../general/header/header.component";
import { SideNavComponent } from "./side-nav/side-nav.component";
import { DashboardHeaderComponent } from "./dashboard-header/dashboard-header.component";
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [NgClass, RouterOutlet, HeaderComponent, SideNavComponent, DashboardHeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements OnInit {
  ngOnInit() {

  }
}

