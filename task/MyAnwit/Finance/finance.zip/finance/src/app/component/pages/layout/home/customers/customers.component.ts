import {
  Component,
  inject,
  OnInit,
  signal,
  ViewChild,
  viewChild,
} from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { CustomersService } from '../../../../../services/api/customers.service';
import { Table, TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import {
  FormsModule,
  ReactiveFormsModule,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, MenuItem } from 'primeng/api';
import { MessagesModule } from 'primeng/messages';

import { MessageService, Message } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { Router } from '@angular/router';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { keyUpDebounceDirective } from '../../../../../directives/keyUp.directive';

import { customerData, customerResponse } from './customer.model';
@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    TableModule,
    ConfirmDialogModule,
    CommonModule,
    ButtonModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    FloatLabelModule,
    DialogModule,
    ReactiveFormsModule,
    DatePipe,
    MessagesModule,
    ToastModule,
    RippleModule,
    BreadcrumbModule,
    IconFieldModule,
    InputIconModule,
  ],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
  providers: [ConfirmationService, MessageService, keyUpDebounceDirective],
})
export class CustomersComponent implements OnInit {
  items: MenuItem[] | undefined;
  constructor(
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.items = [
      { icon: 'pi pi-home', route: '/home' },
      { label: 'customers', route: '/home/customer' },
    ];
  }
  visible = signal(false);
  private CustomerDataService = inject(CustomersService);
  customers: customerData[] = [];

  totalCustomerRecord = 0;
  totalPage = 0;
  currentPage = 1;
  limit = 10;

  messages: Message[] = [];
  notFound: string | undefined;

  onSearchInput(event: Event): void {
    const searchValue = (event.target as HTMLInputElement).value;
    this.loadCustomerData(searchValue);
  }

  customerForm: FormGroup = new FormGroup({
    _id: new FormControl(''),
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phoneNumber: new FormControl('', [
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
    ]),
    birthDate: new FormControl('', Validators.required),
  });

  get controls() {
    return this.customerForm.controls;
  }
  loadCustomerLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.loadCustomerData('');
  }

  openNewUserDialog() {
    this.visible.set(true);
    this.customerForm.reset();
  }

  private loadCustomerData(searchTerm: string) {
    this.CustomerDataService.getCustomerData(
      this.currentPage,
      this.limit,
      searchTerm,
    ).subscribe({
      next: (response: customerResponse) => {
        this.customers = response.data;
        this.totalCustomerRecord = response.totalRecord;
        this.totalPage = response.totalPage;
        if (!response.data) {
          this.notFound = response.message;
        } else {
          this.notFound = undefined;
        }
      },
      error: (error: any) => {
        (this.customers = []),
          (this.messages = [
            {
              severity: 'error',
              summary: 'Delete Error:',
              detail: error.error.message,
              life: 1000,
            },
          ]);
      },
    });
  }

  editCustomer(customer: customerData) {
    this.visible.set(true);
    this.customerForm.setValue({
      _id: customer._id,
      name: customer.name,
      email: customer.email,
      phoneNumber: customer.phoneNumber,
      birthDate: customer.birthDate
        ? new Date(customer.birthDate).toLocaleDateString('en-CA')
        : '',
    });
  }

  saveCustomer(): void {
    if (this.customerForm.valid) {
      const tempData: customerData = this.customerForm.value;
      if (tempData._id) {
        // Update existing user
        this.CustomerDataService.UpdateCustomer(tempData).subscribe({
          next: () => {
            this.visible.set(false);
            this.loadCustomerData('');
          },
          error: (error: any) => {
            console.error(error);
            this.messages = [
              {
                severity: 'error',
                summary: 'Delete Error:',
                detail: error.error.message,
                life: 1000,
              },
            ];
          },
        });
      } else {
        // Create new user
        this.CustomerDataService.postNewCustomer(tempData).subscribe({
          next: (response) => {
            this.visible.set(false);
            this.loadCustomerData('');
          },
          error: (error: any) => {
            this.messages = [
              {
                severity: 'error',
                summary: 'Delete Error:',
                detail: error.message,
                life: 3000,
              },
            ];
          },
        });
      }
    }
  }

  deleteCustomerConformation(customer: customerData) {
    const customerId = customer._id;
    this.confirmationService.confirm({
      message: `Are you sure that you want to delete ${customer.name}?`,
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.CustomerDataService.deleteCustomer(customerId).subscribe({
          next: (res: any) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Deleted',
              detail: `${res.message} `,
            });
            this.loadCustomerData('');
          },
          error: (error: any) => {
            this.messages = [
              {
                severity: 'error',
                summary: 'Delete Error:',
                detail: error.error.message,
              },
            ];
          },
        });
      },
    });
  }
}
