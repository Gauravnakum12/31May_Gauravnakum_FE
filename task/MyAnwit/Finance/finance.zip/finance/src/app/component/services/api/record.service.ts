import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ReactiveFormsModule } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class RecordService {

  constructor(private http: HttpClient) { }
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms';

  getRecord(page: number, limit: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/record/list?page=${page}&limit=${limit}`);
  }

  postRecord(sendRecord: any): Observable<any> {
    return this.http.post<any>(` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record `, sendRecord.recordData)
  }

  updateRecord(sendRecord: any): Observable<any> {
    return this.http.put<any>(` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record/${sendRecord.recordId} `, sendRecord.recordData)
  }
  reNewRecord(sendRecord: any): Observable<any> {
    return this.http.put<any>(` ${this.apiUrl}/customer/${sendRecord.customerId}/policy/${sendRecord.policyId}/record/${sendRecord.recordId}/renew `, sendRecord.recordData)
  }

  deleteRecord(deleteRecord: any): Observable<any> {
    return this.http.delete<any>(` ${this.apiUrl}/policy/${deleteRecord.policyID}/record/${deleteRecord.recordId}`);
  }
}
