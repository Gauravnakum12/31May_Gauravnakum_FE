import { GenericResponse } from '../../../../../shared/interfaces'

export type CustomerResponse = GenericResponse<customerData>;

export interface customerData {
  _id: string;
  birthDate: Date;
  createdAt: Date;
  email: string;
  name: string;
  organization: string;
  phoneNumber: number;
}
