import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../../services/login.service';
import {
  PasswordMatchValidator,
  TermsValidator,
} from '../../../../services/auth/validator';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { SignUpData, SignUpDataSubmit } from '../../../../finance.model';

import { MessageService, Message } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  standalone: true,
  providers: [MessageService],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterLink,
    RouterLinkActive,
    ToastModule,
    ButtonModule,
    RippleModule,
  ],
})
export class LoginComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private router: Router,
    private messageService: MessageService,
  ) {}
  ngOnInit(): void {
    this.authService.navigateToHome();
  }
  visible = signal<boolean>(false);
  isSignInActive = signal<boolean>(true);

  showDialog() {
    this.visible.set(true);
  }

  emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  // passwordRegex = /^((?=.*/d)| (?=.*\W +)) (? ![.\n])(?=.*[A - Z])(?=.* [A - Z]).*$/;
  passwordRegex =
    /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
  integerRegex = /^\s*[0-9]+\s*$/;

  signInform = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [
      Validators.required,
      Validators.pattern(this.passwordRegex),
    ]),
  });

  // Sign-up form
  form = new FormGroup(
    {
      organizationName: new FormControl('', Validators.required),
      organizationLocation: new FormControl('', Validators.required),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [
        Validators.required,
        Validators.pattern(this.passwordRegex),
      ]),
      confirmPassword: new FormControl('', Validators.required),
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern(this.integerRegex),
      ]),
      terms: new FormControl(false, Validators.requiredTrue),
    },
    { validators: [PasswordMatchValidator(), TermsValidator()] },
  );

  passwordFieldType = 'password';
  togglePasswordVisibility() {
    this.passwordFieldType =
      this.passwordFieldType === 'password' ? 'text' : 'password';
  }

  signInUser(event: Event) {
    event.preventDefault();
    if (this.signInform.valid) {
      const credentials = {
        email: this.signInform.value.email ?? '',
        password: this.signInform.value.password ?? '',
      };
      this.authService.signIn(credentials).subscribe({
        next: (response) => {
          this.router.navigate(['/home/dashboard']);
        },
        error: (error) => {
          console.log(error);

          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
        },
      });
    }
  }

  get controls() {
    return this.signInform.controls;
  }

  toggleView() {
    this.isSignInActive.update((value) => !value);
  }

  get signUpControl() {
    return this.form.controls;
  }

  signupUser(event: any) {
    event.preventDefault();
    if (this.form.valid) {
      const userData: SignUpData = {
        organizationName: this.form.value.organizationName ?? '',
        organizationLocation: this.form.value.organizationLocation ?? '',
        firstName: this.form.value.firstName ?? '',
        lastName: this.form.value.lastName ?? '',
        email: this.form.value.email ?? '',
        password: this.form.value.password ?? '',
        confirmPassword: this.form.value.confirmPassword ?? '',
        phoneNumber: this.form.value.phoneNumber ?? '',
        terms: this.form.value.terms ?? false,
      };
      this.authService.signUp(userData).subscribe({
        next: (response: any) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: response.message,
          });
          this.isSignInActive.update((value) => !value);
        },
        error: (error) => {
          console.error('Sign Up Error:', error);
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: error.error.message,
          });
        },
      });
    }
  }

  logoutOwner() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
