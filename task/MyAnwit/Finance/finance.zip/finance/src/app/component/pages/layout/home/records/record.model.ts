import { GenericResponse } from '../../../../../shared/interfaces';

export type RecordResponse = GenericResponse<Record>;

export interface Record {
  _id: string;
  recordNumber: string;
  createdAt: Date;
  policy_info: PolicyInfo;
  customer_info: CustomerInfo;
  isMarkable: false;
  records: RecordFiled[];
}

export interface RecordFiled {
  policyFieldId: string;
  record: string;
}

export interface PolicyInfo {
  _id: string;
  updatedAt: Date;
  createdAt: Date;
  name: string;
  description: string;
  organization: string;
  isExpirable: boolean;
  policyFields: [];
}
export interface CustomerInfo {
  _id: string;
  birthDate: Date;
  createdAt: Date;
  email: string;
  name: string;
  organization: string;
  phoneNumber: number;
}
