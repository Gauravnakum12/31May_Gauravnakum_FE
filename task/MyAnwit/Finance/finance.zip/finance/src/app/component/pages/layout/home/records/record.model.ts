export interface RecordResponse {
    message: string,
    totalPages: number,
    data: Record[],
    totalPage: number,
    totalRecord: number
    currentPage: number
}

export interface Record {
    _id: string,
    createdAt: Date,
    policy_info: policyInfo,
    customer_info: customerInfo,
    isMarkable: false,
    records: recordFiled[],
}

export interface recordFiled {
    policyFieldId: string,
    record: string,
}

export interface policyInfo {
    _id: string,
    updatedAt: Date,
    createdAt: Date,
    name: string,
    description: string,
    organization: string,
    isExpirable: boolean
    policyFields: [],
}
export interface customerInfo {
    _id: string
    birthDate: Date
    createdAt: Date
    email: string
    name: string
    organization: string
    phoneNumber: number
}