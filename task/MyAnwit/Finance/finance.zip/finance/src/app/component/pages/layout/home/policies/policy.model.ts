export interface PoliceCreationData {
    name: string,
    description: string,
    isExpirable: boolean,
}

export interface PoliceCreationResponse {
    message: string,
    data: PoliceResponseData,
}

export interface PoliceResponse {
    message: string,
    data: PoliceResponseData[],
    totalPages: number,
    currentPage: number,
    totalRecord: number,
    totalPage: number
}

export interface PoliceResponseData {
    organization: string,
    _id: string,
    name: string,
    description: string,
    isExpirable: true,
    createdAt: Date,
    policyFields: [],
}
export interface simplePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    placeholder: string,
    value: string
}

export interface complexPolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    value: string[]
}
export interface DatePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
}

export interface Policy {
    _id: string,
    createdAt: Date,
    description: string,
    isExpirable: boolean,
    name: string,
    organization: string,
    policyFields: [],
}

// export interface Field {
//     _id: string,
//     type: string,
//     label: string,
//     createdAt: Date,
//     instruction_hints: string,
//     organization: string,
//     placeholder: string,
//     policy: string,
//     value: string[],
// }
// ------------------------------------edit-Policy-----------------------------
export interface SinglePolicyFEtched {
    message: string,
    data: any,
}
export interface SinglePolicyFEtchedData {
    _id: string,
    updatedAt: Date,
    createdAt: Date,
    name: string,
    description: string,
    organization: string,
    isExpirable: boolean
    policyFields: [],
}

export interface policyField {
    _id: string;
    organization: string;
    policy: string;
    label: string;
    createdAt: string;
    updatedAt: string;
    instruction_hints?: string;
    type: 'text' | 'number' | 'dropdown' | 'radio';
    text?: policyFiledText;
    dropdown?: policyFiledDropdown;
    number?: policyFiledNumber;
    options?: { value: string }[];
    radio?: policyFiledRadio;
}

export interface policyFiledText {
    placeholder: string;
}
export interface policyFiledNumber {
    placeholder: string;
}

export interface policyFiledDropdown {
    values: { value: string }[];
}

export interface policyFiledRadio {
    values: string[];
}

// ---------------------policy List --------------------
export interface PolicyList {
    message: string,
    data:PolicyNameAndId[],
}
export interface PolicyNameAndId {
    _id: string,
    name: string,
}