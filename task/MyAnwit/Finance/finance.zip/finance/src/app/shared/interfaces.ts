export interface GenericResponse<T> {
    message: string;
    totalPages: number;
    currentPage: number;
    totalRecord: number;
    totalPage: number;
    data: T[];
  }
  