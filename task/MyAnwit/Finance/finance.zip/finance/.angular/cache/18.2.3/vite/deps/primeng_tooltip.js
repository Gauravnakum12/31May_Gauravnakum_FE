import {
  Tooltip,
  TooltipModule
} from "./chunk-WUUABVBT.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-HE5PWX4F.js";
import "./chunk-4XBA7G65.js";
import "./chunk-D3IQWCZR.js";
import "./chunk-SZQPEDTI.js";
import "./chunk-PIQKY2LV.js";
import "./chunk-Q3R3BXB2.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
