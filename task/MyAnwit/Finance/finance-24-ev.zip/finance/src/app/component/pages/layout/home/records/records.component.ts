import { Component, OnInit, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ToastModule } from 'primeng/toast';
import { RippleModule } from 'primeng/ripple';
import { Message, ConfirmationService, MessageService } from 'primeng/api';

import { TooltipModule } from 'primeng/tooltip';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';

import { CustomersService } from '../../../../services/api/customers.service';
import { PolicesService } from '../../../../services/api/polices.service';
import { FloatLabelModule } from 'primeng/floatlabel';
import { RecordService } from '../../../../services/api/record.service';
import { SidebarModule } from 'primeng/sidebar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';

@Component({
  selector: 'app-records',
  standalone: true,
  imports: [BreadcrumbModule, RouterModule, CommonModule, ButtonModule, DialogModule, TableModule, FormsModule, DropdownModule, FloatLabelModule, SidebarModule, TooltipModule, ConfirmDialogModule, ToastModule, RippleModule,IconFieldModule,InputIconModule],
  templateUrl: './records.component.html',
  styleUrl: './records.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class RecordsComponent implements OnInit {
  items: MenuItem[] | undefined;
  updateRecord: any;
  recordTitle: string = 'Create record';
  ngOnInit() {
    this.items = [{ icon: 'pi pi-home', route: '/home' }, { label: 'record', route: '/home/record' },];
    this.loadCustomerData();
    this.getPolicyNameList();
  }
  visible: boolean = false;
  createREcordVisibility: boolean = false;

  sidebarVisible() {
    this.recordTitle = "Create record"
    this.visible = true;
    this.createREcordVisibility = true;
    this.fieldsArray = [];
    this.buttonVisible = false
  }
  filterCustomers: string | undefined = '';
  selectedCustomers: any;
  customers: any = [];

  filterPolicy: string | undefined = '';
  selectedPolicy: any;
  polices: any = [];

  policyFormData: any;
  fieldsArray: any = [];
  buttonVisible: boolean = false;

  recordData = signal<any>(null);
  totalPage: number = 0;
  currentPage: number = 1;
  limit: number = 10;
  totalRecordData: number = 0;

  loadRecordLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
    this.getRecord();
  }
  constructor(private CustomerDataService: CustomersService, private policyService: PolicesService, private recordService: RecordService, private router: Router, private messageService: MessageService,
    private confirmationService: ConfirmationService) {
  }
  getRecord() {
    this.recordService.getRecord(this.currentPage, this.limit).subscribe({
      next: (response: any) => {
        console.log(response.data);
        this.recordData.set(response.data);
        this.totalRecordData = response.totalRecord;
        this.totalPage = response.totalPage;
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }

  deleteRecord(record: any) {
    console.log(record);
    const deleteRecord: any = {
      recordId: record._id,
      // customerId: record.customer_info._id,
      policyID: record.policy_info._id,
    }

    this.confirmationService.confirm({
      message: 'Are you sure that you want to delete record?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.recordService.deleteRecord(deleteRecord).subscribe({
          next: (response: any) => {
            console.log(response);
            this.getRecord();
            this.messageService.add({ severity: 'success', summary: 'Confirmed', detail: `${response.message}` });
            this.getRecord();
          },
          error: (error: any) => {
            console.error(error);
          }
        });
      }
    });
  }

  openEditRecordSidebar(tempRecord: any) {
    this.recordTitle = "Update record"
    // console.log(tempRecord);
    this.visible = true;
    this.buttonVisible = true;
    this.createREcordVisibility = false;

    this.updateRecord = tempRecord;
    const singlePolicyId = tempRecord.policy_info._id;

    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: any) => {
        this.policyFormData = response.data;
        this.fieldsArray = [];
        let tempFields = this.policyFormData.policyFields.map((element: any) => {
          element['recordValue'] = '';

          if (element.dropdown) {
            element.options = element.dropdown.values.map((data: any) => ({ value: data }));
          } else if (element.radio) {
            element.options = element.radio.values.map((data: any) => ({ value: data }));
          }

          const matchedRecord = tempRecord.records.find((record: any) => record.policyFieldId === element._id);
          if (matchedRecord) {
            element.recordValue = matchedRecord.record;
          }
          return { ...element };
        });

        this.fieldsArray.push(...tempFields);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }
  recordSubmit() {
    let tempRecord = this.fieldsArray.map((element: any) => {
      return {
        policyFieldId: element._id,
        record: element.recordValue
      }
    });
    const sendRecord: any = {
      customerId: this.selectedCustomers._id,
      policyId: this.selectedPolicy._id,
      recordKey: {
        records: tempRecord,
      }
    }


    this.recordService.postRecord(sendRecord).subscribe({
      next: (response: any) => {
        console.log(response);
        this.visible = false
        this.getRecord();
        this.fieldsArray = [];
        this.messageService.add({ severity: 'success', summary: 'Confirmed', detail: `${response.message}` });
      },
      error: (error: any) => { console.error(error) }
    });


  }

  submitUpdatedRecord() {
    let tempRecord = this.fieldsArray.map((element: any) => {
      return {
        policyFieldId: element._id,
        record: element.recordValue
      }
    });
    const sendRecord: any = {
      customerId: this.updateRecord.customer_info._id,
      policyId: this.updateRecord.policy_info._id,
      recordId: this.updateRecord._id,
      recordKey: {
        records: tempRecord,
      }
    }
    this.recordService.updateRecord(sendRecord).subscribe({
      next: (response: any) => {
        console.log(response);
        this.visible = false
        this.getRecord();
        this.messageService.add({ severity: 'success', summary: 'Confirmed', detail: `${response.message}` });
      },
      error: (error: any) => { console.error(error) }
    });
  }
  private loadCustomerData() {
    this.CustomerDataService.allCustomer().subscribe({
      next: (response: any) => {
        this.customers = response.data
      },
      error: (error: Error) => console.error(error),
    });
  }
  getPolicyNameList() {
    this.policyService.getPolicyNameList().subscribe({
      next: (response: any) => {
        this.polices = (response.data);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }
  callCustomer(event: any) {
    this.selectedCustomers = event.value;
  }
  getPolicy() {
    this.fieldsArray = [];
    const singlePolicyId = this.selectedPolicy._id
    this.policyService.getSinglePolicy(singlePolicyId).subscribe({
      next: (response: any) => {
        this.policyFormData = response.data;
        // console.log(this.policyFormData);
        let temFelids = this.policyFormData.policyFields.map((element: any) => {
          element['recordValue'] = '';
          if (element.dropdown) {
            element.options = element.dropdown.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          else if (element.radio) {
            element.options = element.radio.values.map((data: any) => {
              return {
                value: data
              }
            })
          }
          return { ...element };
        })
        // this.cardData = '';
        this.fieldsArray.push(...temFelids);
        console.log(this.fieldsArray);
        // console.log()
      },
      error: (error: any) => {
        console.error(error);
      }
    });
    this.buttonVisible = true;
  }
}
