import {
  Ripple,
  RippleModule
} from "./chunk-YP33PSG5.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
