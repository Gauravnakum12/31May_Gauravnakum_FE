import {
  InputText,
  InputTextModule
} from "./chunk-RAK4M5WD.js";
import "./chunk-YMPYEK3I.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
