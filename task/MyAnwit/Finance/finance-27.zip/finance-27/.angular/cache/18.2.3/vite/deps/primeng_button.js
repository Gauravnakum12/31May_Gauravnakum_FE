import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-KG5V663U.js";
import "./chunk-2XD6ITC3.js";
import "./chunk-LOS6IAGJ.js";
import "./chunk-G34IFAOL.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-HE5PWX4F.js";
import "./chunk-4XBA7G65.js";
import "./chunk-D3IQWCZR.js";
import "./chunk-PIQKY2LV.js";
import "./chunk-SZQPEDTI.js";
import "./chunk-Q3R3BXB2.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
