import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  constructor(private http: HttpClient) { }
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/';
  getPolicyNameList(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/name-list`);
  }
  getTopPolicies(startDate: string | undefined, endDate: string | undefined): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}analytics/topPolices/record/?startDate=${startDate}&endDate=${endDate}`);
  }

  getValuableCustomer(page: number, limit: number, startDate: string | undefined, endDate: string | undefined): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}analytics/valuableCustomer?page=${page}&limit=${limit}&startDate=${startDate}&endDate=${endDate}`);
  }

  getNearlyPolicyExpire(page: number, limit: number, startDate: string | undefined, endDate: string | undefined): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}analytics/nearlyPolicyExpire/customer?page=${page}&limit=${limit}&startDate=${startDate}&endDate=${endDate}`);
  }
}