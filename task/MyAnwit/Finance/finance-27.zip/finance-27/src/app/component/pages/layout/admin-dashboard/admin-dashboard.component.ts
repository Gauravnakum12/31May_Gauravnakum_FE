import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../../../services/api/customers.service';
import { PolicesService } from '../../../services/api/polices.service';
import { RecordService } from '../../../services/api/record.service';
import { customerResponse } from '../../../../finance.model';
import { PoliceResponse } from '../home/policies/policy.model';
import { RecordResponse } from '../home/records/record.model';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { DashboardService } from '../../../services/api/dashboard.service';
import { MostValuableCustomer, MostValuableCustomerData, topPolicy } from './dashboard.model';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';

import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [ChartModule, FormsModule, CalendarModule, TableModule, ButtonModule, InputTextModule, DialogModule, CommonModule, DatePipe],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent implements OnInit {

  searchPolicyDialogVisibility: boolean = false;
  mostValuableCustomerDialogVisibility: boolean = false;
  nearlyExitingPolicyDialogVisibility: boolean = false;
  chartColor_one: string = '#AC92EB';
  chartColor_two: string = '#4FC1E8';
  chartColor_three: string = '#A0D568';
  chartColor_four: string = '#FFCE54';
  chartColor_five: string = '#E65261';

  mostValuableCustomers: MostValuableCustomerData[] = []
  totalMostValuableCustomersTotalRecord: number = 0;
  mostValuableCustomersTotalPage: number = 0;
  mostValuableCustomersCurrentPage: number = 1;
  mostValuableCustomersTotalPagePage: number = 1;
  mostValuableCustomersLimit: number = 5;

  nearlyExitingPolicy: MostValuableCustomerData[] = []
  nearlyExitingPolicyTotalRecord: number = 0;
  nearlyExitingPolicyTotalPage: number = 0;
  nearlyExitingPolicyCurrentPage: number = 1;
  nearlyExitingPolicyLimit: number = 5;

  totalCustomer: number = 0;
  totalPolicy: number = 0;
  totalRecord: number = 0;
  chartData: any = {
    labels: [],
    datasets: [{
      data: [],
      backgroundColor: [this.chartColor_one, this.chartColor_two, this.chartColor_three, this.chartColor_four, this.chartColor_five],
    }
    ]
  };
  chartOptions: any = [];
  searchPolicyStartDate: Date | undefined;
  searchPolicyEndDate: Date | undefined;
  customerRangeStartDate: Date | undefined;
  customerRangeEndDate: Date | undefined;
  nearlyExitingPolicyStartDate: Date | undefined;
  nearlyExitingPolicyEndDate: Date | undefined;
  time: Date | undefined;

  constructor(private customerService: CustomersService, private policyService: PolicesService, private recordService: RecordService, private dashboardService: DashboardService) {
  }

  basicData: any;

  basicOptions: any;
  ngOnInit(): void {
    this.getCustomerData();
    this.getPolicyData();
    this.getRecord();

    // this.basicData = {
    //   labels: ['Q1', 'Q2', 'Q3', 'Q4'],
    //   datasets: [
    //     {
    //       label: 'polices',
    //       data: [540, 325, 702, 620],
    //       backgroundColor: ['rgba(255, 159, 64, 0.2)', 'rgba(75, 192, 192, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(153, 102, 255, 0.2)'],
    //       borderColor: ['rgb(255, 159, 64)', 'rgb(75, 192, 192)', 'rgb(54, 162, 235)', 'rgb(153, 102, 255)'],
    //       borderWidth: 1
    //     }
    //   ]
    // }

    this.basicOptions = {
      plugins: {
        legend: {
          labels: {
            color: this.chartColor_one,
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: this.chartColor_two
          },
          grid: {
            color: this.chartColor_three,
            drawBorder: false
          }
        },
        x: {
          ticks: {
            color: this.chartColor_four
          },
          grid: {
            color: this.chartColor_four,
            drawBorder: false
          }
        }
      }
    };
  }

  loadMostValuableCustomersLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.mostValuableCustomersCurrentPage = page;
    this.mostValuableCustomersLimit = event.rows || 20;
    this.searchMostValuableCustomer();
  }


  showCustomerSearchDialog() {
    this.mostValuableCustomerDialogVisibility = true;
  }

  showNearlyExitingPolicyDialog() {
    this.nearlyExitingPolicyDialogVisibility = true;
  }
  getCustomerData() {
    this.customerService.getCustomerData(1, 1, '').subscribe({
      next: (response: customerResponse) => {
        // console.log(response);
        this.totalCustomer = response.totalRecord;
      },
      error: (error: any) => {
        console.log(error.error);
        (error)
      },
    });
  }

  getPolicyData() {
    this.policyService.getPolicy(1, 1,).subscribe({
      next: (response: PoliceResponse) => {
        this.totalPolicy = response.totalRecord;
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }

  getRecord() {
    this.recordService.getRecord(1, 1).subscribe({
      next: (response: RecordResponse) => {
        // console.log(response);

        this.totalRecord = response.totalRecord;
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }

//   searchPolicy() {
//     const startDate = this.searchPolicyStartDate?.toISOString();
//     const endDate = this.searchPolicyEndDate?.toISOString();
//     console.log(startDate);

//     this.dashboardService.getTopPolicies(startDate, endDate).subscribe({
//       next: (response: topPolicy) => {
//         console.log(response);
// this.basicData = {
//   labels: [],
//   datasets: [
//     {
//       label: 'polices',
//       data: [],
//       backgroundColor: ['rgba(255, 159, 64, 0.2)', 'rgba(75, 192, 192, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(153, 102, 255, 0.2)'],
//       borderColor: ['rgb(255, 159, 64)', 'rgb(75, 192, 192)', 'rgb(54, 162, 235)', 'rgb(153, 102, 255)'],
//       borderWidth: 1
//   }
//   ]
// }
// for (let i = 0; i < response.data.length; i++) {
//   this.chartData.labels.push(response.data[i].name)
//   this.chartData.datasets[0].data.push(response.data[i].subscribedCount)
// }
//       },
//       error: (error: any) => {
//         console.log(error);
//       }
//     });
//   }

searchPolicy() {
  const startDate = this.searchPolicyStartDate?.toISOString();
  const endDate = this.searchPolicyEndDate?.toISOString();
  console.log(startDate);

  this.dashboardService.getTopPolicies(startDate, endDate).subscribe({
    next: (response: topPolicy) => {
      console.log(response);

      this.basicData = {
        labels: [540, 325, 702, 620], // will be filled dynamically
        datasets: [
          {
            label: 'polices',
            data: [540, 325, 702, 620], // will be filled dynamically
            backgroundColor: [
              'rgba(255, 159, 64, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)'
            ],
            borderColor: [
              'rgb(255, 159, 64)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)'
            ],
            borderWidth: 1
          }
        ]
      };

      // Map over the response data to populate labels and data
      response.data.forEach(policy => {
        this.basicData.labels.push(policy.name);
        this.basicData.datasets[0].data.push(policy.subscribedCount);
      });
    },
    error: (error: any) => {
      
      console.log(error);
    }
  });
}


  searchMostValuableCustomer() {
    const startDate = this.customerRangeStartDate?.toISOString();
    const endDate = this.customerRangeEndDate?.toISOString();
    console.log(startDate);

    this.dashboardService.getValuableCustomer(this.mostValuableCustomersCurrentPage, this.mostValuableCustomersLimit, startDate, endDate).subscribe({
      next: (response: MostValuableCustomer) => {
        console.log(response);
        this.mostValuableCustomers = response.data;
        this.totalMostValuableCustomersTotalRecord = response.totalRecord
        this.mostValuableCustomersTotalPage = response.totalPages
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }
  searchPolicyExpiration() {
    const startDate = this.nearlyExitingPolicyStartDate?.toISOString();
    const endDate = this.nearlyExitingPolicyEndDate?.toISOString();
    // console.log(startDate);

    this.dashboardService.getNearlyPolicyExpire(this.nearlyExitingPolicyCurrentPage, this.nearlyExitingPolicyLimit, startDate, endDate).subscribe({
      next: (response: any) => {
        console.log(response);
      },
      error: (error: any) => {
        console.log(error);
      }
    });
  }
}





