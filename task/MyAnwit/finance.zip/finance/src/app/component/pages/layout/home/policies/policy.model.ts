export interface PoliceCreationData {
    name: string;
    description: string;
    isExpirable: boolean;
}

export interface PoliceCreationResponse {
    message: string;
    data: PoliceResponseData;
}

export interface PoliceResponse {
    message: string;
    totalPages: number;
    currentPage: number;
    totalRecord: number;
    totalPage: number;
    data: PoliceResponseData[];
}

export interface PoliceResponseData {
    organization: string;
    _id: string;
    name: string;
    description: string;
    isExpirable: true;
    createdAt: Date;
    policyFields: [];
}

export interface DatePolicyField {
    label: string;
    type: string;
    instruction_hints?: string;
}

export interface Policy {
    _id: string;
    createdAt: Date;
    description: string;
    isExpirable: boolean;
    name: string;
    organization: string;
    policyFields: [];
}

export interface SinglePolicyFEtched {
    message: string;
    data: any;
}
export interface SinglePolicyFEtchedData {
    _id: string;
    updatedAt: Date;
    createdAt: Date;
    name: string;
    description: string;
    organization: string;
    isExpirable: boolean;
    policyFields: [];
}

export interface PolicyField {
    _id: string;
    organization: string;
    policy: string;
    label: string;
    createdAt: string;
    updatedAt: string;
    instruction_hints?: string;
    type: 'text' | 'number' | 'dropdown' | 'radio';
    text?: policyFiledText;
    dropdown?: policyFiledDropdown;
    number?: policyFiledNumber;
    options?: { value: string }[];
    radio?: policyFiledRadio;
}

export interface policyFiledText {
    placeholder: string;
}
export interface policyFiledNumber {
    placeholder: string;
}

export interface policyFiledDropdown {
    values: { value: string }[];
}

export interface policyFiledRadio {
    values: string[];
}

export interface PolicyList {
    message: string;
    data: PolicyNameAndId[];
}
export interface PolicyNameAndId {
    _id: string;
    name: string;
}
