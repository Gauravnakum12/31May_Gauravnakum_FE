export interface customerResponse {
  message: string;
  totalPage: number;
  limit: number;
  totalRecord: number;
  currentPage: number;
  data: customerData[];
}

export interface customerData {
  _id: string;
  birthDate: Date;
  createdAt: Date;
  email: string;
  name: string;
  organization: string;
  phoneNumber: number;
}
