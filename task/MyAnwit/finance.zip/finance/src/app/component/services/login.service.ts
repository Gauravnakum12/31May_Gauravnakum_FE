import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { fetchedUser, LoginResponse, fetchedOrganization, SignUpResponse, organizationData, } from '../../finance.model';
import { organizationDataService } from './api/organizational.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/auth';
  private organizationService = inject(organizationDataService);
  signInInfo = signal<fetchedUser[]>([]);
  organizationInfo = signal<organizationData[]>([]);
  constructor(private http: HttpClient, private router: Router) { }

  // Login method with strict typing for the response
  signIn(credentials: { email: string; password: string }): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(tap((response: LoginResponse) => {
        if (response.accessToken) {
          this.signInInfo.set(response.user);
          localStorage.setItem('financeToken', response.accessToken);
          this.organizationService.getOrganizationData().subscribe({
            next: (res: fetchedOrganization) => {
              this.organizationInfo.set(res.data);
              console.log('Organization data received:', res);
              localStorage.setItem('id', this.organizationInfo()[0]._id);

            },
            error: (error) => {
              console.error('Error fetching organization data:', error);
            }
          });
        }
      })
      );
  }

  signUp(userData: SignUpResponse): Observable<SignUpResponse> {
    return this.http.post<SignUpResponse>(`${this.apiUrl}/signup`, userData)

  }

  logout() {
    localStorage.removeItem('financeToken');
  }
  navigateToHome() {
    const token = localStorage.getItem('financeToken');
    if (token) {
      this.router.navigate(['/home']);
    }
  }
}
