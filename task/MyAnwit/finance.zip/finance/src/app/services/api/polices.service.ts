import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  PoliceCreationData,
  PoliceCreationResponse,
  PoliceResponse as PoliceResponse,
} from '../../component/pages/layout/home/policies/policy.model';

@Injectable({
  providedIn: 'root',
})
export class PolicesService {
  constructor(private http: HttpClient) {}
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/policy';
  getPolicyNameList(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/name-list`);
  }
  getSinglePolicy(policyIdFromRoute: string): Observable<any> {
    return this.http.get<PoliceResponse>(`${this.apiUrl}/${policyIdFromRoute}`);
  }

  getPolicy(page: number, limit: number): Observable<any> {
    return this.http.get<PoliceResponse>(
      `${this.apiUrl}/list/?page=${page}&limit=${limit}`,
    );
  }
  updatePolicy(policyIdFromRoute: string, updatedData: any) {
    return this.http.put<PoliceResponse>(
      `${this.apiUrl}/${policyIdFromRoute}`,
      updatedData,
    );
  }
  deletePolicy(policyId: string): Observable<any> {
    return this.http.delete<PoliceResponse>(`${this.apiUrl}/${policyId}`);
  }

  postNewPolices(policy: {
    name: string;
    description: string;
    isExpirable: boolean;
  }): Observable<PoliceCreationResponse> {
    return this.http.post<PoliceCreationResponse>(this.apiUrl, policy);
  }

  postInputField(policyId: string, InputFieldCard: any): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}/${policyId}/policyFields`,
      InputFieldCard,
    );
  }

  postUpdatedInputField(passData: any): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}/${passData.policyId}/policyFields/${passData.cardId}`,
      passData.formData,
    );
  }

  deleteInputField(passData: any): Observable<any> {
    return this.http.delete<any>(
      `${this.apiUrl}/${passData.policyId}/policyFields/${passData.cardId}`,
    );
  }
}
