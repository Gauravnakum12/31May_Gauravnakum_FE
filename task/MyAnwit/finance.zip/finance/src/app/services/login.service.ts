import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import {
  User,
  LoginResponse,
  FetchedOrganization,
  SignUpData,
  OrganizationData,
} from '../finance.model';
import { organizationDataService } from './api/organizational.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'https://ctwvk1rh-3003.inc1.devtunnels.ms/auth';
  private organizationService = inject(organizationDataService);
  signInInfo = signal<User[]>([]);
  organizationInfo = signal<OrganizationData[]>([]);
  constructor(
    private http: HttpClient,
    private router: Router,
  ) {}

  signIn(credentials: {
    email: string;
    password: string;
  }): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        tap((response: LoginResponse) => {
          if (response.accessToken) {
            this.signInInfo.set(response.user);
            localStorage.setItem('financeToken', response.accessToken);
            this.organizationService.getOrganizationData().subscribe({
              next: (res: FetchedOrganization) => {
                this.organizationInfo.set(res.data);
                localStorage.setItem('id', this.organizationInfo()[0]._id);
              },
              error: (error) => {
                console.error('Error fetching organization data:', error);
              },
            });
          }
        }),
      );
  }

  signUp(userData: SignUpData): Observable<SignUpData> {
    return this.http.post<SignUpData>(`${this.apiUrl}/signup`, userData);
  }

  logout() {
    localStorage.removeItem('financeToken');
  }
  navigateToHome() {
    const token = localStorage.getItem('financeToken');
    if (token) {
      this.router.navigate(['/home/dashboard']);
    }
  }
}
