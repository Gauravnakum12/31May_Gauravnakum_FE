import { Message } from 'primeng/api';
export interface User {
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: number;
  resetToken: null;
  verificationCode: null;
  verificationCodeExpiry: null;
  verified: boolean;
  registerCode: number;
}
export interface FetchedOrganization {
  message: string;
  data: OrganizationData[];
}

export interface OrganizationData {
  location: string;
  name: string;
  createdAt: Date | string;
  _id: string;
}
export interface LoginResponse {
  accessToken: string;
  message: string;
  _id: string;
  createdAt: Date;
  user: User[];
}
export interface SignUpData {
  organizationLocation?: string;
  organizationName: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  terms: boolean;
  password: string;
  confirmPassword: string;
}
export interface SignUpDataSubmit {
  message: string;
  organization: OrganizationData;
}
