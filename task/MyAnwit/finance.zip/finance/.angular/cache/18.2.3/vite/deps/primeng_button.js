import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-V6TXZSTR.js";
import "./chunk-5TPT74BM.js";
import "./chunk-U6VRYB5D.js";
import "./chunk-BJ3RULPZ.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
