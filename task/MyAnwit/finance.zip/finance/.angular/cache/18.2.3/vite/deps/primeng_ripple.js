import {
  Ripple,
  RippleModule
} from "./chunk-U6VRYB5D.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  Ripple,
  RippleModule
};
//# sourceMappingURL=primeng_ripple.js.map
