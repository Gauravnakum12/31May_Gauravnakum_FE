import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-7UDB5L6L.js";
import "./chunk-YJ7WA6ZH.js";
import "./chunk-BJ3RULPZ.js";
import "./chunk-2QPE2CQO.js";
import "./chunk-4BEQS6LP.js";
import "./chunk-W5BY6WIP.js";
import "./chunk-E7PIFXUZ.js";
import "./chunk-Q3ZLBCLD.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
