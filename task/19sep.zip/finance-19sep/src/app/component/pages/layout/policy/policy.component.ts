import { FormBuilder, FormGroup, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-policy',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.scss']
})
export class PolicyComponent {

  customInputDataType: string[] = ["text", "file", "dropdown", "radio"];

  dynamicForm: FormGroup;

  popupForm: FormGroup;
  fields: any[] = [];

  popupVisible = true;
  selectedInputType: string = '';
  dropdownOptions: string[] = [];
  radioOptions: string[] = [];

  constructor(private fb: FormBuilder) {
    this.dynamicForm = this.fb.group({
      PolicyName: ['', Validators.required], 
      selectedInput: ['']
    });

    this.popupForm = this.fb.group({
      label: ['', Validators.required],
      options: ['']
    });
  }

  openPopup() {
    this.popupVisible = true;
    this.selectedInputType = this.dynamicForm.get('selectedInput')?.value;
    this.popupForm.reset();
    this.dropdownOptions = [];
    this.radioOptions = [];
  }

  closePopup() {
    this.popupVisible = false;
  }

  addOption() {
    const option = this.popupForm.get('options')?.value.trim();
    if (option) {
      if (this.selectedInputType === 'dropdown') {
        this.dropdownOptions.push(option);
      } else if (this.selectedInputType === 'radio') {
        this.radioOptions.push(option);
      }
      this.popupForm.get('options')?.setValue('');
    }
  }

  addField() {
    const label = this.popupForm.get('label')?.value;
    const controlName = label.replace().toLowerCase();
    let newField: any = {
      label: label,
      controlName: controlName,
      type: this.selectedInputType,
    };

    if (this.selectedInputType === 'text') {
      this.dynamicForm.addControl(controlName, new FormControl(''));
    } else if (this.selectedInputType === 'file') {
      this.dynamicForm.addControl(controlName, new FormControl(null));
    } else if (this.selectedInputType === 'dropdown' || this.selectedInputType === 'radio') {
      newField['options'] = this.selectedInputType === 'dropdown' ? this.dropdownOptions : this.radioOptions;
      this.dynamicForm.addControl(controlName, new FormControl(''));
    }
    this.fields.push(newField);
    this.closePopup();
  }

  clearFields() {
    this.dynamicForm.reset();
    this.fields = [];
  }

  onSubmit() {
    const formValues = this.dynamicForm.value;
    const output = this.fields.map(field => {
      const fieldOutput: any = {
        type: field.type,
        label: field.label
      };
      if (field.options && field.options.length > 0) {
        fieldOutput.options = field.options;
      }
      return fieldOutput;
    });
    console.log({ PolicyName: formValues.PolicyName, fields: output });
  }
}

