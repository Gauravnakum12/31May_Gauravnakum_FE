import { Component, signal } from '@angular/core';
import { SidebarService } from '../../../../services/sidebarService';
// import { }
import { MenuItem } from 'primeng/api';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { AuthService } from '../../../../services/login.service';
import { fetchedUser } from '../../../../../finance.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard-header',
  standalone: true,
  imports: [MenuModule, ButtonModule],
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss']
})
export class DashboardHeaderComponent {
  constructor(private authService: AuthService,private router: Router ) { }
  
  organiZationInfo = this.authService.organizationInfo()[0];
  UserInfo = this.authService.signInInfo();

  items: MenuItem[] | undefined;

  // OrganiZationName: string | undefined = this.organiZationInfo.name;
  // username :string = this.UserInfo.firstName;

  ngOnInit() {
    // this.OrganiZationName = this.organiZationInfo.name;
    console.log(`log of organiZationInfo ${this.organiZationInfo}`)
    console.log(`log of UserInfo ${this.UserInfo}`);
    // console.log(`log from dashboard ${this.UserInfo.firstName}`);

    this.items = [
      {
        label: 'Options',
        items: [
          {
            icon: '',
            label: 'organization',

          },
          {
            icon: 'pi pi-sign-out',
            label: 'log-out',
            // click: ,
            command: (event) => {
              // console.log('Item clicked')
              localStorage.removeItem('financeToken');
              this.router.navigate(['/login']);
            },
          }
        ]
      }
    ];
  }
  logOutFunction() {
    localStorage.clear();
  }

}
