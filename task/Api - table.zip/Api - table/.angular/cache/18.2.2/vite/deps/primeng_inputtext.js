import {
  InputText,
  InputTextModule
} from "./chunk-55PIY2OM.js";
import "./chunk-CAUKJ7XR.js";
import "./chunk-MINMG2VS.js";
import "./chunk-GTUCESPA.js";
import "./chunk-3W2WHAOB.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
