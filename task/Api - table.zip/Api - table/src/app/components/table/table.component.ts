import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { UserService } from '../../../services/user.service';
import { User, UserDataResponse } from '../../user.model';

import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { LazyLoadEvent } from 'primeng/api';
@Component({
  selector: 'app-table',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    FloatLabelModule,
    DialogModule,
    ReactiveFormsModule
  ],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  private userDataService = inject(UserService);
  err = signal('');
  visible = signal(false);
  imgSrc: string = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
  userForm: FormGroup = new FormGroup({
    id: new FormControl<number | null>(null),
    avatar: new FormControl('', Validators.required),
    first_name: new FormControl('', Validators.required),
    last_name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  userData = signal<UserDataResponse>({
    page: 0,
    per_page: 0,
    total: 0,
    total_pages: 0,
    data: [],
    support: {
      url: '',
      text: '',
    }
  });

  first = 0;
  rows = 6;
  totalRecords: number = this.userData().total;  //12
  recordsPerPage: number = this.userData().page;  // 6
  totalPages: number = 2;
  currentPage: number = 1;
  pages: number[] = [];

  constructor(private router: Router, private route: ActivatedRoute) {
    this.calculatePages();
  }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const page = params['page'] ? Number(params['page']) : 1;
      this.currentPage = page;
      this.loadUserData();
    });
  }

  loadUserData(){
    this.userDataService.getUserData(this.currentPage).subscribe({
      next: (users: UserDataResponse) => {
        this.userData.set(users);
        // console.log( users)
      },
      error: (error: Error) => {
        this.err.set(error.message);
      },
    });
  }

  // loadDataLazy(event:LazyLoadEvent){

  // }

  openNewUserDialog(): void {
    this.visible.set(true);
    this.imgSrc = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    this.userForm.reset();
  }

  editUser(user: User): void {
    this.visible.set(true);
    this.userForm.setValue(user);
    this.imgSrc = user.avatar || 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
  }

  getNewUserId(): number {
    const lastUser = this.userData().data[this.userData().data.length - 1];
    return lastUser ? lastUser.id + 1 : 1;
  }

  saveUser(): void {
    if (this.userForm.valid) {
      const tempData: User = this.userForm.value;
      if (tempData.id) {
        // Update existing user
        this.userDataService.updateUser(tempData).subscribe({
          next: () => {



            // recall current page of user list  



            this.visible.set(false);
          },
          error: (error: Error) => this.err.set(error.message),
        });
      } else {
        // Create new user
        const newUser = { ...tempData, id: this.getNewUserId() };
        this.userDataService.postNewUserData(newUser).subscribe({
          next: (response) => {
            console.log(response);
            this.visible.set(false);
          },
          error: (error: Error) => this.err.set(error.message),
        });
      }
      this.imgSrc = tempData.avatar || 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    }
  }
  deleteUser(userId: number): void {
    this.userDataService.deleteUser(userId).subscribe({
      next: function(response){console.log(response);
            // recall current page of user list 
      },
      error: (error: Error) => this.err.set(error.message),
    });
  }
  setImageSrc(): void {
    const avatarUrl = this.userForm.get('avatar')?.value;
    if (avatarUrl) {
      this.imgSrc = avatarUrl;
    } else {
      this.imgSrc = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    }
  }
  goToPage(page: number) {
    if (page < 1 || page > this.totalPages) return;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { page: page },
    });
  }

  pageChange(event: { first: number; rows: number; }) {
    this.first = event.first;
    this.rows = event.rows;
  }

  calculatePages() {
    for (let i = 1; i <= this.totalPages; i++) {
      this.pages.push(i);
    }
  }

  get controls() {
    return this.userForm.controls;
  }
}
