import { Injectable,  } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { Observable,  } from 'rxjs';
import { User, UserDataResponse } from '../app/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'https://reqres.in/api/users';

  constructor(private httpClient: HttpClient) { }

  getUserData(page: number): Observable<UserDataResponse> {
    const url = `${this.apiUrl}?page=${page}`;
    return this.httpClient.get<UserDataResponse>(url);
  }

  postNewUserData(user: User): Observable<User> {
    return this.httpClient.post<User>(this.apiUrl, user);
  }

  updateUser(user: User){
    const url = `${this.apiUrl}/${user.id}`;
    return this.httpClient.put<User>(url, user);
  }

  deleteUser(userId: number) {
    const url = `${this.apiUrl}/${userId}`;
    return this.httpClient.delete<void>(url);
  }
}

