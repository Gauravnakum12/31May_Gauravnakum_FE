import { Component, inject, OnInit } from '@angular/core';
import { NgFor, NgClass } from '@angular/common';
import { GameService } from '../game.service';
import { TicTacCellComponent } from './tic-tac-cell/tic-tac-cell.component';

@Component({
  selector: 'app-tic-tac-toe',
  templateUrl: './tic-tac-toe.component.html',
  styleUrls: ['./tic-tac-toe.component.css'],
  standalone: true,
  providers: [GameService, NgClass],
  imports: [NgFor, NgClass, TicTacCellComponent]
})
export class TicTacToeComponent {
  private gameService = inject(GameService);
  gameData = this.gameService.board;
  myMessage = this.gameService.message;
  winDetails = this.gameService.winDetails;

  myMove(i: number) {
    this.gameService.makeMove(i);
  }

  myResetFunction() {
    this.gameService.resetGame();
  }

  getWinningLineClass(index: number): string {
    const winDetails = this.winDetails();
    if (winDetails) {
      const { combo, winType } = winDetails;
      if (combo.includes(index)) {
        return `win-${winType}-line`;
      }
    }
    return '';
  }
}
