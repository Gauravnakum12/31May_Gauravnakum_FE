import { Component, inject, signal } from '@angular/core';
import { GameService } from '../game.service';
import { NgFor, NgClass } from '@angular/common';
import { TicTacCellComponent } from './tic-tac-cell/tic-tac-cell.component';

@Component({
  selector: 'app-tic-tac-toe',
  templateUrl: './tic-tac-toe.component.html',
  styleUrls: ['./tic-tac-toe.component.css'],
  standalone: true,
  providers: [GameService],
  imports: [NgFor, NgClass, TicTacCellComponent]
})
export class TicTacToeComponent {
  winVertical = signal<number[] | undefined>(undefined);
  winHorizontal = signal<number[] | undefined>(undefined);
  winCrossFirst = signal<number[] | undefined>(undefined);
  winCrossSecond = signal<number[] | undefined>(undefined);

  private gameService = inject(GameService);
  gameData = this.gameService.board;
  myMessage = this.gameService.message;

  constructor() {}

  myMove(i: number) {
    this.gameService.makeMove(i);
    const combo = this.gameService.winNumberArr();
    if (combo.length) {
      this.setWinningLine(combo);
    }
  }

  myResetFunction() {
    this.gameService.resetGame();
    this.winVertical.set(undefined);
    this.winHorizontal.set(undefined);
    this.winCrossFirst.set(undefined);
    this.winCrossSecond.set(undefined);
  }

  setWinningLine(combo: number[]) {
    if (combo) {
      if (this.isHorizontalWin(combo)) {
        this.winHorizontal.set(combo);
      } else if (this.isVerticalWin(combo)) {
        this.winVertical.set(combo);
      } else if (this.isCrossFirstWin(combo)) {
        this.winCrossFirst.set(combo);
        console.log('isCrossFirstWin');
      } else if (this.isCrossSecondWin(combo)) {
        this.winCrossSecond.set(combo);
        console.log('isCrossSecondWin');
      }
    }
  }

  private isHorizontalWin(combo: number[]): boolean {
    return (
      (combo[0] === 0 && combo[1] === 1 && combo[2] === 2) ||
      (combo[0] === 3 && combo[1] === 4 && combo[2] === 5) ||
      (combo[0] === 6 && combo[1] === 7 && combo[2] === 8)
    );
  }

  private isVerticalWin(combo: number[]): boolean {
    return (
      (combo[0] === 0 && combo[1] === 3 && combo[2] === 6) ||
      (combo[0] === 1 && combo[1] === 4 && combo[2] === 7) ||
      (combo[0] === 2 && combo[1] === 5 && combo[2] === 8)
    );
  }

  private isCrossFirstWin(combo: number[]): boolean {
    // top-left to bottom-right
    return combo[0] === 0 && combo[1] === 4 && combo[2] === 8;
  
  }

  private isCrossSecondWin(combo: number[]): boolean {
    //  top-right to bottom-left
    return combo[0] === 2 && combo[1] === 4 && combo[2] === 6;
  
  }
}
