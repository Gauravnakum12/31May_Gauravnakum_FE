import { Component, Input, Output, EventEmitter, inject, signal, OnInit } from '@angular/core';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-tic-tac-cell',
  templateUrl: './tic-tac-cell.component.html',
  styleUrls: ['./tic-tac-cell.component.css'],
  standalone: true,
  imports: [NgClass]
})
export class TicTacCellComponent implements OnInit {
  @Input() cellData: string = '';
  @Input() winDetails: { combo: number[]} | null = null;
  @Output() cellClick = new EventEmitter<void>();

  ngOnInit(): void {
  }
  onCellClick() {
    console.log('clicked');
    this.cellClick.emit();
  }

  isWinningCell(): boolean {
    return this.winDetails?.combo.includes(this.cellData as unknown as number) ?? false;
  }


}
