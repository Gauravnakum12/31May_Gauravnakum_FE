import { NgClass } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-tic-tac-cell',
  templateUrl: './tic-tac-cell.component.html',
  styleUrls: ['./tic-tac-cell.component.css'],
  standalone: true,
  imports: [NgClass]
})
export class TicTacCellComponent {
  @Input() cellData: string = '';

  @Output() cellClick = new EventEmitter<void>();
  onCellClick() {
    this.cellClick.emit();
  }
}
