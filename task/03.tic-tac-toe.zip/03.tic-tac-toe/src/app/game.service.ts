import { Injectable, signal } from '@angular/core';

@Injectable()
export class GameService {
  board = signal<string[]>(['', '', '', '', '', '', '', '', '']);
  currentPlayer = signal<string>('X');
  message = signal<string>('Your turn!');
  gameActive = signal<boolean>(true);
  winDetails = signal<{ combo: number[]; winType: string } | null>(null);

  winningCombinations: number[][] = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];

  makeMove(index: number): void {
    if (this.board()[index] === '' && this.gameActive()) {
      this.board.update(value => {
        value[index] = this.currentPlayer();
        return value;
      });
      this.checkWinner();
      if (this.gameActive()) {
        this.switchPlayer();
        if (this.currentPlayer() === 'O') {
          this.computerMove();
        }
      }
    }
  }

  switchPlayer(): void {
    this.currentPlayer.update(value => (value === 'X' ? 'O' : 'X'));
    this.message.set(this.currentPlayer() === 'X' ? 'Your turn!' : 'Computer\'s turn...');
  }

  computerMove(): void {
    const emptyIndexes: number[] = [];
    for (let i = 0; i < this.board().length; i++) {
      if (this.board()[i] === '') {
        emptyIndexes.push(i);
      }
    }

    if (emptyIndexes.length > 0) {
      const randomIndex = emptyIndexes[Math.floor(Math.random() * emptyIndexes.length)];
      this.board.update(value => {
        value[randomIndex] = 'O';
        return value;
      });
      this.checkWinner();
      if (this.gameActive()) {
        this.switchPlayer();
      }
    }
  }

  checkWinner(): void {
    for (let combo of this.winningCombinations) {
      if (combo.every(index => this.board()[index] && this.board()[index] === this.currentPlayer())) {
        this.gameActive.set(false);
        this.message.set(`${this.currentPlayer()} wins!`);
        this.winDetails.set({ combo, winType: this.getWinType(combo) });
        return;
      }
    }

    if (!this.board().includes('')) {
      this.message.set('It\'s a draw!');
      this.gameActive.set(false);
    }
  }

  resetGame(): void {
    this.board.set(['', '', '', '', '', '', '', '', '']);
    this.currentPlayer.set('X');
    this.message.set('Your turn!');
    this.gameActive.set(true);
    this.winDetails.set(null);
  }

 getWinType(combo: number[]): string {
    if ([0, 1, 2].every(i => combo.includes(i)) || [3, 4, 5].every(i => combo.includes(i)) || [6, 7, 8].every(i => combo.includes(i))) {
      return 'horizontal';
    }
    if ([0, 3, 6].every(i => combo.includes(i)) || [1, 4, 7].every(i => combo.includes(i)) || [2, 5, 8].every(i => combo.includes(i))) {
      return 'vertical';
    }
    if ([0, 4, 8].every(i => combo.includes(i))) {
      return 'first-cross';
    }
    if ([2, 4, 6].every(i => combo.includes(i))) {
      return 'second-cross';
    }
    return '';
  }
}