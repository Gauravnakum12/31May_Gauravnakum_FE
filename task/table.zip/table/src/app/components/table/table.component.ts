import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../../services/user.service';
import { User, UserDataResponse } from '../../user.model';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    FloatLabelModule,
    DialogModule,
    ReactiveFormsModule
  ],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {

  private userDataService = inject(UserService);
  err = signal('');
  visible = signal(false);
  imgSrc: string = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
  userForm: FormGroup = new FormGroup({
    id: new FormControl<number | null>(null),
    avatar: new FormControl('', Validators.required),
    first_name: new FormControl('', Validators.required),
    last_name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  userData = signal<UserDataResponse>({
    page: 0,
    per_page: 0,
    total: 0,
    total_pages: 0,
    data: [],
    support: {
      url: '',
      text: '',
    }
  });

  first = 0;
  rows = 6;
  // totalRecords: number|undefined = this.userData().total;
  // recordsPerPage: number|undefined = this.userData().page;
  totalRecords:number =12; 
  totalPages:number =2;
  recordsPerPage: number = 6;
  currentPage: number = 1;
  pages: number[] = [];

  constructor(private router: Router, private route: ActivatedRoute) {}
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const page = params['page'] ? Number(params['page']) : 1;
      this.currentPage = page;
      this.loadUserData(page);
      this.calculatePages();
    });
  }
  

  calculatePages() {
    this.totalPages = Math.ceil(this.totalRecords / this.recordsPerPage);
    this.pages = Array(this.totalPages)
      .fill(0)
      .map((x, i) => i + 1);
  }

  loadUserData(page: number): void {
    this.userDataService.getUserData(page).subscribe({
      next: (users: UserDataResponse) => {
        // console.log( users);
        this.userData.set(users);
        // this.first = (page - 1) * this.rows;
      },
      error: (error: Error) => {
        this.err.set(error.message);
      },
    });
  }
  
  goToPage(page: number) {
    if (page < 1 || page > this.totalPages) return;
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { page: page },
    });
  }
  

  openNewUserDialog(): void {
    this.userForm.reset();
    this.visible.set(true);
    this.imgSrc = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
  }

  setImageSrc(): void {
    const avatarUrl = this.userForm.get('avatar')?.value;
    if (avatarUrl) {
      this.imgSrc = avatarUrl;
    } else {
      this.imgSrc = 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    }
  }
  
  editUser(user: User): void {
    this.userForm.setValue({ ...user });
    this.imgSrc = user.avatar || 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    this.visible.set(true);
  }

  getNewUserId(): number {
    const lastUser = this.userData().data[this.userData().data.length - 1];
    return lastUser ? lastUser.id + 1 : 1;
  }

  saveUser(): void {
    if (this.userForm.valid) {
      const userData: User = this.userForm.value as User;
      if (userData.id) {
        this.userDataService.updateUser(userData).subscribe({
          next: () => {
            this.loadUserData(this.currentPage!);
            this.visible.set(false);
          },
          error: (error: Error) => this.err.set(error.message),
        });
      } else {
        const newUser = { ...userData, id: this.getNewUserId() };
        this.userDataService.postNewUserData(newUser).subscribe({
          next: () => {
            this.loadUserData(this.currentPage!);
            this.visible.set(false);
          },
          error: (error: Error) => this.err.set(error.message),
        });
      }
      this.imgSrc = userData.avatar || 'https://png.pngtree.com/element_our/png/20181206/users-vector-icon-png_260862.jpg';
    }
  }

  deleteUser(userId: number): void {
    this.userDataService.deleteUser(userId).subscribe({
      next: () => this.loadUserData(this.currentPage!),
      error: (error: Error) => this.err.set(error.message),
    });
    // setTimeout(() => {
    //   this.userData().data = this.userData().data.filter(user => user.id !== userId);
    // }, 1000);
  }

  pageChange(event: { first: number; rows: number; }) {
    this.first = event.first;
    this.rows = event.rows;
  }

  get controls() {
    return this.userForm.controls;
  }
}
