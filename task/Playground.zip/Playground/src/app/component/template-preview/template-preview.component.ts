import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { NgForOf, NgIf } from '@angular/common';
// import { ComponentButtons, HeaderFormatEnum } from '../../../modules/template/models/template.model';
// import { BotService } from '../../../modules/bots/services/bot.service';

@Component({
  selector: 'app-template-preview',
  styleUrls: ['./template-preview.component.scss'],
  templateUrl: './template-preview.component.html',
  standalone: true,
  imports: [NgIf, NgForOf],
  changeDetection: ChangeDetectionStrategy.Default,
})
export class TemplatePreviewComponent implements OnChanges {
  @Input()
  header: string | undefined;
  @Input()
  headerMediaLink: string | undefined;
  // @Input()
  // headerMediaType: HeaderFormatEnum;
  @Input()
  body: string | undefined;
  @Input()
  footer: string | undefined;
  @Input()
  buttonType: string | undefined;
  @Input()
  // buttons: ComponentButtons;
  // constructor(public _botService: BotService) {}
  ngOnChanges(changes: SimpleChanges) {}
}
