export interface policeCreationData {
    name: string,
    description: string,
    isExpirable: boolean,
}

export interface policeResponse {
    message: string,
    data: policeResponseData
}

export interface policeResponseData {
    name: string,
    description: string,
    isExpirable: true,
    organization: string,
    policyFields: [],
    createdAt: Date,
    _id: string,
}
export interface simplePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    placeholder: string,
    value: string
}

export interface complexPolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
    value: string[]
}
export interface DatePolicyField {
    label: string,
    type: string,
    instruction_hints?: string,
}

export interface Policy {
    _id: string,
    createdAt: Date,
    description: string,
    isExpirable: boolean,
    name: string,
    organization: string,
    policyFields: [],
}

export interface PolicyField{
    _id:string,
    type:string,
    label:string,
    createdAt:Date,
    instruction_hints:string,
    organization:string,
    placeholder:string,
    policy:string,
    value:string[],
}