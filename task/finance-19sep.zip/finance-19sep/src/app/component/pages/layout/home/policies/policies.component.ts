import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Message } from 'primeng/api';
import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { policeCreationData, policeResponse } from '../../../../../finance.model';
import { PolicesService } from '../../../../services/api/polices.service';
import { DropdownModule } from 'primeng/dropdown';
import { Router } from '@angular/router';

import { TableLazyLoadEvent, TableModule } from 'primeng/table';
@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [TableModule, ButtonModule, DropdownModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, Button],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss'
})
export class PoliciesComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.getPolicy();
  }

  private policyService = inject(PolicesService);
  visible = signal(false);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyData = signal<policeResponse | null>(null);
  policyName: string = '';
  policyId: string = '';

  policyDataFetched = signal<[]>([]);
  cardData: any = [];
  optionData: string[] = [];

  // -------table----
  totalPage: number = 0;
  currentPage: number = 1;
  limit: number = 10;
  // messages: any = [];
  totalPoliciesRecord: number = 0;

  // ------------------------------- get policy -------------------------------------//
  loadPolicyLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / (event.rows || 1)) + 1;
    this.currentPage = page;
    this.limit = event.rows || 20;
  }

  getPolicy() {
    this.policyService.getPolicy().subscribe({
      next: (response: any) => {
        console.log(response.data);
        this.policyDataFetched.set(response.data);        // console.log(this.policyDataFetched);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }


  editPolicy(policy: any) {
    const policyId = policy._id
    console.log(policyId);
    this.router.navigate([`/home/policy/${policyId}`])
  }




  // ------------------------------card---------------------------------------

  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }

  // -----------------------------------------------poly-creation---------------------------------
  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [Validators.required, Validators.minLength(10)]),
    expirable: new FormControl(false),
  });

  savepolicies() {
    const sendPolicy: policeCreationData = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    }
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: policeResponse) => {
        this.policyData.set(response);
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName = response.data.name;
        this.policyId = response.data._id;
        console.log(response.data);
        this.policesForm.reset();
      },
      error: (error: any) => { console.error(error) }
    });

  }
  // ----------------------------------------------after-policy-created-------------------------

  // customInputDataType: string[] = ["text", "number", "date", "file", "dropdown", "radio"];

  felidsData: [] = [];

  // --------------------------------------------temple-form--------------------------------------
  addCard() {
    const newField: any = {
      label: '',
      type: 'text',
      name: '',
      description: '',
      instruction_hints: '',
      isExpirable: false,
      text: {
        value: '',
        placeholder: '',
      },
      options: [{
        value: ''
      }]
    }
    // this.cardData.push(newField);

    this.policyService.postInputField(newField, this.policyId).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response.data)
        // console.log(this.cardData);
      },
      error: (error: any) => { console.error(error) }
    })
  }

  updateField(card: any) {
    let tempAry: any = []

    if (card.options) {
      tempAry = card.options.map((data: any) => data.value)
    }

    const updatedField: any = {
      type: card.type,
      label: card.label,
      isExpirable: false,
      instruction_hints: card.instruction_hints,
      [card.type]: {
        values: tempAry,
        placeholder: card.placeholder || '',
      }
    };

    const passData = {
      formData: updatedField,
      cardId: card._id,
      policyId: this.policyId,
    };
    // console.log(updatedField[card.type].values);

    this.policyService.postUpdatedInputField(passData).subscribe({
      next: (response: any) => {
        // console.log(response);
        console.log(this.cardData);
      },
      error: (error: any) => { console.error(error); }
    });

  }

  deleteField(card: any, index: number) {
    const passData = {
      cardId: card._id,
      policyId: this.policyId,
    }
    this.policyService.deleteInputField(passData).subscribe({
      next: (response: any) => {
        this.cardData.splice(index, 1);
      },
      error: (error: any) => { console.error(error); }
    });
  }

  // -----------------add-option--------------------
  addOption(card: any) {
    if (!card.options) {
      card['options'] = [];
    }
    card.options.push({
      value: ''
    })
  }
  removeOption(card: any, index: number) {
    card.options.splice(index, 1)
  }


}



