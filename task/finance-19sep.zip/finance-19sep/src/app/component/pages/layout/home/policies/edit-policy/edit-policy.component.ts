import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { PolicesService } from '../../../../../services/api/polices.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
@Component({
  selector: 'app-edit-policy',
  standalone: true,
  imports: [ButtonModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule,],
  templateUrl: './edit-policy.component.html',
  styleUrls: ['./edit-policy.component.scss']
})
export class EditPolicyComponent implements OnInit {
  policy: any = '';
  policyIdFromRoute: any = '';
  cardData: any = [];
  policyName: string = '';
  policyDescription: string = '';
  policyExpirable: boolean = false;
  CreatedPoliceFelids:any = '';
  constructor(
    private policyDataService: PolicesService,
    private activeRoute: ActivatedRoute
  ) { }

  
  ngOnInit(): void {
    this.getPolicy();
    this.policyIdFromRoute = this.activeRoute.snapshot.paramMap.get('id');
    console.log(this.policyIdFromRoute);
    if (this.policyIdFromRoute) {
    }
  }

  getPolicy() {
    this.policyDataService.getAllPolicy().subscribe({
      next: (response: any) => {
        this.policy = response.data.find((p: any) => p._id === this.policyIdFromRoute);
        this.cardData.push(this.policy.policyFields);
        this.policyName = this.policy.name;
        this.policyDescription = this.policy.description;
        this.policyExpirable = this.policy.isExpirable;
        console.log(`Policy Object =`, this.policy);
        console.log(this.CreatedPoliceFelids);
      },
      error: (error: any) => {
        console.error(error);
      }
    });
  }

  updatePolicy() {

  }

  // --------------------------------------------temple-form--------------------------------------
  addCard() {
    const newField: any = {
      label: '',
      type: 'text',
      name: '',
      description: '',
      instruction_hints: '',
      isExpirable: false,
      text: {
        value: '',
        placeholder: '',
      },
      options: [{
        value: ''
      }]
    }
    // this.cardData.push(newField);

    this.policyDataService.postInputField(newField, this.policyIdFromRoute).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response.data)
        // console.log(this.cardData);
      },
      error: (error: any) => { console.error(error) }
    })
  }

  updateField(card: any) {
    let tempAry: any = []

    if (card.options) {
      tempAry = card.options.map((data: any) => data.value)
    }

    const updatedField: any = {
      type: card.type,
      label: card.label,
      isExpirable: false,
      instruction_hints: card.instruction_hints,
      [card.type]: {
        values: tempAry,
        placeholder: card.placeholder || '',
      }
    };

    const passData = {
      formData: updatedField,
      cardId: card._id,
      policyId: this.policyIdFromRoute,
    };
    // console.log(updatedField[card.type].values);

    this.policyDataService.postUpdatedInputField(passData).subscribe({
      next: (response: any) => {
        // console.log(response);
        console.log(this.cardData);
      },
      error: (error: any) => { console.error(error); }
    });

  }

  deleteField(card: any, index: number) {
    const passData = {
      cardId: card._id,
      policyId: this.policyIdFromRoute,
    }
    this.policyDataService.deleteInputField(passData).subscribe({
      next: (response: any) => {
        this.cardData.splice(index, 1);
      },
      error: (error: any) => { console.error(error); }
    });
  }

  // -----------------add-option--------------------
  addOption(card: any) {
    if (!card.options) {
      card['options'] = [];
    }
    card.options.push({
      value: ''
    })
  }
  removeOption(card: any, index: number) {
    card.options.splice(index, 1)
  }

}
