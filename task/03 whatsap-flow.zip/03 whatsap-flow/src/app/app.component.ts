import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';
import { CommonModule, NgClass, NgFor, NgIf, NgSwitch } from '@angular/common';
import { NgbAccordionModule, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import {
  CdkDragDrop,
  CdkDropList,
  CdkDragPreview,
  CdkDrag,
  moveItemInArray,
  CdkDragHandle,
} from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';
import { TemplatePreviewComponent } from './component/template-preview/template-preview.component';
import { ScreenComponent } from './component/screen/screen.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    CdkDragHandle,
    CdkDropList,
    CdkDrag,
    NgClass,
    FormsModule,
    NgSwitch,
    NgbDropdownModule,
    NgFor,
    NgIf,
    NgSwitch,
    NgbAccordionModule,
    TemplatePreviewComponent,
    ScreenComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
 
})
export class AppComponent implements OnInit {
  title = 'Playground';
  activeScreen: any = undefined;
  activeScreenIndex: number = 0;
  activeFormControl: any = undefined;
  newScreen: any = {
    id: 'screen_1',
    editScreenName: false,
    title: 'new screen',
    data: {},
    layout: {
      type: 'SingleColumnLayout',
      children: [
        {
          type: 'Form',
          name: 'flow_path',
          children: [
            {
             
              type: 'TextBody',
              text: 'text',
              editContent: false,
            },
            
          ],
        },
      ],
    },
  };

  constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
    this.activeScreen = this.whatsapp_FlowJson.screens[0];
    if (this.screens.length < 0) {
      this.whatsapp_FlowJson.screens.push(this.newScreen);
    }
  }
  onImageSelected(event: any) {
    if (event.target.files.length > 0) {

    }
  }
  setText_SumMeu(submenuItem: string, index: number) {
    console.log(submenuItem);
    console.log(index);

    this.activeScreen.layout.children[0].children[index].type =
      submenuItem.trim();
    console.log(this.activeScreen.layout);
  }

  addNewScreen() {
    this.whatsapp_FlowJson.screens.push(this.newScreen);
  }
  saveScreenName(index: number) {
    console.log(index);
    this.whatsapp_FlowJson.screens[index].editScreenName = false;
  }
  editScreenName(index: number) {
    this.whatsapp_FlowJson.screens[index].editScreenName = true;
  }
  deleteScreen(index: number) {
    this.whatsapp_FlowJson.screens.splice(index, 1);
  }

  deleteFormControl(index: number) {
    this.whatsapp_FlowJson.screens[this.activeScreenIndex].layout.children[0].children.splice(index, 1)
  }
  setActiveScreen(index: number) {
    this.activeScreen = this.whatsapp_FlowJson.screens[index];
    this.activeScreenIndex = index;
  }

  setActiveContent(activeFormControl: any) {
    if (this.activeFormControl == activeFormControl) {
      this.activeFormControl = undefined;
    } else {
      this.activeFormControl = activeFormControl;
    }
  }

  moveScreen(event: any) {
    moveItemInArray(this.screens, event.previousIndex, event.currentIndex);
  }

  moveScreen_FormControl(event: any) {
    // moveItemInArray(this.whatsapp_FlowJson, event.previousIndex, event.currentIndex);
  }
  removeImage(index: number) {
    this.whatsapp_FlowJson.screens[this.activeScreenIndex].layout.children[0].children[index].src = '';
  }

  deleteOption(contentIndex: number, optionIndex: number) {
    const screen = this.whatsapp_FlowJson.screens[this.activeScreenIndex];
    const form = screen.layout.children[0].children[contentIndex];
    if (form['data-source'] && Array.isArray(form['data-source'])) {
      form['data-source'].splice(optionIndex, 1);
    }
  }

  addOption(contentIndex: number) {
    const screen = this.whatsapp_FlowJson.screens[this.activeScreenIndex];
    const form = screen.layout.children[0].children[contentIndex];
    if (form['data-source'] && Array.isArray(form['data-source'])) {
      form['data-source'].push({ id: `${form['data-source'].length}_0_Option_${form['data-source'].length}`, title: 'Option' });
    }
  }

  screens: Array<any> = [
    { title: 'Feedback 1 of 2', editScreenName: false },
    { title: 'screen-2', editScreenName: false },
    { title: 'screen-3', editScreenName: false },
  ];
  contentArray = [
    {
      menuItemName: 'Text',
      menuItemImage: './assets/images/icons/10.img.svg',
      submenu: ['TextHeading', 'TextCaption', 'TextBody', 'TextSubheading'],
    },
    {
      menuItemName: 'Image',
      menuItemImage: './assets/images/icons/10.img.svg',
      submenu: ['Image'],
    },
    {
      menuItemName: 'Text Answer',
      menuItemImage: ' ./assets/images/icons/10.img.svg',
      submenu: ['Short Answer', 'Paragraph', 'Date picker','TextInput'],
    },
    {
      menuItemName: 'Selection',
      menuItemImage: './assets/images/icons/10.img.svg',
      submenu: ['Single choice', 'Multiple Choice', 'Dropdown', 'Opt-in'],
    },
  ];

  whatsapp_FlowJson: any =
   {
    version: '5.1',
    screens: [
      {
        id: 'screen_1',
        editScreenName: false,
        title: 'screen - 1',
        data: {},
        layout: {
          type: 'SingleColumnLayout',
          children: [
            {
              type: 'Form',
              name: 'flow_path',
              children: [
                {
                  type: 'TextCaption',
                  text: 'large-hedaing -80word',
                  editContent: false,
                },
                {
                  type: 'TextSubheading',
                  text: 'Small heading 80-charchter',
                  editContent: false,
                },
                {
                  type: 'TextHeading',
                  text: 'caption  4096-charchter',
                  editContent: false,
                },
                {
                  type: 'TextBody',
                  text: 'body -4096 charchter',
                  editContent: false,
                },
                {
                  type: 'Image',
                  src: 'https://th.bing.com/th/id/OIP.vggFhcDaZAZ0BLI1MKgUzgHaD-?rs=1&pid=ImgDetMain   ',
                  height: 400,
                  'scale-type': 'contain',
                  editContent: false,
                },
                {
                  type: 'TextInput',
                  name: 'TextInput_27b31f',
                  label: 'Label 5 - charchter',
                  required: true,
                  'input-type': 'text',
                  'helper-text': 'instruction - 80 ',
                  editContent: false,
                },
                {
                  type: 'TextInput',
                  label: 'password lable -20',
                  name: 'TextInput_05c41f',
                  required: false,
                  'input-type': 'password',
                  'helper-text': 'password-80 word',
                  editContent: false,
                },
                {
                  type: 'TextInput',
                  label: 'email-Label 20 charc',
                  name: 'TextInput_a17646',
                  required: true,
                  'input-type': 'email',
                  'helper-text': 'email-instruction  80 - charch',
                  editContent: false,
                },
                {
                  type: 'Footer',
                  label: 'Continue to next screen',
                  'on-click-action': {
                    name: 'navigate',
                    next: { type: 'screen', name: 'screen_wnnsmc' },
                    payload: {
                      screen_0_TextInput_0: '${form.TextInput_27b31f}',
                      screen_0_TextInput_1: '${form.TextInput_05c41f}',
                      screen_0_TextInput_2: '${form.TextInput_a17646}',
                    },
                  },
                },
              ],
            },
          ],
        },
      },
      {
        id: 'screen_2',
        editScreenName: false,
        title: 'screen - 2',
        data: {
          screen_0_TextInput_0: { type: 'string', __example__: 'Example' },
          screen_0_TextInput_1: { type: 'string', __example__: 'Example' },
          screen_0_TextInput_2: { type: 'string', __example__: 'Example' },
        },
        terminal: true,
        layout: {
          type: 'SingleColumnLayout',
          children: [
            {
              type: 'Form',
              name: 'flow_path',
              children: [
                {
                  type: 'TextArea',
                  label: 'paragr -30 charch ',
                  required: false,
                  name: 'TextArea_a792c7',
                  'helper-text': 'inst-80 charch and after lable 20 char show warnning of lable',
                },
                {
                  type: 'DatePicker',
                  label: 'datepicker lab -20 c',
                  required: true,
                  name: 'DatePicker_43cf12',
                  'helper-text': 'ins -80 ',
                },
                {
                  type: 'RadioButtonsGroup',
                  label: 'RadioButton Label',
                  required: false,
                  name: 'RadioButtonsGroup_526e72',
                  'data-source': [
                    { id: '0_Option_1', title: 'Option 1' },
                    { id: '1_Option_2', title: 'Option 2' },
                    { id: '3_Option_3', title: 'Option 3' },
                    { id: '4_Option_4', title: 'Option 4' },
                  ],
                },
                {
                  type: 'CheckboxGroup',
                  label: 'CheckboxGroup Label',
                  required: true,
                  name: 'CheckboxGroup_1474ab',
                  'data-source': [
                    { id: '0_Option_1', title: 'Option 1' },
                    { id: '1_Option_2', title: 'Option 2' },
                  ],
                },
                {
                  type: 'CheckboxGroup',
                  label: 'Label',
                  required: true,
                  name: 'Dropdown_3ec6b5',
                  'data-source': [
                    { id: '0_Option_1', title: 'Option 1' },
                    { id: '1_Option_2', title: 'Option 2' },
                  ],
                },
                {
                  type: 'Dropdown',
                  label: 'drop down lable',
                  required: true,
                  name: 'Dropdown_373a87',
                  'data-source': [
                    { id: '0_drop_down_Option_1', title: 'drop down Option 1' },
                    { id: '1_drop_down_Option_2', title: 'drop down Option 2' },
                  ],
                },
                {
                  type: 'OptIn',
                  label: 'read more link',
                  required: true,
                  name: 'OptIn_b44849',
                  'on-click-action': {
                    name: 'navigate',
                    payload: {},
                    next: {
                      name: 'OPTIN_SCREEN_screen_okejoj',
                      type: 'screen',
                    },
                  },
                },
                {
                  type: 'Footer',
                  label: 'Continue',
                  'on-click-action': {
                    name: 'complete',
                    payload: {
                      screen_1_TextArea_0: '${form.TextArea_a792c7}',
                      screen_1_DatePicker_1: '${form.DatePicker_43cf12}',
                      screen_1_RadioButtonsGroup_2:
                        '${form.RadioButtonsGroup_526e72}',
                      screen_1_CheckboxGroup_3: '${form.CheckboxGroup_1474ab}',
                      screen_1_Dropdown_4: '${form.Dropdown_3ec6b5}',
                      screen_1_OptIn_5: '${form.OptIn_b44849}',
                      screen_0_TextInput_0: '${data.screen_0_TextInput_0}',
                      screen_0_TextInput_1: '${data.screen_0_TextInput_1}',
                      screen_0_TextInput_2: '${data.screen_0_TextInput_2}',
                    },
                  },
                },
              ],
            },
          ],
        },
      },
      {
        id: 'OPTIN_SCREEN_screen_okejoj',
        title: 'Read more',
        data: {},
        layout: {
          type: 'SingleColumnLayout',
          children: [
            {
              type: 'Form',
              name: 'flow_path',
              children: [{ type: 'TextBody', text: 'Text' }],
            },
          ],
        },
      },
    ],
  };

  addContent(item: any) {
    const activeScreen = this.whatsapp_FlowJson.screens[this.activeScreenIndex];
  
    if (!activeScreen.layout || !activeScreen.layout.children || !Array.isArray(activeScreen.layout.children)) {
      return;
    }

    const firstChild = activeScreen.layout.children[0];
  
    if (!firstChild.children || !Array.isArray(firstChild.children)) {
      console.error('Invalid children structure in the first child');
      return;
    }
  
    switch (item) {
      case 'TextHeading':
        firstChild.children.push({
          type: 'TextHeading',
          text: 'Small heading 80-character',
          editContent: false,
        });
        break;
  
      case 'TextSubheading':
        firstChild.children.push({
          type: 'TextSubheading',
          text: '',
          editContent: false,
        });
        break;
  
      case 'TextBody':
        firstChild.children.push({
          type: 'TextBody',
          text: '',
          editContent: false,
        });
        break;
  
      case 'TextCaption':
        firstChild.children.push({
          type: 'TextCaption',
          text: '',
          editContent: false,
        });
        break;

        case 'Image':
          firstChild.children.push({
            type: 'Image',
            src: '',
            height: 400,
            'scale-type': 'contain',
            editContent: false,
          });
          break;

          case 'TextInput':
            firstChild.children.push(               {
              type: 'TextInput',
              name: '',
              label: 'text - label',
              required: true,
              'input-type': 'text',
              'helper-text': ' ',
              editContent: false,
            },);
            break;
          
  
      default:
        console.warn(`Unhandled item type: ${item}`);
    }
  }
    
  }

