import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
// import { ComponentButtons, HeaderFormatEnum } from '../../../modules/template/models/template.model';
// import { BotService } from '../../../modules/bots/services/bot.service';

@Component({
  selector: 'app-template-preview',
  styleUrls: ['./template-preview.component.scss'],
  templateUrl: './template-preview.component.html',
  standalone: true,
  imports: [NgIf,NgFor,CommonModule,FormsModule],
  changeDetection: ChangeDetectionStrategy.Default,
})
export class TemplatePreviewComponent implements OnChanges {
  sidebarFlag = true;
  @Input()
  header: string | undefined;

  @Input () screen: any;
  // buttons: ComponentButtons;
  // constructor(public _botService: BotService) {}
  ngOnChanges(changes: SimpleChanges) {}
  openPreview(){
    this.sidebarFlag = !this.sidebarFlag;
  }
}
