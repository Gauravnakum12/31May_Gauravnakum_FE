import { Component, Input, input } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule, NgClass, NgFor, NgIf, NgSwitch } from '@angular/common';
import { NgbAccordionModule, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import {
  CdkDragDrop,
  CdkDropList,
  CdkDragPreview,
  CdkDrag,
  moveItemInArray,
  CdkDragHandle,
} from '@angular/cdk/drag-drop';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-screen',
  standalone: true,
  imports: [ CommonModule,
    CdkDragHandle,
    CdkDropList,
    CdkDrag,
    NgClass,
    FormsModule,
    NgSwitch,
    NgbDropdownModule,
    NgFor,
    NgIf,
    NgSwitch,
    NgbAccordionModule,],
  templateUrl: './screen.component.html',
  styleUrl: './screen.component.scss'
})
export class ScreenComponent {
  @Input () screen: any;
  @Input () activeScreenId: any;
  nameEditable = false;

  editScreenTitle(){
    
  }
}
