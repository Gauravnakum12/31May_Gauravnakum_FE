import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { environment } from '../';
import { BehaviorSubject, catchError, Observable, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UploadMediaService {
  UPLOAD_URL =  '/upload'; //environment.API_URL +

  loading$ = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient) {}

  uploadFile(file: any, type: 'Inventory' | 'Artist' | 'Vendor' | 'Theme' | 'Event'): Observable<{ message: string; url: string }> {
    this.loading$.next(true);
    const fd = new FormData();
    fd.append('file', file, file.name);
    return this.http.post<{ message: string; url: string }>(this.UPLOAD_URL + '/' + type, fd).pipe(
      tap(() => {
        this.loading$.next(false);
      }),
      catchError(err => {
        this.loading$.next(false);
        return throwError(err);
      })
    );
  }
}
