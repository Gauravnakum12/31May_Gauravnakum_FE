import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { policeCreationData, policeResponseData, policeResponse } from '../../../finance.model';
@Injectable({
  providedIn: 'root'
})
export class PolicesService {
  constructor(private http: HttpClient) { }
  private apiUrl = 'https://ctwvk1rh-3001.inc1.devtunnels.ms/policy';

  postNewPolices(policy: policeCreationData): Observable<policeResponse> {
    return this.http.post<policeResponse>(this.apiUrl, policy);
  }


  postNewInputFieldCard(InputFieldCard:any,policyId:string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/${policyId}/policyFields`,InputFieldCard);
  }
  // getSinglePolicesData(id): Observable<> {
  //   const url = `${this.apiUrl}/${id}`;
  //   return this.http.get<>(url);
  // }




}
