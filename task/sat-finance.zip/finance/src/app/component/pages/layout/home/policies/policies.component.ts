import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Message } from 'primeng/api';
import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { policeCreationData, policeResponse, policeResponseData } from '../../../../../finance.model';
import { PolicesService } from '../../../../services/api/polices.service';

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [ButtonModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, Button],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss'
})
export class PoliciesComponent {

  private policyService = inject(PolicesService);

  visible = signal(false);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyData = signal<policeResponse | null>(null);
  policyName: string  = '';
  policyId: string = '';
  
  // ----------------------------------------------------------------card---------------
  cardData: any = [];

  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }

  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [Validators.required, Validators.minLength(100)]),
    expirable: new FormControl(false),
  });

  savepolicies() {
    const sendPolicy: policeCreationData = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    }
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: policeResponse) => {
        this.policyData.set(response);
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName = response.data.name;
        this.policyId = response.data._id;
        console.log(response.data);
    
      },
      error: (error: any) => { console.error(error) }
    });
  }
  // ----------------------policy-creation-------------------------

  customInputDataType: string[] = ["text", "number", "date", "file", "dropdown", "radio"];
   OptionValue:string[] = []
   newField: any =  {
    label: '',
    type: 'text',
    instruction_hints: '',
    text: {
      value: '',
      placeholder: ""
    }

   }
   afterInputTypeSelected :any = [
     {
      label: '',
      type: ['text','number','file',],
      instruction_hints: '',
      text: {
        value: '',
        placeholder: '',
      }
     },
     {
      label: '',
      type: 'date',
      instruction_hints: '',
      text: {
        value: '',
        placeholder: ""
      }
     },
     {
      label: '',
      type: ['dropdown','radio'],
      instruction_hints: '',
      multiple: {
        value: '',
        placeholder: ""
      }
     },

   ]
  addOptionValue(){
this.OptionValue.push(this.newField)
  }
  addCard() {

    // this.policyService.postNewInputFieldCard(newField, this.policyId).subscribe({
    //   next: (response: any) => {
    //     this.cardData.push(response)
    //   },
    //   error: (error: Error) => { console.error(error) }
    // })
    this.cardData.push(this.newField)
  }

  updateFieldForm = new FormGroup({
    label: new FormControl(''),
    selectInput: new FormControl('text'),
    inputType: new FormControl(''),
    instructionHints: new FormControl(''),
  })
  updateField(event: Event) {
    event.preventDefault();
  }

}








// export class PoliciesComponent {
//   policyForm: FormGroup;
//   policies: Array<{ options: Array<{ value: string, readonly: boolean }> }> = [];
//   previewData: Array<{ label: string, type: string, options?: string[], instruction_hints?: string }> = [];

//   constructor(private fb: FormBuilder) {
//     // Define the structure of your form
//     this.policyForm = this.fb.group({
//       inputType: ['text'],
//       label: [''],
//       instruction_hints: ['']
//     });
    
//     // Example: Add a default policy
//     this.policies.push({
//       options: []
//     });
//   }

//   onInputTypeChange(policyIndex: number) {
//     // Logic to handle input type change
//   }

//   addOption(policyIndex: number) {
//     // Add a new option for dropdown or radio types
//     this.policies[policyIndex].options.push({ value: '', readonly: false });
//   }

//   editOption(policyIndex: number, optionIndex: number) {
//     // Allow editing of an option
//     this.policies[policyIndex].options[optionIndex].readonly = false;
//   }

//   saveOption(policyIndex: number, optionIndex: number) {
//     // Mark option as readonly
//     this.policies[policyIndex].options[optionIndex].readonly = true;
//   }

//   deleteOption(policyIndex: number, optionIndex: number) {
//     // Remove an option
//     this.policies[policyIndex].options.splice(optionIndex, 1);
//   }

//   saveField(policyIndex: number) {
//     // Update the preview section based on current form values
//     const formValue = this.policyForm.value;
//     const options = this.policies[policyIndex].options.map(option => option.value);

//     this.previewData.push({
//       label: formValue.label,
//       type: formValue.inputType,
//       options: options.length ? options : undefined,
//       instruction_hints: formValue.instruction_hints
//     });
//   }
// }