import { Component } from '@angular/core';
import { ToDocontainerComponent } from "./to-do-container/to-do-container.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ ToDocontainerComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'TODO';
}
