import { Injectable, signal } from '@angular/core';
import { TODO } from './to-do-model';
@Injectable({ providedIn: 'root' })

export class TodoService {
  
  dataTransferItem: any = signal<any>([]);
  todo = signal<TODO[]>([])
  allTodo = this.todo.asReadonly();

  addtodo(todoData: { title: string }) {
    let newTodo: TODO = {
      ...todoData,
      id: (Math.random() * 100).toString(),
      isCompleted: false
    }
    this.todo.update((oldTodo: any) => [...oldTodo, newTodo])
  }

  updateTodoStatus(todoId: string,) {
    this.todo.update((todoData: any) => todoData.map((item: any) => item.id === todoId ? { ...item, isCompleted: !item.isCompleted } : item))
  }

  deleteTodoItem(todoId: string) {
    this.todo.update((todoData: any) => todoData.filter((item: any) => item.id !== todoId))
  }
  editTodoItem(todoId: string) {
    this.dataTransferItem = this.todo().filter((item: any) => item.id == todoId)[0];
    console.log(this.dataTransferItem);
    console.log(this.dataTransferItem.title);
  }
}
