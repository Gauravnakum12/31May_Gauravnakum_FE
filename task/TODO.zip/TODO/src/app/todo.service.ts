import { Injectable, signal } from '@angular/core';
import { TODO, } from './to-do-model';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  todo = signal<TODO[]>([])
  allTodo = this.todo.asReadonly();

  addtodo(todoData: { title: string }) {
    let newTodo: TODO = {
      ...todoData,
      id: Math.random().toString(),
      isCompleted:false
    }
    this.todo.update((oldTodo) => [...oldTodo, newTodo])
  }
  updateTasksStatus(todoId: string, ) {
    this.todo.update((oldTasks) => oldTasks.map((item) => item.id === todoId ? { ...item,isCompleted:!item.isCompleted } : item))
  }

}