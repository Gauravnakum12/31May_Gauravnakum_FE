
export interface TODO {
  id: string;
  title: string;
  isCompleted: boolean;
}