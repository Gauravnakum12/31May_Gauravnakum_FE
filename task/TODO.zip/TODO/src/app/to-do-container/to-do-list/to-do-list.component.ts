import { Component, inject } from '@angular/core';
import { TodoItemComponent } from "./todo-item/todo-item.component";
import { TodoService } from '../../todo.service';

@Component({
  selector: 'app-to-do-list',
  standalone: true,
  imports: [TodoItemComponent],
  templateUrl: './to-do-list.component.html',
  styleUrl: './to-do-list.component.css'
})
export class ToDoListComponent {
  private tservice = inject(TodoService) 
  todoData = this.tservice.allTodo;
}
