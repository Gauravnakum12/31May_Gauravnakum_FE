import { Component, inject, input, Input } from '@angular/core';
import { TODO } from '../../../to-do-model';
import { FormsModule } from '@angular/forms';
import { TodoService } from '../../../todo.service';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-todo-item',
  standalone: true,
  imports: [FormsModule,NgClass],
  templateUrl: './todo-item.component.html',
  styleUrl: './todo-item.component.css'
})
export class TodoItemComponent {
  tservice = inject(TodoService)
  todoData = input.required<TODO>();
  changeStatus(id:string){
    this.tservice.updateTasksStatus(id)
  }                                                                                                      
}
