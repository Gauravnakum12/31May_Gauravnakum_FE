import { Component, inject, input } from '@angular/core';
import { TODO } from '../../../to-do-model';
import { TodoService } from '../../../todo.service';
import { NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todo-item',
  standalone: true,
  imports: [FormsModule,NgClass],
  templateUrl: './todo-item.component.html',
  styleUrl: './todo-item.component.css'
})
export class TodoItemComponent {
  
  tservice = inject(TodoService)
  todoData = input.required<TODO>();

  changeStatus(id:string){
    this.tservice.updateTodoStatus(id)
  }          
   
  deleteTodo(id:string){
    this.tservice.deleteTodoItem(id)
  }
  editTodo(id:string){
    this.tservice.editTodoItem(id)
  }
}
