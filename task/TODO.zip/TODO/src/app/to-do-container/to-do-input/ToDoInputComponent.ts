import { Component,viewChild, ElementRef } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { TodoService } from "../../todo.service";

@Component({
  selector: 'app-to-do-input',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './to-do-input.component.html',
  styleUrl: './to-do-input.component.css'
})

export class ToDoInputComponent {

  
  private formEl = viewChild<ElementRef<HTMLFormElement>>('form');
   private tservice: TodoService;

constructor( private mytodo: TodoService) {
    this. tservice = mytodo;
  }

  onSubmit(title: string) {

    if (title.trim() !== '') {
      console.log(title);
      this.tservice.addtodo({title})
      this.formEl()?.nativeElement.reset();
    }
    else {
      alert('Please enter a value.');
    }
  }
}

