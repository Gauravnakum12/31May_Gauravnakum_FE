import { Component, inject, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { TodoService } from "../../todo.service";
import { FormsModule } from "@angular/forms";
import { toObservable } from "@angular/core/rxjs-interop";

@Component({
  selector: 'app-to-do-input',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './to-do-input.component.html',
  styleUrl: './to-do-input.component.css'
})

export class ToDoInputComponent implements OnInit {
  // towWayBindin Variable 
  todoDataTitle = ''
  private tservice = inject(TodoService)

  // Observable
  getdata$ = toObservable(this.tservice.dataTransferItem)

  ngOnInit(): void {

    // if (this.tservice.dataTransferItem.title !== '') {
    //   this.getdata$.subscribe({
    //     next: () => this.todoDataTitle = this.tservice.dataTransferItem.title,
    //   })
    // }
    
    this.getdata$.subscribe({
      next: () => this.todoDataTitle = this.tservice.dataTransferItem.title,
    })
  }

  onSubmit() {
    if (this.todoDataTitle.trim() !== '') {

      this.tservice.addtodo({
        title: this.todoDataTitle
      })
      this.todoDataTitle = '';
    }
    else {
      alert('Please enter a value.');
    }
  }
}

