import { Component } from '@angular/core';
import { HeaderComponent } from "./header/header.component";
import { ToDoInputComponent } from './to-do-input/To-do-InputComponent';
import { ToDoListComponent } from "./to-do-list/to-do-list.component";

@Component({
  selector: 'app-to-do-container',
  standalone: true,
  imports: [HeaderComponent, ToDoInputComponent, ToDoListComponent],
  templateUrl: './to-do-container.component.html',
  styleUrl: './to-do-container.component.css'
})
export class ToDocontainerComponent {

}
