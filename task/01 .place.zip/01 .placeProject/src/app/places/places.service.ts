import { inject, Injectable, signal } from '@angular/core';
import { catchError, map, Observable, tap, throwError, } from 'rxjs';
import { Place } from './place.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PlacesService {

  private httpClient = inject(HttpClient)
  private userPlaces = signal<Place[]>([]);
  loadedUserPlaces = this.userPlaces.asReadonly();

  loadAvailablePlaces(): Observable<Place[]> {
    return this.fetchPlaces('http://localhost:3000/places', 'somthing went wrong it masssege frome throwError')
  }

  loadUserPlaces() {
    return this.fetchPlaces('http://localhost:3000/user-places', 'somthing went wrong we can not featch favorite place').pipe(tap({
      next: (userPlaces) => this.userPlaces.set(userPlaces)
    }));
  }

  addPlaceToUserPlaces(place: Place): Observable<Place> {
    this.userPlaces.update(prevPlaces => [...prevPlaces, place])
    return this.httpClient.put<Place>('http://localhost:3000/user-places',
      { placeId: place.id })
  }

  removeUserPlace(place: Place) { }

  private fetchPlaces(url: string, errorMessage: string) {
    return this.httpClient.get<{ places: Place[] }>(url)
      .pipe(map((resData) => resData.places),
        catchError((error, obs) => throwError(() => new Error(errorMessage))))
  }
}
