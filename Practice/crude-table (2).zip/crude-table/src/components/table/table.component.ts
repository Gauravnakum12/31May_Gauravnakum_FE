import { CommonModule } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../services/user.service';
import { User } from '../../app/user.model';
import { FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { HttpClientModule, provideHttpClient } from '@angular/common/http';
@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule, ButtonModule, TableModule,FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
})
export class TableComponent {
  // userData = signal<User[]>([]);
  // err = signal('');

  constructor(private userDataService: UserService) { }
  // ngOnInit(): void {
  //   this.userDataService.getUserData().subscribe({
  //     next: (users: any) => {
  //       this.userData.set(users)
  //     },
  //     error: (error: Error) => {
  //       this.err.set(error.message)
  //     },
  //   })
  // }

  userData = this.userDataService.dataSignal();

  first = 0;
  rows = 6;
  next() {
    this.first = this.first + this.rows;
  }
  prev() {
    this.first = this.first - this.rows;
  }
  reset() {
    this.first = 0;
  }
  isFirstPage(): boolean {
    return this.userData.data ? this.first === 0 : true;
  }
    pageChange(event: { first: number; rows: number; }) {
    this.first = event.first;
    this.rows = event.rows;
  }

  isLastPage(): boolean {
    return this.userData.data ? this.first === this.userData.data.length - this.rows : true;
  }
}