// import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { User, UserDataResponse, } from '../app/user.model';
import { Observable, tap } from 'rxjs';
@Injectable({
  providedIn: 'root'
})

export class UserService {
  // private apiUrl = 'https://reqres.in/api/users';
  // constructor(private httpClient: HttpClient) { }

  // getUserData() {
  //   return this.httpClient.get<UserDataResponse>(this.apiUrl).pipe(
  //     tap(response => this.userData.set(response))
  //   )
  // }

  // postNewUserData(user: User): Observable<User> {
  //   return this.httpClient.post<User>(this.apiUrl, user)
  //     .pipe(tap(response => {
  //       this.getUserData()
  //     }),
  //     )
  // }
  // updateUser(user: User): Observable<User> {
  //   const url = `${this.apiUrl}/${user.id}`;
  //   return this.httpClient.put<User>(url, user)
  //     .pipe(tap(response => {
  //       this.getUserData();
  //     })
  //     );
  // }
  // private userData = signal<UserDataResponse | null>(null);
  private Data: UserDataResponse = {
    page: 1,
    per_page: 6,
    total: 12,
    total_pages: 2,
    data: [
      { id: 1, email: "george.bluth@reqres.in", first_name: "George", last_name: "Bluth", avatar: "https://reqres.in/img/faces/1-image.jpg" },
      { id: 2, email: "janet.weaver@reqres.in", first_name: "Janet", last_name: "Weaver", avatar: "https://reqres.in/img/faces/2-image.jpg" },
      { id: 3, email: "emma.wong@reqres.in", first_name: "Emma", last_name: "Wong", avatar: "https://reqres.in/img/faces/3-image.jpg" },
      { id: 4, email: "eve.holt@reqres.in", first_name: "Eve", last_name: "Holt", avatar: "https://reqres.in/img/faces/4-image.jpg" },
      { id: 5, email: "charles.morris@reqres.in", first_name: "Charles", last_name: "Morris", avatar: "https://reqres.in/img/faces/5-image.jpg" },
      { id: 6, email: "tracey.ramos@reqres.in", first_name: "Tracey", last_name: "Ramos", avatar: "https://reqres.in/img/faces/6-image.jpg" }
    ],
    support: {
      url: "https://reqres.in/#support-heading",
      text: "To keep ReqRes free, contributions towards server costs are appreciated!"
    }
  };

  dataSignal = signal<UserDataResponse>(this.Data);
}
