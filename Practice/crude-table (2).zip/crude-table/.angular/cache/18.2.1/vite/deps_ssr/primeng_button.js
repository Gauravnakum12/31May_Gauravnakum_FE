import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-OM7JLH26.js";
import "./chunk-MOQUW5ZZ.js";
import "./chunk-E7STEE66.js";
import "./chunk-MERWBA6M.js";
import "./chunk-NQ4HTGF6.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
