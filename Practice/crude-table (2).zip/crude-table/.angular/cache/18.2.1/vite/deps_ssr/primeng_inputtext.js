import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  InputText,
  InputTextModule
} from "./chunk-VOFQV6O5.js";
import "./chunk-H7VOTZBG.js";
import "./chunk-MOQUW5ZZ.js";
import "./chunk-E7STEE66.js";
import "./chunk-MERWBA6M.js";
import "./chunk-NQ4HTGF6.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
