import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { User, UserDataResponse } from '../app/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'https://reqres.in/api/users';
  userData = signal<UserDataResponse | null>(null);
  err = signal<string|null>(null);

  constructor(private httpClient: HttpClient) { }

  getUserData(): Observable<UserDataResponse> {
    return this.httpClient.get<UserDataResponse>(this.apiUrl).pipe(
      tap(response => this.userData.set(response))
    );
  }

  postNewUserData(user: User): Observable<User> {
    return this.httpClient.post<User>(this.apiUrl, user).pipe(
      tap(response => this.getUserData())
    );
  }

  updateUser(user: User): Observable<User> {
    const url = `${this.apiUrl}/${user.id}`;
    return this.httpClient.put<User>(url, user).pipe(
      tap(response => this.getUserData())
    );
  }
}
