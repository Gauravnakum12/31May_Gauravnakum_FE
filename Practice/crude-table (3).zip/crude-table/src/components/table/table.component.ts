import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../services/user.service';
import { User, UserDataResponse } from '../../app/user.model';
import { FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule, ButtonModule, TableModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule,FloatLabelModule,DialogModule],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
})
export class TableComponent {
  private userDataService = inject(UserService)
  userData = signal<UserDataResponse>({
    page: 0,
    per_page: 0,
    total: 0,
    total_pages: 0,
    data: [],
    support: {
      url: '',
      text: ''
    }
  });
  err = signal('');

  ngOnInit(): void {
    this.userDataService.getUserData().subscribe({
      next: (users: UserDataResponse) => {
        this.userData.set(users)
      },
      error: (error: Error) => {
        this.err.set(error.message)
      },
    })
  }
  first = 0;
  rows = 6;
  next() {
    this.first = this.first + this.rows;
  }
  prev() {
    this.first = this.first - this.rows;
  }
  reset() {
    this.first = 0;
  }
  isFirstPage(): boolean {
    return this.userData().data ? this.first === 0 : true;
  }
  pageChange(event: { first: number; rows: number; }) {
    this.first = event.first;
    this.rows = event.rows;
  }

  isLastPage(): boolean {
    return this.userData().data ? this.first === this.userData().data.length - this.rows : true;
  }

  //dilog
  visible: boolean = false;

  showDialog() {
      this.visible = true;
  }
}