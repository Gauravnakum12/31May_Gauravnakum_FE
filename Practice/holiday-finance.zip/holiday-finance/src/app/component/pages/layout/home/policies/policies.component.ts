import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators } from '@angular/forms';
import { Message } from 'primeng/api';
import { Button, ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { MessagesModule } from 'primeng/messages';
import { policeCreationData, policeResponse, policeResponseData } from '../../../../../finance.model';
import { PolicesService } from '../../../../services/api/polices.service';

@Component({
  selector: 'app-policies',
  standalone: true,
  imports: [ButtonModule, CommonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe, MessagesModule, Button],
  templateUrl: './policies.component.html',
  styleUrl: './policies.component.scss'
})
export class PoliciesComponent {

  private policyService = inject(PolicesService);

  visible = signal(false);
  isPolicyCreated = signal<boolean>(false);
  messages: Message[] = [];
  policyData = signal<policeResponse | null>(null);
  policyName: string = '';
  policyId: string = '';


  // ----------------------------------------------------------------card---------------
  cardData: any = [];
  optionData: string[] = [];
  openNewPoliciesDialog() {
    this.visible.set(true);
  }
  get controls() {
    return this.policesForm.controls;
  }

  // ----------------------------------------------------poly-creation-------------------------------------
  policesForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', [Validators.required, Validators.minLength(10)]),
    expirable: new FormControl(false),
  });

  savepolicies() {
    const sendPolicy: policeCreationData = {
      name: this.policesForm.value.name,
      description: this.policesForm.value.description,
      isExpirable: this.policesForm.value.expirable,
    }
    this.policyService.postNewPolices(sendPolicy).subscribe({
      next: (response: policeResponse) => {
        this.policyData.set(response);
        this.isPolicyCreated.set(true);
        this.policesForm.reset();
        this.visible.set(false);
        this.policyName = response.data.name;
        this.policyId = response.data._id;
        console.log(response.data);

      },
      error: (error: any) => { console.error(error) }
    });
  }
  // --------------------------------------------------after-policy-created-------------------------

  // customInputDataType: string[] = ["text", "number", "date", "file", "dropdown", "radio"];
  felidsData: [] = [];
  addCard() {
    const newField: any = {
      label: '',
      type: 'text',
      name:'a',
      description:'a',
      instruction_hints: 'a',
      isExpirable:false,
      text: {
        value: '',
        placeholder:this.placeholderData,
      }
    }
    this.policyService.postInputField(newField,this.policyId).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response)

      },
      error: (error: any) => { console.error(error) }
    })

  }

  // ------templet-form----------------
  inputType = 'text';
  label = '';
  instruction_hints = '';
  placeholderData = '';

  updateField(form: NgForm,card:any ) {
    // console.log(form.value);
    const updatedField: any = {
      label: this.label,
      type: this.inputType,
      isExpirable:false,
      instruction_hints: this.instruction_hints,
      text: {
        value: '',
        placeholder: ""
      }
    }

    this.policyService.postUpdatedInputField(updatedField, this.policyId,card._id).subscribe({
      next: (response: any) => {
        console.log(response);
        this.cardData.push(response)
      },
      error: (error: any) => { console.error(error) }
    })
  }

  saveOption(item: string) {
    this.optionData.push(item);
  }
  // addOption(item:string) {
  //   this.optionData.push(item);
  // }
}



