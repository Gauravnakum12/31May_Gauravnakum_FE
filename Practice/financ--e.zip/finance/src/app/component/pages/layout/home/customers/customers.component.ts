import { Component, inject, OnInit, signal } from '@angular/core';
import { customerData, customerResponse } from '../../../../../finance.model';
import { CommonModule, DatePipe } from '@angular/common';
import { CustomersService } from '../../../../services/api/customers.service';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [TableModule, CommonModule, ButtonModule, FormsModule, InputGroupModule, InputGroupAddonModule, InputTextModule, FloatLabelModule, DialogModule, ReactiveFormsModule, DatePipe],
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent implements OnInit {
  visible = signal(false);
  private CustomerDataService = inject(CustomersService);
  customers: customerData[] = [];
  totalCustomerRecord: number = 0;
  row: number = 20;
  totalPage: number = 0;
  currentPage: number = 1;
  limit:number= 0;

  loadCustomerLazy(event: TableLazyLoadEvent) {
    const page = Math.floor((event.first || 0) / this.row) + 1;
  
    console.log(event);
    this.CustomerDataService.getCustomerData(page,this.limit).subscribe({
      next: (response: customerResponse) => {
        this.totalCustomerRecord = response.totalRecord;
        this.totalPage = response.totalPage;
        this.customers = response.data;
        this.row = event.rows as number;
        this.limit = event.first as number;
        console.log(`this.limit=${this.row}`);
        
        console.log(`this.row=${this.row}`);
      }
    });
  }
  ngOnInit(): void {
    console.log(`row-${this.row}`);
  }
  customerForm: FormGroup = new FormGroup({
    _id: new FormControl(''), // For holding the ID during edits
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    birthDate: new FormControl(''),
  });

  get controls() {
    return this.customerForm.controls;
  }

  openNewUserDialog() {
    this.visible.set(true);
    this.customerForm.reset();
  }
  // private loadCustomerData() {
  //   this.CustomerDataService.getCustomerData(this.currentPage,this.limit).subscribe({
  //     next: (response: customerResponse) => {
  //       this.customers = response.data;
  //     },
  //     error: (error: Error) => console.error(error),
  //   });
  // }

  editCustomer(customer: customerData) {
    this.visible.set(true);
    this.customerForm.setValue({
      _id: customer._id,
      name: customer.name,
      email: customer.email,
      phoneNumber: customer.phoneNumber,
      birthDate: customer.birthDate ? new Date(customer.birthDate).toLocaleDateString('en-CA') : '',
    });
  }

  saveCustomer(): void {
    if (this.customerForm.valid) {
      const tempData: customerData = this.customerForm.value;
      if (tempData._id) {
        // Update existing user
        this.CustomerDataService.UpdateCustomer(tempData).subscribe({
          next: () => {
            this.visible.set(false);
            // this.loadCustomerData();
          },
          error: (error: Error) => console.error(error),
        });
      } else {
        // Create new user
        this.CustomerDataService.postNewCustomer(tempData).subscribe({
          next: (response) => {
            this.visible.set(false);
            // this.loadCustomerData();
          },
          error: (error: Error) => console.error(error),
        });
      }
    }
  }

  deleteCustomer(customerId: string) {
    this.CustomerDataService.deleteCustomer(customerId).subscribe({
      next: () => {
        // this.loadCustomerData();
      },
      error: (error: Error) => console.error(error),
    });
  }


}
