import { Component } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
function mustContainQuestionMArk(control:AbstractControl){
  if (control.value.includes('?')) {
    return null;
  }
  return{ doesNotContainQuestionMark: true};

}
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})

export class LoginComponent {
  form = new FormGroup({
    email: new FormControl('', {
      validators: [Validators.required, Validators.email ],
    }),
    password: new FormControl('', {
      validators: [Validators.required, Validators.minLength(6),mustContainQuestionMArk],
    })
  });

  get emailIsInvalid() {
    const control = this.form.controls.email;
    return control.touched && control.invalid ;
  }

  get passwordIsInvalid() {
    const control = this.form.controls.password;
    return control.touched && control.invalid;
  }

  onSubmit() {
    if (this.form.valid) {
      const enteredEmail = this.form.value.email;
      const enteredPassword = this.form.value.password;
      console.log('Form submitted:', { email: enteredEmail, password: enteredPassword });
    } else {
      alert('form is not submitted')
    }
  }
}
