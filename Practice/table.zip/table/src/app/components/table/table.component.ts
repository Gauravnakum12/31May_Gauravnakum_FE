import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../../services/user.service';
import { User, UserDataResponse } from '../.././user.model';
import { FormsModule } from '@angular/forms';

import { TableModule } from 'primeng/table';
import { InputGroupModule } from 'primeng/inputgroup';
import { InputGroupAddonModule } from 'primeng/inputgroupaddon';
import { InputTextModule } from 'primeng/inputtext';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DialogModule } from 'primeng/dialog';
import { signal } from '@angular/core';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    TableModule,
    FormsModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputTextModule,
    FloatLabelModule,
    DialogModule
  ],
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent {
  private userDataService = inject(UserService);
  err = signal('');
  visible = signal(false);
  userForm: Partial<User> = {};

  userData = signal<UserDataResponse>({
    page: 0,
    per_page: 12,
    total: 0,
    total_pages: 0,
    data: [],
    support: {
      url: '',
      text: '',
    }
  });

  first = 0;
  rows = 6;

  ngOnInit(): void {
    this.loadUserData(1);
  }

  loadUserData(page: number): void {
    this.userDataService.getUserData(page).subscribe({
      next: (users: UserDataResponse) => this.userData.set(users),
      error: (error: Error) => this.err.set(error.message),
    });
  }

  openNewUserDialog(): void {
    this.userForm = {};
    this.visible.set(true);
  }

  editUser(user: User): void {
    this.userForm = { ...user };
    this.visible.set(true);
  }

  getNewUserId(): number {
    const lastUser = this.userData().data[this.userData().data.length - 1];
    return lastUser ? lastUser.id + 1 : 1;
  }
  saveUser(): void {
    if (this.userForm.id) {
      this.userDataService.updateUser(this.userForm as User).subscribe({
        next: () => {
          this.loadUserData(this.userData().page);
          this.visible.set(false);
        },
        error: (error: Error) => this.err.set(error.message),
      });
    } else {
      const newUser = { ...this.userForm, id: this.getNewUserId() } as User;
      this.userDataService.postNewUserData(newUser).subscribe({
        next: () => {
          this.loadUserData(this.userData().page);
          this.visible.set(false);
        },
        error: (error: Error) => this.err.set(error.message),
      });
    }
  }

  deleteUser(userId: number): void {
    this.userDataService.deleteUser(userId).subscribe({
      next: () => this.loadUserData(this.userData().page),
      error: (error: Error) => this.err.set(error.message),
    });
  }

  pageChange(event: { first: number; rows: number; }) {
    this.first = event.first
    this.rows = event.rows;
  }
}




