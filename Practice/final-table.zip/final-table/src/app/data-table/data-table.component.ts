import { Component, inject } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { Transaction } from './table.model';
import { NgClass, NgFor } from '@angular/common';
import { DecimalPipe, DatePipe } from '@angular/common';

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [NgClass, NgFor, DatePipe],
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css'],
  providers: [DecimalPipe, DatePipe,]
})
export class DataTableComponent {
  private WalletService = inject(DataServiceService);
  transactions: Array<Transaction> = this.WalletService.transactionsSignal();
  CurrentExpandedRow: number | null = null;

  constructor(private decimalPipe: DecimalPipe, private datePipe: DatePipe) { }

  toggleRow(index: number): void {
    this.CurrentExpandedRow = (this.CurrentExpandedRow === index ? null : index);
  }

}
