import {
  InputText,
  InputTextModule
} from "./chunk-I6VAFPTG.js";
import "./chunk-KNAY2FP2.js";
import "./chunk-7GJVN474.js";
import "./chunk-GHTSNRWU.js";
import "./chunk-T6OEQNTN.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-EBXC6MJI.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
