import {
  Tooltip,
  TooltipModule
} from "./chunk-AAVDQY55.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-X3QUKF4S.js";
import "./chunk-FRIKEHAD.js";
import "./chunk-HUWSEA2J.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
