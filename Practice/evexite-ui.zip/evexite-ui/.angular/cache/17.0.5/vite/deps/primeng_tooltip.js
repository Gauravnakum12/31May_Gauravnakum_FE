import {
  Tooltip,
  TooltipModule
} from "./chunk-QVPIRFCU.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-KNAY2FP2.js";
import "./chunk-GHTSNRWU.js";
import "./chunk-T6OEQNTN.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-EBXC6MJI.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
