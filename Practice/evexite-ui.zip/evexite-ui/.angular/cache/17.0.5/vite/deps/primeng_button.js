import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-LTD5O74B.js";
import "./chunk-M6MT5VLJ.js";
import "./chunk-JVWZDCGY.js";
import "./chunk-SWQ4GSWX.js";
import "./chunk-CFXL3M6G.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-KNAY2FP2.js";
import "./chunk-GHTSNRWU.js";
import "./chunk-T6OEQNTN.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-EBXC6MJI.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
