import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-EPL4MTAB.js";
import "./chunk-KAC53ODA.js";
import "./chunk-GZRMB5MF.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-XYUEZXI3.js";
import "./chunk-X3QUKF4S.js";
import "./chunk-FRIKEHAD.js";
import "./chunk-HUWSEA2J.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
