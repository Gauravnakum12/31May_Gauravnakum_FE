import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-2Q3CTVKB.js";
import "./chunk-HWPAVMGJ.js";
import "./chunk-XAS6G3YG.js";
import "./chunk-3U6SZDML.js";
import "./chunk-N5VOYFLT.js";
import "./chunk-WD55HX4J.js";
import "./chunk-7GJVN474.js";
import "./chunk-R75Y3RQN.js";
import "./chunk-NRPQEUWD.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-PFSBGZRB.js";
import "./chunk-2SFJ3DLA.js";
import "./chunk-O7JMIU2L.js";
import "./chunk-GHTSNRWU.js";
import "./chunk-T6OEQNTN.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-EBXC6MJI.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
