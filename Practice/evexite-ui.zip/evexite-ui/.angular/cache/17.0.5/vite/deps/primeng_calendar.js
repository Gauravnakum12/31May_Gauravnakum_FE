import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-I6H2VSEE.js";
import "./chunk-M6263R4L.js";
import "./chunk-UQSEBYMD.js";
import "./chunk-DOKSKRCI.js";
import "./chunk-2YWVEBHW.js";
import "./chunk-EPL4MTAB.js";
import "./chunk-KAC53ODA.js";
import "./chunk-GZRMB5MF.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-XYUEZXI3.js";
import "./chunk-X3QUKF4S.js";
import "./chunk-CVQBE5NG.js";
import "./chunk-4E4VHFF7.js";
import "./chunk-FRIKEHAD.js";
import "./chunk-HUWSEA2J.js";
import "./chunk-WI6LBH4V.js";
import "./chunk-BQTYKBYB.js";
import "./chunk-KDOJNZN6.js";
import "./chunk-HSNDBVJ3.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
