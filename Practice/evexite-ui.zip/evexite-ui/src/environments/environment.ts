export const environment = {
  production: false,
  API_URL: 'https://dev.api.evexite.in',
};
