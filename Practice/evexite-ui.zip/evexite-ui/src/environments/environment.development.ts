export const environment = {
  production: true,
  // API_URL: 'http://localhost:4008',
  API_URL: 'https://dev.api.evexite.in',
};
