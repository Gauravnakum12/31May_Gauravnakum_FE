import { NgModule } from '@angular/core';
import { DialogModule } from 'primeng/dialog';
import { ChipModule } from 'primeng/chip';
import { ChipsModule } from 'primeng/chips';
import { InputTextModule } from 'primeng/inputtext';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { PanelModule } from 'primeng/panel';
import { ToolbarModule } from 'primeng/toolbar';
import { CardModule } from 'primeng/card';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { PanelMenuModule } from 'primeng/panelmenu';
import { ButtonModule } from 'primeng/button';
import { RouterModule } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { EventComponent } from './pages/event/event.component';
import { ClientComponent } from './pages/client/client.component';
import { VendorComponent } from './pages/vendor/vendor.component';
import { TableModule } from 'primeng/table';
import { ArtistComponent } from './pages/artist/artist.component';
import { InventoryComponent } from './pages/inventory/inventory.component';
import { SettingComponent } from './pages/setting/setting.component';
import { CreateEventComponent } from './pages/event/create-event/create-event.component';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { EventArtistComponent } from './pages/event/event-artist/event-artist.component';
import { EventVendorComponent } from './pages/event/event-vendor/event-vendor.component';
import { ToastModule } from 'primeng/toast';
import { TabViewModule } from 'primeng/tabview';
import { NavigationMenuComponent } from './components/navigation-menu/navigation-menu.component';
import { UserMenuComponent } from './components/user-menu/user-menu.component';
import { AvatarModule } from 'primeng/avatar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { MenuModule } from 'primeng/menu';
import { CreateInventoryComponent } from './pages/inventory/create-inventory/create-inventory.component';
import { CombineValuesPipe } from '../common/pipes/variant.group.pipe';
import { ImageUploaderComponent } from './components/image-uploader/image-uploader.component';
import { BreadcrumbsComponent } from './components/breadcrums/breadcrumbs.component';
import { ThemeListComponent } from './pages/theme/theme-list/theme-list.component';
import { CreateThemeComponent } from './pages/theme/create-theme/create-theme.component';
import { DragDropModule } from 'primeng/dragdrop';
import { AccordionModule } from 'primeng/accordion';
import { BlockUIModule } from 'primeng/blockui';
import { DataViewModule } from 'primeng/dataview';
import { DebounceDirective } from '../common/Directive/debounce.directive';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { InventoryListComponent } from './pages/inventory/inventory-list/inventory-list.component';
import { SearchInputComponent } from '../common/components/search-input/search-input.component';
import { EventInventoryComponent } from './pages/event/event-inventory/event-inventory.component';
import { InputNumberModule } from 'primeng/inputnumber';
import { SidebarModule } from 'primeng/sidebar';
import { ThemeComponent } from './pages/theme/theme.component';
import { MultiplyThemePipe } from '../common/pipes/area-item.total.pipe';
import { MultiplyThemeAreaPipe } from '../common/pipes/area.total.pipe';
import { EventTotalPipe } from '../common/pipes/event.total.pipe';
import { EventImagePipe } from '../common/pipes/event.image.pipe';
import { ThemeImagePipe } from '../common/pipes/theme.image.pipe';
import { LoaderComponent } from './components/loader/loader.component';
import { AddClientComponent } from './pages/client/add-client.component';
import { AddArtistComponent } from './pages/artist/add-artist.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ActionIconsComponent } from '../common/components/action-icons/action-icons.component';
import { SegmentTotalPricePipe } from '../common/pipes/segment.total.pipe';
import { SegmentGridComponent } from '../common/components/segment-grid/segment-grid.component';
import { SegmentAreaGroupComponent } from '../common/components/segment-area-group/segment-area-group.component';
import { QuotationSheetComponent } from './pages/event/download-section/quotation-sheet/quotation-sheet.component';
import { AddVendorComponent } from './pages/vendor/add-vendor.component';
import { UploadEventImgComponent } from './components/upload-event-img/upload-event-img.component';
import { DownloadQuotationSheetComponent } from './pages/event/download-section/quotation-sheet/download-quotaion-sheet/download-quotaion-sheet.component';
import { AreaGroupComponent } from "../common/components/image-select/area-group/area-group.component";

@NgModule({
  declarations: [
    DashboardComponent,
    SideBarComponent,
    EventComponent,
    CreateEventComponent,
    ClientComponent,
    VendorComponent,
    ArtistComponent,
    InventoryComponent,
    SettingComponent,
    NavigationMenuComponent,
    UserMenuComponent,
    CreateInventoryComponent,
    ThemeListComponent,
    CreateThemeComponent,
    InventoryListComponent,
    EventInventoryComponent,
    ThemeComponent,
    AddClientComponent,
    DownloadQuotationSheetComponent,
    QuotationSheetComponent,
  ],
  imports: [
    DialogModule,
    ChipModule,
    ChipsModule,
    ButtonModule,
    TableModule,
    InputTextModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    FormsModule,
    CommonModule,
    PanelModule,
    ToolbarModule,
    CardModule,
    PanelMenuModule,
    ButtonModule,
    TableModule,
    CalendarModule,
    DropdownModule,
    InputTextareaModule,
    RouterModule.forChild([
        {
            path: '',
            component: DashboardComponent,
            children: [
                {
                    path: '',
                    redirectTo: 'events',
                    pathMatch: 'full',
                },
                {
                    path: 'events',
                    component: EventComponent,
                },
                {
                    path: 'events/:id',
                    component: CreateEventComponent,
                },
                {
                    path: 'events/:id/quotationSheet',
                    component: QuotationSheetComponent,
                },
                {
                    path: 'clients',
                    component: ClientComponent,
                },
                {
                    path: 'vendors',
                    component: VendorComponent,
                },
                {
                    path: 'artists',
                    component: ArtistComponent,
                },
                {
                    path: 'inventory',
                    component: InventoryComponent,
                },
                {
                    path: 'inventory/:id',
                    component: CreateInventoryComponent,
                },
                {
                    path: 'theme',
                    component: ThemeComponent,
                },
                {
                    path: 'theme/:id',
                    component: CreateThemeComponent,
                },
                {
                    path: 'settings',
                    component: SettingComponent,
                },
            ],
        },
        {
            path: '**',
            redirectTo: '',
            pathMatch: 'full',
        },
    ]),
    EventArtistComponent,
    EventVendorComponent,
    ToastModule,
    TabViewModule,
    AvatarModule,
    OverlayPanelModule,
    MenuModule,
    CombineValuesPipe,
    InputTextareaModule,
    ImageUploaderComponent,
    UploadEventImgComponent,
    BreadcrumbsComponent,
    DragDropModule,
    AccordionModule,
    BlockUIModule,
    DataViewModule,
    InfiniteScrollModule,
    SearchInputComponent,
    DebounceDirective,
    InputNumberModule,
    SidebarModule,
    MultiplyThemePipe,
    MultiplyThemeAreaPipe,
    EventTotalPipe,
    EventImagePipe,
    ThemeImagePipe,
    LoaderComponent,
    AddArtistComponent,
    ChangePasswordComponent,
    ActionIconsComponent,
    SegmentTotalPricePipe,
    SegmentGridComponent,
    SegmentAreaGroupComponent,
    AddVendorComponent,
    AreaGroupComponent
],
  providers: [ConfirmationService, MessageService, DatePipe],
})
export class DashboardModule {}
