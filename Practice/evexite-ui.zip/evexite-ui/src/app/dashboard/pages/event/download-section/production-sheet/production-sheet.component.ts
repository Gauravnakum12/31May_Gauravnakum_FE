import { Component } from '@angular/core';

@Component({
  selector: 'app-production-sheet',
  standalone: true,
  imports: [],
  templateUrl: './production-sheet.component.html',
  styleUrl: './production-sheet.component.scss',
})
export class ProductionSheetComponent {}
