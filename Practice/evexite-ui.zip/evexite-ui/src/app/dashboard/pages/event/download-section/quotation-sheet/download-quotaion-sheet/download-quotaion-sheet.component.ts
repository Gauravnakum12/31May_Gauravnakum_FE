import { Component, Input } from '@angular/core';
import { EventSegment } from '../../../../../../common/models';

@Component({
  selector: 'app-download-quotation-sheet',
  templateUrl: './download-quotation-sheet.component.html',
  styleUrl: './download-quotation-sheet.component.scss',
})
export class DownloadQuotationSheetComponent {
  @Input() heading: string = '';
  @Input() addressData: string = '';
  @Input() coverImage: string | undefined |null;

  @Input() editorTextArea: string = '';
  @Input() eventSegments!: EventSegment[];
  @Input() collageImages!: string[] | undefined | null;
  @Input() footerImages!: string[] | undefined | null;
  @Input() eventName!: string | undefined;
  @Input() clientContactNumber!: string | undefined;
  @Input() eventDate!: Date | undefined;
  @Input() totalArea!: number;
}
