import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EventService } from '../../../../common/services/event.service';
import { ClientService } from '../../../../common/services/client.service';
import { VendorService } from '../../../../common/services/vendor.service';
import {
  Artist,
  Client,
  EventAreaGroup,
  EventArtist,
  EventSegment,
  EventStatusType,
  EventType,
  EventVendor,
  IEvent,
  VendorResponse,
} from '../../../../common/models';
import { OrganizationService } from '../../../../common/services/organization.service';
import { EventInventoryComponent } from '../event-inventory/event-inventory.component';
import { MenuItem, MessageService } from 'primeng/api';
import { LoaderService } from '../../../../common/services/loader.service';
import { AddClientComponent } from '../../client/add-client.component';
import { EventSegmentService } from '../../../../common/services/event.segment.service';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrl: './create-event.component.scss',
})
export class CreateEventComponent implements OnInit {
  eventForm: FormGroup;
  isEventCreated = false;
  eventTypes = Object.values(EventType);
  currentTabIndex = 0;
  eventData!: IEvent;
  clients: Client[] = [];
  vendors: VendorResponse[] = [];
  artists: Artist[] = [];
  eventSegments: EventSegment[] = [];
  eventArtists: Array<EventArtist & { artist: Artist }> = [];
  eventVendors: Array<EventVendor & { vendor: VendorResponse }> = [];
  @ViewChild(EventInventoryComponent) eventInventoryComponent!: EventInventoryComponent;
  isProductionSheetBeingDownloaded = false;
  isSheetBeingDownloaded = false;
  items: MenuItem[] = [
    {
      label: 'Download Production Sheet',
      command: () => {
        this.isProductionSheetBeingDownloaded = true;
        this.eventService.downloadProductionSheet(this.eventId).subscribe({
          next: response => {
            const url = response.url;
            const a = document.createElement('a');
            a.href = url;
            a.target = '_blank';
            a.click();
            a.remove();
            this.isProductionSheetBeingDownloaded = false;
          },
          error: error => {
            console.error('Error downloading production sheet:', error);
            this.isProductionSheetBeingDownloaded = false;
          },
        });
      },
    },
    {
      label: 'Download Quotation Sheet',
      command: () => {
        this._router.navigate([`app/events/${this.route.snapshot.params['id']}/quotationSheet`]);
      },
    },
  ];
  eventId = '';
  isLoading = false;

  @ViewChild(AddClientComponent) addClientComponent!: AddClientComponent;
  constructor(
    private formBuilder: FormBuilder,
    private readonly eventService: EventService,
    private readonly eventSegmentService: EventSegmentService,
    private readonly clientService: ClientService,
    private readonly organizationService: OrganizationService,
    private readonly vendorService: VendorService,
    private location: Location,
    private route: ActivatedRoute,
    private _router: Router,
    private _messageService: MessageService,
    private _loaderService: LoaderService
  ) {
    this.eventSegmentService.isLoading$.subscribe(res => {
      this.isLoading = res;
    });
    this.eventService.isLoading$.subscribe(res => {
      this.isLoading = res;
    });
    this.eventForm = this.formBuilder.group({
      type: ['', Validators.required],
      status: '',
      name: ['', Validators.required],
      description: '',
      date: [new Date(), Validators.required],
      venue: ['', Validators.required],
      totalMembers: [null, Validators.required],
      clientId: ['', Validators.required],
      organizationId: '',
    });
  }

  ngOnInit(): void {
    this.fetchClients();
    this.getSingleEventDetails();
    this.fetchVendors();
  }

  getSingleEventDetails(): void {
    if (this.route.snapshot.params['id']) {
      if (this.route.snapshot.params['id'] !== 'create') {
        this.eventId = this.route.snapshot.params['id'];
        this._loaderService.showLoader();
        this.eventService.fetchEventById(this.eventId).subscribe(response => {
          this.handleEventResponse(response.event);
          this._loaderService.hideLoader();
        });
      }
    }
  }

  handleEventResponse(response: IEvent): void {
    this.eventData = response;

    this.eventData.date = new Date(this.eventData.date as any);
    this.eventForm.patchValue(this.eventData);
    if (this.eventData.eventSegments) {
      this.eventSegments = this.eventData.eventSegments;
    }
    if (this.eventData.eventArtists) {
      this.eventArtists = this.eventData.eventArtists;
    }
    if (this.eventData.eventVendors) {
      this.eventVendors = this.eventData.eventVendors;
    }
    this.isEventCreated = true;
  }

  fetchClients() {
    this.clientService.getAllClients({}).subscribe({
      next: response => {
        this.clients = response.clients;
      },
      error: error => {
        console.error('Error fetching clients:', error);
      },
    });
  }

  fetchVendors() {
    this.vendorService.getAllVendors().subscribe({
      next: vendors => {
        this.vendors = vendors.vendors;
      },
      error: error => {
        console.error('Error fetching events:', error);
      },
    });
  }

  createEvent() {
    if (this.currentTabIndex === 1) {
      if (this.eventInventoryComponent && this.eventId) {
        this.eventInventoryComponent.saveInventory();
      }
    }
    const organizationId = this.organizationService.CurrentOrganization;
    const eventData: IEvent = {
      ...this.eventForm.value,
      organizationId,
    };
    if (this.eventData?.id) {
      this.eventService.updateEvent({ ...eventData, id: this.eventData.id }).subscribe({
        next: response => {
          if (this.currentTabIndex !== 1) {
            this._messageService.add({ severity: 'success', detail: 'Event updated ' });
          }
        },
        error: error => {
          console.log('ERROR', error);
          this._messageService.add({ severity: 'error', detail: 'Error while updating event: ' + error.error.message });
        },
      });
    } else {
      eventData.status = EventStatusType.DRAFT;
      let valid = true;
      if (!eventData.clientId) {
        valid = false;
        this._messageService.add({ severity: 'error', detail: 'Select client for event' });
        return;
      }
      if (!eventData.name) {
        valid = false;
        this._messageService.add({ severity: 'error', detail: 'Enter name for event' });
        return;
      }
      if (!eventData.date) {
        valid = false;
        this._messageService.add({ severity: 'error', detail: 'Select date for event' });
        return;
      }
      if (!eventData.type) {
        valid = false;
        this._messageService.add({ severity: 'error', detail: 'Select type of event' });
        return;
      }
      if (!eventData.totalMembers) {
        valid = false;
        this._messageService.add({ severity: 'error', detail: 'Enter total member of event' });
        return;
      }
      this.eventService.createEvent(eventData).subscribe({
        next: response => {
          this.isEventCreated = true;
          this.eventData = response.event;
          if (response.event.id) this.eventId = response.event.id;
          this.eventForm.patchValue(this.eventData);
          this._messageService.add({ severity: 'success', detail: 'Event Created' });
        },
        error: error => {
          this._messageService.add({ severity: 'error', detail: 'Error while creating event: ' + error.error.message });
        },
      });
    }
  }

  createOrUpdateEvent() {
    if (this.eventForm.valid) {
      this.createEvent();
    }
  }

  goBack() {
    this.location.back();
  }

  downlaodProductionSheet() {
    this.isProductionSheetBeingDownloaded = true;
    this.eventService.downloadProductionSheet(this.eventId).subscribe({
      next: response => {
        const url = response.url;
        const a = document.createElement('a');
        a.href = url;
        a.target = '_blank';
        a.click();
        a.remove();
        this.isProductionSheetBeingDownloaded = false;
      },
      error: error => {
        console.error('Error downloading production sheet:', error);
        this.isProductionSheetBeingDownloaded = false;
      },
    });
  }

  openAddClientDialog() {
    this.addClientComponent.resetForm();
    this.addClientComponent.visible = true;
  }
}
