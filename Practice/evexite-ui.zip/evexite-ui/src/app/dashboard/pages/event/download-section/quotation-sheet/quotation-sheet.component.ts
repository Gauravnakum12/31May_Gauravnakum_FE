import { Component, OnInit, ViewChild } from '@angular/core';
import { MessageService } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { LoaderService } from '../../../../../common/services/loader.service';
import { EventService } from '../../../../../common/services/event.service';
import { UploadMediaService } from '../../../../../common/services/upload.service';
import { ClientService } from '../../../../../common/services/client.service';
import { ClientResponse, EventSegment, QuotationSheetData } from '../../../../../common/models';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { quotationSheetStyles } from './style';
import { AreaGroupComponent } from '../../../../../common/components/image-select/area-group/area-group.component';
@Component({
  selector: 'app-quotation-sheet',
  templateUrl: './quotation-sheet.component.html',
  styleUrl: './quotation-sheet.component.scss',
})
export class QuotationSheetComponent implements OnInit {
  @ViewChild(AreaGroupComponent) areaGroupComponent!: AreaGroupComponent;
  [x: string]: any;
  title: string | undefined | null = '';
  subtitle: string | undefined | null = '';
  eventName: string | undefined = 'event';
  eventSegments: EventSegment[] = [];
  eventDate!: Date | undefined;
  clientContactNumber!: string | undefined;
  totalArea = 0;
  currentEventId: string = '';
  choseSectionArray: string[] = ['*', '*', '*', '*', '*'];
  collageImagesFinalArray: string[] = [];
  printWindow: Window | null = null;
  editorTextArea!: string;
  selectedImageFromSidebar: string = '';
  currentActiveSegment: null | EventSegment = null;
  editCollageImgIndex!: number;
  eventImages: string[] = [];
  quotationSheetData: QuotationSheetData = {
    id: this.currentEventId,
    title: '',
    subtitle: '',
    description: '',
    coverImage: '',
    collageImages: [],
    footerImages: [],
  };
  isEventImagesUploaded = false;
  downloadSheetPreviewFlag = true;
  downloadSheetVisible = false;
  displayImageSelectionModal = false;
  addImageInCollageImages = false;
  addImageInFooterImages = false;
  editCollageImages = false;
  constructor(
    private route: ActivatedRoute,
    private _loaderService: LoaderService,
    private _uploadMediaService: UploadMediaService,
    private messageService: MessageService,
    private clientService: ClientService,
    private readonly eventService: EventService
  ) { }
  private saveSheetDebounce$ = new Subject<string>();

  ngOnInit(): void {
    this.getSingleEventDetails();
    this.saveSheetDebounce$.pipe(debounceTime(1000), distinctUntilChanged()).subscribe(() => {
      this.saveSheetData();
    });
  }
  onDescriptionChange(value: string): void {
    this.saveSheetDebounce$.next(value);
    this.quotationSheetData.description = value;
  }

  onSelectFromLocalImage(img: string) {
    this.areaGroupComponent.resetSelectedImage();
    this.selectedImageFromSidebar = img;
  }
  toggleSidebar() {
    this.addImageInCollageImages = false;
    this.addImageInFooterImages = false;
    this.selectedImageFromSidebar = '';
    this.displayImageSelectionModal = true;
    this.currentActiveSegment = null;
    this.areaGroupComponent.resetAreaGroup();
  }
  openSidebarforcollageImages() {
    this.toggleSidebar();
    this.addImageInCollageImages = true;
  }
  openSidebarForFooterImages() {
    this.toggleSidebar();
    this.addImageInFooterImages = true;
  }
  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImage(file);
    }
  }

  editCollageImg(index: number) {
    this.toggleSidebar();
    this.editCollageImgIndex = index;
    this.editCollageImages = true;
  }

  deleteCoverImg() {
    this.quotationSheetData.coverImage = '';
    this.saveSheetData();
  }

  deleteCollageImg(index: number) {
    this.quotationSheetData.collageImages?.splice(index, 1);
    this.choseSectionArray.splice(index, 0, '*');
    this.saveSheetData();
  }
  deleteFooterImag(index: number) {
    this.quotationSheetData.footerImages?.splice(index, 1);
    this.saveSheetData();
  }
  onSegmentSelect(segment: EventSegment) {
    this.currentActiveSegment = segment;
  }
  uploadImage(file: File) {
    this.isEventImagesUploaded = true;
    this._uploadMediaService.uploadFile(file, 'Theme').subscribe(
      response => {
        if (this.isEventImagesUploaded) {
          this.eventImages.push(response.url);
          this.areaGroupComponent.resetSelectedImage();
          this.selectedImageFromSidebar = response.url;

        }
        this.isEventImagesUploaded = false;
      },
      err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
        this.isEventImagesUploaded = false;
      }
    );
  }

  deleteImage(index: number) {
    this.eventImages.splice(index, 1);
  }

  getSingleEventDetails(): void {
    if (this.route.snapshot.params['id']) {
      if (this.route.snapshot.params['id'] !== 'create') {
        this.currentEventId = this.route.snapshot.params['id'];
        this._loaderService.showLoader();
        this.eventService.fetchEventById(this.currentEventId).subscribe(response => {
          this.eventName = response.event.name;
          this.eventDate = response.event.date;
          if (response.event.eventQuotation) {
            this.quotationSheetData = response.event.eventQuotation;
            this.choseSectionArray.splice(0, response.event.eventQuotation.collageImages?.length || 0);
          }

          this.eventSegments = response.event.eventSegments;
          this.totalArea = this.eventSegments.length;
          this.getContactNumber(response.event.clientId || '');
          this._loaderService.hideLoader();
        });
      }
    }
  }

  getContactNumber(clientId: string) {
    this.clientService.getClientById(clientId).subscribe({
      next: (response: ClientResponse) => {
        this.clientContactNumber = response.client.primaryContact;
      },
      error: error => {
        this.messageService.add({ severity: 'error', detail: ` client's contact number not found ` });
      },
    });
  }

  downloadSheetPreview() {
    this.downloadSheetVisible = true;
    this.downloadSheetPreviewFlag = false;
  }
  downloadSheetReSize() {
    this.downloadSheetPreviewFlag = true;
  }
  onSelectedImageChange(img: string) {
    this.selectedImageFromSidebar = img;
  }
  submitSelectedImage() {
    if (this.addImageInCollageImages) {
      this.quotationSheetData?.collageImages?.push(this.selectedImageFromSidebar);
      this.choseSectionArray.splice(0, 1);
    } else if (this.addImageInFooterImages) {
      this.quotationSheetData?.footerImages?.push(this.selectedImageFromSidebar);
    } else if (this.editCollageImages) {
      this.quotationSheetData?.collageImages?.splice(this.editCollageImgIndex, 1, this.selectedImageFromSidebar);
    } else {
      this.quotationSheetData.coverImage = this.selectedImageFromSidebar;
    }
    this.displayImageSelectionModal = false;
    this.saveSheetData();
  }
  onDownloadSheet() {
    const printContents = document.querySelector('.downloadSheet')?.innerHTML;
    const styles = '<style>' + ` ${quotationSheetStyles} ` + '</style>';
    this.printWindow = window.open('', '', '_blank');
    if (this.printWindow && printContents) {
      this.printWindow.document.write('<html><head>');
      this.printWindow.document.write(styles);
      this.printWindow.document.write('</head><body>');
      this.printWindow.document.write(printContents);
      this.printWindow.document.write('</body></html>');
      this.printWindow.document.close();
      this.printWindow.print();
    }
  }

  saveSheetData() {
    this.eventService.updateQuotationSheet(this.currentEventId, this.quotationSheetData).subscribe({
      error: error => {
        this.messageService.add({ severity: 'error', detail: ` error during updated QuotationSheet` });
      },
    });
  }
}
