import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { NgClass, NgForOf, NgIf, TitleCasePipe } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { FormsModule } from '@angular/forms';
import { ArtistType, EventArtist, EventThirdPartyConfirmationStatusType } from '../../../../common/models';
import { ArtistService } from '../../../../common/services/artist.service';
import { EventArtistService } from '../../../../common/services/event.artist.service';
import { OrganizationService } from '../../../../common/services/organization.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { TagModule } from 'primeng/tag';
import { SidebarModule } from 'primeng/sidebar';
import { SearchInputComponent } from '../../../../common/components/search-input/search-input.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { Artist } from '../../../../common/models';
import { AddArtistComponent } from '../../artist/add-artist.component';
import { ActionIconsComponent } from '../../../../common/components/action-icons/action-icons.component';

@Component({
  selector: 'app-event-artist',
  standalone: true,
  imports: [
    ButtonModule,
    NgForOf,
    DialogModule,
    DropdownModule,
    InputTextareaModule,
    FormsModule,
    NgIf,
    ConfirmDialogModule,
    ToastModule,
    TagModule,
    SidebarModule,
    SearchInputComponent,
    NgClass,
    TitleCasePipe,
    InfiniteScrollModule,
    AddArtistComponent,
    ActionIconsComponent,
  ],
  providers: [MessageService],
  templateUrl: './event-artist.component.html',
  styleUrl: './event-artist.component.scss',
})
export class EventArtistComponent implements OnInit {
  @Input() eventId: string = '';
  artists: Artist[] = [];
  displayArtistModal = false;
  @Input() eventArtists: Array<EventArtist & { artist: Artist }> = [];
  thirdPartyStatus = Object.values(EventThirdPartyConfirmationStatusType).map(d => {
    return {
      name: d,
      id: d,
    };
  });
  eventArtistTypes = Object.values(ArtistType).map(d => {
    return {
      name: d,
      id: d,
    };
  });
  currentEventArtist: EventArtist = {
    artistId: '',
    eventId: '',
    flightTicketDetails: '',
    hotelDetails: '',
    logisticsDetails: '',
    notes: '',
    organizationId: '',
    status: EventThirdPartyConfirmationStatusType.PENDING,
  };
  artistType = '';
  page = 1;
  @ViewChild(AddArtistComponent) AddArtistComponent!: AddArtistComponent;
  constructor(
    private readonly artistService: ArtistService,
    private eventArtistService: EventArtistService,
    private readonly organizationService: OrganizationService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {}
  ngOnInit() {
    this.fetchArtist();
  }
  selectArtist(artist: Artist) {
    this.currentEventArtist.artistId = artist.id;
    delete this.currentEventArtist.id;
  }

  clearCurrentArtist() {
    this.artistType = '';
    this.currentEventArtist = {
      artistId: '',
      eventId: '',
      flightTicketDetails: '',
      hotelDetails: '',
      logisticsDetails: '',
      notes: '',
      organizationId: '',
      status: EventThirdPartyConfirmationStatusType.PENDING,
    };
  }

  fetchArtist(isFresh?: boolean) {
    if (isFresh) {
      this.page = 1;
      this.artists = [];
    }
    this.artistService.getAllArtists({ page: this.page, limit: 20 }).subscribe({
      next: artists => {
        this.artists = [...this.artists, ...artists.artists];
      },
      error: error => {
        console.error('Error fetching events:', error);
      },
    });
  }
  async saveEventArtist() {
    if (this.currentEventArtist.id) {
      const organizationId = this.organizationService.CurrentOrganization;
      let eventArtis: any = {
        ...this.currentEventArtist,
        organizationId,
        eventId: this.eventId,
      };
      delete eventArtis['artist'];
      this.eventArtistService.updateEventArtist(this.eventId, eventArtis, this.currentEventArtist.id).subscribe(
        response => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Artist updated',
          });

          this.displayArtistModal = false;
          this.clearCurrentArtist();
        },
        error => {
          console.error('Error updating event artist:', error);
        }
      );
    } else {
      const organizationId = this.organizationService.CurrentOrganization;
      let eventArtis = {
        ...this.currentEventArtist,
        organizationId,
        eventId: this.eventId,
      };
      this.eventArtistService.createEventArtist(this.eventId, eventArtis).subscribe(
        response => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Artist added',
          });
          this.displayArtistModal = false;
          this.clearCurrentArtist();
          if (response.event.eventArtists) {
            this.eventArtists = [...response.event.eventArtists];
          }
        },
        error => {
          console.error('Error creating event artist:', error);
        }
      );
    }
  }
  filterArtist(event: any) {
    this.artists = this.artists.filter(art => art.type === event.value);
  }
  editArtist(artist: EventArtist & { artist: Artist }) {
    this.currentEventArtist = artist;
    if (artist.artist) {
      this.artists = [artist.artist];
    }
    this.displayArtistModal = true;
  }
  deleteArtist(artist: EventArtist, index: number) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: async () => {
        if (artist.id) {
          this.eventArtistService.deleteEventArtist(artist.id).subscribe(
            response => {
              this.eventArtists = this.eventArtists?.filter(eA => eA.id !== artist.id);
              this.messageService.add({
                severity: 'success',
                summary: 'Success',
                detail: 'Artist Removed',
              });
            },
            error => {
              console.error(error);
            }
          );
        }
      },
    });
  }

  scrolled() {
    this.page++;
    this.fetchArtist();
  }

  openSelectArtistModal() {
    this.artists = [];
    this.clearCurrentArtist();
    this.fetchArtist();
    this.displayArtistModal = true;
  }
  openAddArtist() {
    this.AddArtistComponent.resetForm();
    this.AddArtistComponent.visible = true;
  }
}
