export const quotationSheetStyles = `
 @import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap');
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  font-family: Quicksand, sans-serif;
}
img {
  height: 100%;
  width: 100%;
}

#webPage {
  width: 100vw;
  max-width: 794px;
  margin: auto;
  background-color: white;
  border-top: 0px;
  height: auto;
  font-family: Quicksand, sans-serif !important;
}

.gradint-hr {
  width: 100%;
  background: linear-gradient(180deg, #1a3460 -83.33%, #5090f8 66.67%);
}

.gradint-hr:nth-of-type(1) {
  height: 7px;
}

.gradint-hr-2 {
  height: 2px;
  margin: 12px 0;
}

.title {
  display: flex;
  justify-content: space-between;
  padding: 0 24px;
}

.title .colum:nth-of-type(1) {
  max-width: 40%;
  margin-top: 27px;
}

.title .colum:nth-of-type(1) h2 {
  font-size: 24px;
  line-height: 32px;
  font-weight: 700;
  margin: 0;
}

.title .colum:nth-of-type(1) p {
  font-weight: 700;
  font-size: 14px;
  margin-top: 6px;
  line-height: 13.75px;
}

.title .colum:nth-of-type(2) {
  text-align: right;
  margin-top: 26px;
  font-size: 14px;
  max-width: 40%;
  line-height: 20px;
  font-weight: 600;
}
.title .colum:nth-of-type(2) p {
  margin-top: 2px;
}

.banner {
  padding: 0 24px;
  margin-top: 0px;
  border-radius: 4px;
}

.banner img {
  border-radius: 4px;
  max-height: 185px;
}

#section-1 {
  padding: 0 24px;
  margin-top: 22px;
  display: flex;
  gap: 22px;
}

#section-1 .col:nth-of-type(1) {
  width: 49%;
  max-width: 400px; 
  padding: 10px;
  background-color: #e6dfd1 !important;
  border-radius: 4px;
  gap: 10px;
  height: 300px;
  display: flex;
  flex-wrap: wrap;
}

.image-box img {
  height: 100%;
  width: 100%;
}

.gap-10px {
  gap: 10px;
}
.image-box {
  height: 100%;
  width: 100%;
}
.h-100 {
  height: 100% ;
}
.h-95 {
  height: 95% ;
}

.h-50 {
  height: 50%;
}

.h-65 {
  height: 65% ;
}

.h-48{
  height: 48% ;
}

.h-30 {
  height: 30% ! important;
}

.w-half{

}

.img-1-container{
  width: 100%;
 display: flex;
 gap: 10px;
 }

.img-container-2-half{
width:50%  ! important;
}

#section-1 .col:nth-of-type(2) {
  max-width: 47%;
  text-align: justify;
}

.col:nth-of-type(2) h2 {
  font-size: 20px;
  font-weight: 700;
  line-height: 28px;
}

.col:nth-of-type(2) .description {
  margin-top: 3px;
  text-align: justify;
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
}

.col:nth-of-type(2) .data {
  width: 47%;
  margin-top: 16px;
  text-align: justify;
}

#section-2 {
  padding: 0 24px;
  margin-top: 10px;
  gap: 11px;
  display: flex;
  flex-wrap: wrap;
}

#section-2 .image-box {
  width: 140px;
  height: 140px;
  border-radius: 3px;
}

#section-2 .image-box img {
  border-radius: 3px;
}

.event-date {
  display: flex;
  justify-content: space-between;
  padding: 0 3px;
  font-size: 12px;
  font-weight: 600;
}
.event-date p {
  margin-bottom: 0%;
}

.event-data {
  background: #f0f0f0;
  display: flex;
  justify-content: space-between;
  padding: 12px 24px;
}
.event-data .colum {
  font-size: 20px;
  font-weight: 700;
  line-height: 28px;
  margin: 0%;
}
.event-data .colum:nth-of-type(2) {
  font-size: 16px;
  font-weight: 600;
}
.event-segment-container {
  border: 0.6px solid #898989;
  margin: 16px 24px;
  border-radius: 3px;
}
.event-segment-container:last-of-type {
  margin: 24px;
}
.event-segment-container .data-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8f8f8;
  border-radius: 4px;
}
.event-segment-container .data-row .colum {
  padding: 8px;
}
.event-segment-container .data-row .colum:nth-of-type(1) {
  font-size: 20px;
  font-weight: 700;
  line-height: 28px;
  border: none;
  margin: 0%;
}
.event-segment-container .data-row .colum:nth-of-type(2) {
  border: 0.05px solid #d4d4d4;
  font-size: 12px;
  font-weight: 600;
  margin-right: 6px;
  border-radius: 4px;
  background-color: #fff;
}
.event-segment-container .row .colum {
  border: 0.05px solid #d4d4d4;
  border-radius: 4px;
  margin: 12px 8px;
}
.event-segment-container .row .colum .area-table {
  background: #f8f8f8;
  width: 100%;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom: 0.05px solid #d4d4d4;
}
.event-segment-container .row .colum .area-table tr th {
  font-weight: 600;
  font-size: 0.8rem;
  padding: 8px 6px 0px 6px;
}
.event-segment-container .row .colum .area-table tr th:nth-of-type(1) {
  min-width: 49%;
  text-align: left;
}
.event-segment-container .row .colum .area-table tr th:nth-of-type(2),
.event-segment-container .row .colum .area-table tr th:nth-of-type(3) {
  min-width: 17%;
  text-align: center;
}
.event-segment-container .row .colum .area-table tr th:nth-of-type(4) {
  min-width: 17%;
  text-align: right;
}
.event-segment-container .row .colum .area-table tr:nth-of-type(2) th {
  font-size: 1rem;
  font-weight: 700;
  padding: 0px 8px 8px 6px;
}
.event-segment-container .row .colum .item-table {
  width: 100%;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
}
.event-segment-container .row .colum .item-table tr {
  border-bottom: 0.05px solid #d4d4d4;
}
.event-segment-container .row .colum .item-table tr:last-of-type {
  border-bottom: none;
}
.event-segment-container .row .colum .item-table tr:last-of-type .notes {
  text-align: justify !important;
}
.event-segment-container .row .colum .item-table tr th,
.event-segment-container .row .colum .item-table tr td {
  border-collapse: collapse;
  padding-left: 16px;
  padding: 6px;
  font-size: 0.8rem;
}
.event-segment-container .row .colum .item-table tr th:nth-of-type(1),
.event-segment-container .row .colum .item-table tr td:nth-of-type(1) {
  min-width: 49%;
  text-align: left;
}
.event-segment-container .row .colum .item-table tr th:nth-of-type(2),
.event-segment-container .row .colum .item-table tr td:nth-of-type(2),
.event-segment-container .row .colum .item-table tr th:nth-of-type(3),
.event-segment-container .row .colum .item-table tr td:nth-of-type(3) {
  min-width: 17%;
  text-align: center;
}
.event-segment-container .row .colum .item-table tr th:nth-of-type(4),
.event-segment-container .row .colum .item-table tr td:nth-of-type(4) {
  min-width: 17%;
  text-align: right;
  padding: 4px 6px;
}
.event-segment-container table,
.event-segment-container tr {
  border-collapse: collapse;
}`;
