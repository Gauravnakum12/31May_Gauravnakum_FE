import { Component, Input, OnInit } from '@angular/core';
import { UploadMediaService } from '../../../../common/services/upload.service';
import { ThemeService } from '../../../../common/services/theme.service';
import { EventAreaGroup, EventSegment, Inventory, InventoryVariantGroup, ThemeAreaSegment } from '../../../../common/models';
import { Theme } from '../../../../common/models';
import { AccordionTab } from 'primeng/accordion';
import { EventSegmentService } from '../../../../common/services/event.segment.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-event-inventory',
  templateUrl: './event-inventory.component.html',
  styleUrl: './event-inventory.component.scss',
})
export class EventInventoryComponent implements OnInit {
  allInventories: Inventory[] = [];
  draggedProduct: Inventory | InventoryVariantGroup | undefined | null | any;
  isVariantProduct = false;
  searchTerm: string = '';
  page = 1;
  currentTheme: Theme = {
    name: '',
    organizationId: '',
    segments: [],
  };
  themePage = 1;
  displayThemeDialog = false;
  allthemes: Theme[] = [];

  @Input() allSegments: EventSegment[] = [];
  @Input() currentEventId: string = '';
  currentActiveSegment: null | EventSegment = null;

  constructor(
    private _themeService: ThemeService,
    private _eventInventoryService: EventSegmentService,
    private _uploadMediaService: UploadMediaService,
    private _messageService: MessageService
  ) {}

  ngOnInit() {}

  getAllThemes() {
    this._themeService.getAllTheme({ page: this.themePage, limit: 20 }).subscribe(res => {
      this.allthemes = [...this.allthemes, ...res.themes];
    });
  }

  getInventoryDetail(id: string) {
    this._themeService.getTheme(id).subscribe(res => {
      this.allSegments = res.theme.segments.map(segment => {
        let ns = { ...segment, image: segment.image || '' };
        delete ns.id;
        delete ns.createdAt;
        delete ns.updatedAt;
        return {
          ...ns,
          areaGroups: ns.areaGroups.map(group => {
            let ng = { ...group };
            delete ng.createdAt;
            delete ng.updatedAt;
            return {
              name: ng.name,
              roundOffAmount: ng.areaInventories.reduce((acc, inventory) => {
                return acc + inventory.rate * (inventory.unit ?? 1);
              }, 0),
              images: ng.images || [],
              notes: '',
              createdAt: new Date(),
              eventInventories: ng.areaInventories.map(inventory => {
                let ni: any = { ...inventory };
                delete ni.id;
                delete ni.areaGroupId;
                delete ni.createdAt;
                delete ni.updatedAt;
                return {
                  ...ni,
                };
              }),
            };
          }),
        };
      });
      this.displayThemeDialog = false;
      this._eventInventoryService.updateEventSegments(this.currentEventId, { eventSegments: this.allSegments }).subscribe({
        next: response => {
          if (response.event?.eventSegments) {
            this.allSegments = JSON.parse(JSON.stringify(response.event?.eventSegments));
          }
          this._messageService.add({ severity: 'success', detail: 'Event updated' });
        },
        error: (error: any) => {
          console.error('Error saving inventory:', error);
        },
      });
    });
  }

  handleClickOfTabs(tab: AccordionTab, hideIcon: boolean) {
    if (hideIcon) {
      tab.toggle();
    }
  }

  scrolledTheme() {
    this.themePage++;
    this.getAllThemes();
  }
  openThemeDialog() {
    this.allthemes = [];
    this.getAllThemes();
    this.displayThemeDialog = true;
  }

  selectTheme(theme: Theme) {
    this.currentTheme = theme;
  }
  applyCurrentTheme() {
    if (this.currentTheme.id) {
      this.getInventoryDetail(this.currentTheme.id);
    }
  }
  saveInventory() {
    this.saveSegments();
  }

  onFileSelected(area: EventAreaGroup, event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImage(area, file);
    }
  }

  uploadImage(area: EventAreaGroup, file: File) {
    this._uploadMediaService.uploadFile(file, 'Event').subscribe(
      response => {
        area.images.push(response.url);
        this._messageService.add({ severity: 'success', detail: 'Event updated ' });
      },
      err => {
        this._messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
      }
    );
  }
  deleteImage(areaGroup: EventAreaGroup, index: number) {
    areaGroup.images.splice(index, 1);
  }

  onGroupNameBlur(areaGroup: EventAreaGroup) {
    if (!areaGroup.name) {
      areaGroup.name = 'Default Group';
    }
  }

  updateTotal(areaGroup: EventAreaGroup) {
    areaGroup.roundOffAmount = areaGroup.eventInventories.reduce((acc, inventory) => {
      return acc + inventory.rate * (inventory.unit ?? 1);
    }, 0);
  }

  removeSegment(segmentId: string) {
    this._eventInventoryService.deleteEventSegment(segmentId).subscribe({
      next: response => {
        this.allSegments = this.allSegments.filter(s => s.id !== segmentId);
        if (this.currentActiveSegment?.id === segmentId) {
          this.currentActiveSegment = null;
        }
        this._messageService.add({ severity: 'success', detail: 'Segment deleted' });
      },
      error: (error: any) => {
        console.error('Error deleting segment:', error);
      },
    });
  }

  saveSegments() {
    this._eventInventoryService.updateEventSegments(this.currentEventId, { eventSegments: this.allSegments }).subscribe({
      next: response => {
        if (response.event?.eventSegments) {
          this.allSegments = JSON.parse(JSON.stringify(response.event?.eventSegments));
        }
        this._messageService.add({ severity: 'success', detail: 'Event updated' });
      },
      error: (error: any) => {
        console.error('Error saving inventory:', error);
      },
    });
  }
  createNewSegment(segment: EventSegment | ThemeAreaSegment) {
    if (segment as EventSegment) {
      this.allSegments.push(segment as EventSegment);
      this.saveSegments();
    }
  }
  editSegment(segment: EventSegment | ThemeAreaSegment | null) {
    this.currentActiveSegment = segment as EventSegment;
    this.setAreaIndex();
  }

  updateSegment(segment: EventSegment | ThemeAreaSegment | null) {
    if (segment?.id)
      this._eventInventoryService
        .updateEventSegment(this.currentEventId, segment?.id, { eventSegment: segment as EventSegment })
        .subscribe({
          next: response => {
            if (response.eventSegment) {
              this.allSegments = this.allSegments.map(s => {
                if (s.id === segment?.id) {
                  s = JSON.parse(JSON.stringify(response.eventSegment));
                  this.currentActiveSegment = JSON.parse(JSON.stringify(response.eventSegment));
                  this.setAreaIndex();
                }
                return s;
              });
            }
            this._messageService.add({ severity: 'success', detail: 'Segment updated' });
          },
          error: (error: any) => {
            console.error('Error updating segment:', error);
          },
        });
  }
  setAreaIndex() {
    this.currentActiveSegment?.areaGroups.sort((a, b) => {
      const aIndex = a.index !== undefined ? a.index : 100;
      const bIndex = b.index !== undefined ? b.index : 100;
      return aIndex - bIndex;
    });
  }
}
