import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventArtistComponent } from './event-artist.component';

describe('EventArtistComponent', () => {
  let component: EventArtistComponent;
  let fixture: ComponentFixture<EventArtistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EventArtistComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EventArtistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
