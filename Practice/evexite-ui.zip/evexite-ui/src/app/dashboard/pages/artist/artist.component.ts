import { v4 as uuidv4 } from 'uuid';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { from } from 'rxjs';
import { ArtistService } from '../../../common/services/artist.service';
import { Artist, ArtistType } from '../../../common/models';
import { LoaderService } from '../../../common/services/loader.service';
import { AddArtistComponent } from './add-artist.component';

@Component({
  selector: 'app-artist',
  templateUrl: './artist.component.html',
  styleUrls: ['./artist.component.scss'],
})
export class ArtistComponent implements OnInit {
  displayDialog: boolean = false;
  displayUpdateDialog = false;
  artistForm: FormGroup;
  artists: Artist[] = [];
  page = 1;
  limit = 20;
  totalRecords = 0;
  artistTypes = [
    { key: 'ANCHOR', value: 'Anchor' },
    { key: 'FILLER', value: 'Filler' },
    { key: 'SINGER', value: 'Singer' },
    { key: 'DANCER', value: 'Dancer' },
    { key: 'DJ', value: 'DJ' },
    { key: 'COMEDIAN', value: 'Comedian' },
    { key: 'MAGICIAN', value: 'Magician' },
    { key: 'OTHER', value: 'Other' },
  ];
  @ViewChild(AddArtistComponent) AddArtistComponent!: AddArtistComponent;

  constructor(
    private formBuilder: FormBuilder,
    private readonly artistService: ArtistService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private _loaderService: LoaderService
  ) {
    this.artistForm = this.formBuilder.group({
      id: '',
      name: ['', Validators.required],
      primaryContact: [null, [Validators.required, Validators.maxLength(12), Validators.minLength(10)]],
      secondaryContact: null,
      type: ['', Validators.required],
      location: '',
      notes: '',
      organizationId: '',
      image: '',
    });
  }

  ngOnInit() {
    this.fetchArtists();
  }

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }

  searchArtists(searchTerm: string) {
    if (searchTerm.length > 0) {
      this._loaderService.showLoader();
      this.artists = [];
      this.page = 1;
      this.artistService.getAllArtists({ page: 1, limit: this.limit, search: searchTerm }).subscribe({
        next: artists => {
          this.artists = artists.artists;
          this._loaderService.hideLoader();
        },
        error: error => {
          this._loaderService.hideLoader();
          console.error('Error searching artists:', error);
        },
      });
    } else {
      this.page = 1;
      this.artists = [];
      this.fetchArtists();
    }
  }

  fetchArtists(isFresh?: boolean) {
    if (isFresh) {
      this.page = 1;
      this.artists = [];
    }
    this._loaderService.showLoader();
    this.artistService
      .getAllArtists({
        limit: this.limit,
        page: this.page,
      })
      .subscribe(
        data => {
          this.artists = [...this.artists, ...data.artists];
          this.page = data.page;
          this.limit = data.limit;
          this.totalRecords = data.total;
          this._loaderService.hideLoader();
        },
        error => {
          this._loaderService.hideLoader();
          console.error('Error fetching artists:', error);
        }
      );
  }

  openUpdateDialog(artist: Artist) {
    this.artistForm.patchValue(artist);
    this.displayUpdateDialog = true;
  }

  closeUpdateDialog() {
    this.displayUpdateDialog = false;
    this.artistForm.reset({
      id: '',
      name: '',
      primaryContact: null,
      secondaryContact: null,
      type: '',
      location: '',
      notes: '',
      organizationId: '',
      image: '',
    });
  }

  updateArtist() {
    if (this.artistForm.valid) {
      const organizationId = this.fetchOrganizationId();
      const artistData = {
        ...this.artistForm.value,
        organizationId,
        primaryContact: this.artistForm.value.primaryContact.toString(),
      };

      this.artistService.updateArtist(artistData).subscribe({
        next: response => {
          this.artistForm.reset();
          this.displayUpdateDialog = false;
          this.artists = this.artists.map(artist => {
            if (artist.id === artistData.id) {
              return artistData;
            }
            return artist;
          });
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Artist updated successfully',
          });
        },
        error: error => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error updating artist:',
            detail: error.error.message,
          });
          console.log('ERROR', error);
        },
      });
    }
  }

  confirmDelete(artist: Artist) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${artist.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (artist.id) {
          this.deleteArtist(artist.id);
        }
      },
    });
  }

  deleteArtist(artistId: string) {
    this.artistService.deleteArtist(artistId).subscribe({
      next: response => {
        this.artists = this.artists.filter(artist => artist.id !== artistId);
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Artist deleted successfully',
        });
      },
      error: error => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error deleting artist:',
          detail: error.error.message,
        });
        console.error('Error deleting artist:', error);
      },
    });
  }

  openAddArtist() {
    this.AddArtistComponent.resetForm();
    this.AddArtistComponent.visible = true;
  }
  nextPage(event: any) {
    this.page++;
    this.fetchArtists();
    //todo: need to test how the pagination will work
  }
  onImageUploadForArtist(imageUrl: string) {
    this.artistForm.patchValue({ image: imageUrl });
  }
}
