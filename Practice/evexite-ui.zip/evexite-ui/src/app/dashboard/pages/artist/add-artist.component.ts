import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { v4 as uuidv4 } from 'uuid';
import { MessageService } from 'primeng/api';
import { ArtistService } from '../../../common/services/artist.service';
import { DialogModule } from 'primeng/dialog';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { ImageUploaderComponent } from '../../components/image-uploader/image-uploader.component';
import { InputTextareaModule } from 'primeng/inputtextarea';

@Component({
  selector: 'app-add-artist',
  standalone: true,
  imports: [
    DialogModule,
    InputNumberModule,
    InputTextModule,
    ReactiveFormsModule,
    DropdownModule,
    ButtonModule,
    ImageUploaderComponent,
    InputTextareaModule,
  ],
  template: `
    <p-dialog
      header="Add Artist"
      [(visible)]="visible"
      [modal]="true"
      [style]="{ width: '50vw' }"
      [baseZIndex]="10000"
      [draggable]="false"
      [resizable]="false"
      [closable]="true">
      <form [formGroup]="artistForm" (ngSubmit)="createArtist()" class="mt-3 mb-3">
        <div class="flex gap-3">
          <div>
            <label class="block text-900 font-medium mb-2">Picture</label>
            <app-image-uploader
              [Type]="'Artist'"
              [imageUrl]="artistForm.controls['image'].value"
              (imageUrlChanged)="onImageUploadForArtist($event)"></app-image-uploader>
          </div>
          <div class="w-full">
            <label for="name" class="block text-900 font-medium mb-2">Name</label>
            <input id="name" type="text" placeholder="Enter artist's full name" pInputText class="w-full mb-3" formControlName="name" />
            <div class="flex align-items-center gap-3 mb-3">
              <div class="w-full">
                <label for="primaryContact" class="block text-900 font-medium mb-2">Primary Contact</label>
                <p-inputNumber
                  class="w-full"
                  styleClass="w-full"
                  [useGrouping]="false"
                  formControlName="primaryContact"
                  [maxlength]="12"
                  placeholder="Enter contact number">
                </p-inputNumber>
              </div>
              <div class="w-full">
                <label for="secondaryContact" class="block text-900 font-medium mb-2">Secondary Contact</label>

                <p-inputNumber
                  class="w-full"
                  styleClass="w-full"
                  [useGrouping]="false"
                  formControlName="secondaryContact"
                  [maxlength]="12"
                  placeholder="Enter contact number">
                </p-inputNumber>
              </div>
            </div>
            <div class="flex align-items-center gap-3">
              <div class="w-full">
                <label for="type" class="block text-900 font-medium mb-2">Artist Type</label>
                <p-dropdown
                  [options]="artistTypes"
                  placeholder="Select Type of Artist"
                  appendTo="body"
                  optionLabel="value"
                  optionValue="key"
                  formControlName="type"
                  [styleClass]="'w-full '"></p-dropdown>
              </div>
              <div class="w-full">
                <label for="location" class="block text-900 font-medium mb-2">Location</label>
                <input
                  id="location"
                  type="text"
                  placeholder="Enter location (optional)"
                  pInputText
                  class="w-full"
                  formControlName="location" />
              </div>
            </div>
          </div>
        </div>

        <label for="notes" class="block text-900 font-medium mb-2">Notes</label>
        <textarea id="notes" placeholder="Enter notes (optional)" pInputTextarea class="w-full mb-3" formControlName="notes"></textarea>
        <div class="w-full flex align-items-center justify-content-end gap-2">
          <p-button label="Cancel" [raised]="true" severity="secondary" (onClick)="visible = false" class="mr-2"></p-button>
          <p-button label="Add" [raised]="true" type="submit" [disabled]="!artistForm.valid"></p-button>
        </div>
      </form>
    </p-dialog>
  `,
  styles: [``],
})
export class AddArtistComponent {
  visible = false;
  artistTypes = [
    { key: 'ANCHOR', value: 'Anchor' },
    { key: 'FILLER', value: 'Filler' },
    { key: 'SINGER', value: 'Singer' },
    { key: 'DANCER', value: 'Dancer' },
    { key: 'DJ', value: 'DJ' },
    { key: 'COMEDIAN', value: 'Comedian' },
    { key: 'MAGICIAN', value: 'Magician' },
    { key: 'OTHER', value: 'Other' },
  ];
  artistForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    primaryContact: new FormControl('', [Validators.required, Validators.maxLength(12), Validators.minLength(10)]),
    secondaryContact: new FormControl(null),
    type: new FormControl('', Validators.required),
    location: new FormControl(''),
    notes: new FormControl(''),
    organizationId: new FormControl(''),
    image: new FormControl(''),
  });
  @Output() clientAdded: EventEmitter<boolean> = new EventEmitter();
  constructor(
    private artistService: ArtistService,
    private messageService: MessageService
  ) {}

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }
  createArtist() {
    if (this.artistForm.valid) {
      const organizationId = this.fetchOrganizationId();
      const artistData: any = {
        ...this.artistForm.value,
        primaryContact: this.artistForm.value.primaryContact?.toString(),
        id: uuidv4(),
        organizationId,
      };

      // Remove keys with empty string values
      Object.keys(artistData).forEach(key => {
        if (artistData[key] === '') {
          delete artistData[key];
        }
      });

      this.artistService.createArtist(artistData).subscribe({
        next: response => {
          this.artistForm.reset();
          this.visible = false;
          this.clientAdded.emit(true); // Fetch the updated list of clients
        },
        error: error => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error creating artist:',
            detail: error.error.message,
          });
          console.log('ERROR', error);
        },
      });
    }
  }

  resetForm() {
    this.artistForm.reset();
  }

  onImageUploadForArtist(imageUrl: string) {
    this.artistForm.patchValue({ image: imageUrl });
  }
}
