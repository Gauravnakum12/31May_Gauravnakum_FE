import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ThemeService } from '../../../../common/services/theme.service';
import { Theme } from '../../../../common/models';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { LoaderService } from '../../../../common/services/loader.service';

@Component({
  selector: 'app-theme-list',
  templateUrl: './theme-list.component.html',
  styleUrl: './theme-list.component.scss',
})
export class ThemeListComponent implements OnInit, OnChanges {
  allTheme: Theme[] = [];
  page = 1;
  @Input() searchTerm: string = '';
  constructor(
    private _themeService: ThemeService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private _router: Router,
    private _loaderService: LoaderService
  ) {}

  ngOnInit() {}

  getAllThemes() {
    this._loaderService.showLoader();
    this._themeService.getAllTheme({ page: this.page, limit: 20, search: this.searchTerm }).subscribe(
      res => {
        this.allTheme = [...this.allTheme, ...res.themes];
        this._loaderService.hideLoader();
      },
      err => {
        this._loaderService.hideLoader();
      }
    );
  }
  openEditTheme(theme: Theme) {
    if (theme.id) {
      this._router.navigate(['/app/theme', theme.id]);
    }
  }

  confirmDelete(stock: Theme) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${stock.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteTheme(stock);
      },
    });
  }

  deleteTheme(stock: Theme) {
    if (stock.id)
      this._themeService.deleteTheme(stock.id).subscribe(message => {
        this.allTheme = this.allTheme.filter(theme => theme.id !== stock.id);
        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Theme Deleted' });
      });
  }
  scrolled(event: any) {
    this.page++;
    this.getAllThemes();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['searchTerm'].currentValue !== changes['searchTerm'].previousValue) {
      this.allTheme = [];
      this.getAllThemes();
    }
  }
}
