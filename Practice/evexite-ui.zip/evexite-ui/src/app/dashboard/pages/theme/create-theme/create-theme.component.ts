import { Component, ElementRef, ViewChild } from '@angular/core';
import { AccordionTab } from 'primeng/accordion';
import { InventoryService } from '../../../../common/services/inventory.service';
import { EventSegment, Inventory, InventoryVariantGroup, ThemeAreaSegment } from '../../../../common/models';
import { ThemeAreaGroup, Theme, ThemeAreaInventory } from '../../../../common/models';
import { v4 as uuidv4 } from 'uuid';
import { UploadMediaService } from '../../../../common/services/upload.service';
import { ThemeService } from '../../../../common/services/theme.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ActivatedRoute, Router } from '@angular/router';
import { OrganizationService } from '../../../../common/services/organization.service';
import { LoaderService } from '../../../../common/services/loader.service';

@Component({
  selector: 'app-create-theme',
  templateUrl: './create-theme.component.html',
  styleUrl: './create-theme.component.scss',
})
export class CreateThemeComponent {
  @ViewChild('newAreaInput') newAreaInput!: ElementRef;

  currentTheme: Theme = {
    name: '',
    organizationId: '',
    segments: [],
  };
  displayNameDialog = false;
  currentActiveSegment: null | ThemeAreaSegment = null;
  isImageUploaded$;
  isLoading = false;

  constructor(
    private _uploadMediaService: UploadMediaService,
    private _themeService: ThemeService,
    private messageService: MessageService,
    private _activateRoute: ActivatedRoute,
    private _router: Router,
    private _organizationService: OrganizationService,
    private _loaderService: LoaderService
  ) {
    this.isImageUploaded$ = this._uploadMediaService.loading$;
    this._themeService.isLoading$.subscribe(res => {
      this.isLoading = res;
    });
  }

  ngOnInit() {
    if (this._organizationService.CurrentOrganization) {
      this.currentTheme.organizationId = this._organizationService.CurrentOrganization;
    }
    if (this._activateRoute.snapshot.params['id'] === 'create') {
      this.displayNameDialog = true;
    } else {
      this.getInventoryDetail(this._activateRoute.snapshot.params['id']);
    }
  }

  getInventoryDetail(id: string) {
    this._loaderService.showLoader();
    this._themeService.getTheme(id).subscribe(
      res => {
        this.currentTheme = res.theme;
        this._loaderService.hideLoader();
      },
      err => {
        this._loaderService.hideLoader();
      }
    );
  }

  handleClickOfTabs(tab: AccordionTab, hideIcon: boolean) {
    if (hideIcon) {
      tab.toggle();
    }
  }

  saveTheme() {
    let currentTheme = { ...this.currentTheme };
    if (!this.currentTheme.id) {
      this._themeService.createTheme(currentTheme).subscribe(
        res => {
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Theme created' });
          this.currentTheme.id = res.theme.id;
          this.currentTheme = { ...res.theme };
        },
        err => {
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while creating theme' });
        }
      );
    } else {
      this._themeService.updateTheme(currentTheme).subscribe(
        res => {
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Theme updated' });
          this.currentTheme = { ...res.theme };
          if (this.currentActiveSegment) {
            this.currentActiveSegment = this.currentTheme.segments.filter(segment => segment.id === this.currentActiveSegment?.id)[0];
            this.setAreaIndex();
          }
        },
        err => {
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while updating theme' });
        }
      );
    }
  }

  navigateToThemes() {
    this.displayNameDialog = false;
    if (!this.currentTheme?.id) {
      this._router.navigate(['app', 'theme']);
    }
  }

  createNewSegment(segment: ThemeAreaSegment | EventSegment) {
    if (segment) {
      this.currentTheme.segments.push(segment as ThemeAreaSegment);
      this.saveTheme();
    }
  }

  editSegment(themeSegment: EventSegment | ThemeAreaSegment | null) {
    if (themeSegment) {
      this.currentActiveSegment = themeSegment as ThemeAreaSegment;
      this.setAreaIndex();
    } else {
      this.currentActiveSegment = null;
    }
  }

  removeSegment(segmentId: string) {
    this._themeService.deleteThemeSegment(segmentId).subscribe({
      next: response => {
        this.currentTheme.segments = this.currentTheme.segments.filter(s => s.id !== segmentId);
        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Segment Removed' });
      },
      error: error => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while removing segment' });
      },
    });
  }

  currentSegmentUpdated(segment: ThemeAreaSegment | EventSegment | null) {
    if (segment) {
      this.currentTheme.segments.forEach(s => {
        if (s.id === segment.id) {
          s = { ...(segment as ThemeAreaSegment) };
          this.setAreaIndex();
        }
      });
      this.saveTheme();
    }
  }
  setAreaIndex() {
    this.currentActiveSegment?.areaGroups.sort((a, b) => {
      const aIndex = a.index !== undefined ? a.index : 100;
      const bIndex = b.index !== undefined ? b.index :100;
      return aIndex - bIndex;
    });
  }
}
