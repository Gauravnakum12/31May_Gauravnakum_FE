import { v4 as uuidv4 } from 'uuid';
import { from } from 'rxjs';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClientService } from '../../../common/services/client.service';
import { Client, ClientResponse, CommonPaginationResponse, GetAllClientsResponse } from '../../../common/models';
import { TableLazyLoadEvent } from 'primeng/table';
import { LoaderService } from '../../../common/services/loader.service';
import { AddClientComponent } from './add-client.component';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss'],
})
export class ClientComponent implements OnInit {
  displayDialog: boolean = false;
  displayUpdateDialog = false;
  clientForm: FormGroup;
  clients: Client[] = [];
  page = 1;
  pagination!: CommonPaginationResponse;
  @ViewChild(AddClientComponent) addClientComponent!: AddClientComponent;

  constructor(
    private formBuilder: FormBuilder,
    private readonly clientService: ClientService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private _loaderService: LoaderService
  ) {
    this.clientForm = this.formBuilder.group({
      id: '',
      name: ['', Validators.required],
      primaryContact: [null, [Validators.required, Validators.maxLength(12), Validators.minLength(10)]],
      email: '',
      secondaryContact: null,
      location: '',
      notes: '',
      organizationId: '',
    });
  }

  ngOnInit() {
    this.fetchClients();
  }

  fetchOrganizationId() {
    const organizationId = localStorage.getItem('organizationId');
    if (!organizationId) {
      throw new Error('Organization ID not found');
    }
    return organizationId;
  }

  searchClients(searchTerm: string) {
    this.page = 1;
    this.fetchClients(searchTerm.trim());
  }

  fetchClients(search?: string, isFresh?: boolean) {
    if (isFresh) {
      this.page = 1;
    }
    this._loaderService.showLoader();
    this.clientService.getAllClients({ page: this.page, search: search }).subscribe({
      next: response => {
        this.clients = response.clients;
        this.pagination = {
          total: response.total,
          page: response.page,
          limit: response.limit,
          totalPages: response.totalPages,
          message: response.message,
        };
        this._loaderService.hideLoader();
      },
      error: error => {
        this._loaderService.hideLoader();
        console.error('Error fetching clients:', error);
      },
    });
  }

  openUpdateDialog(client: Client) {
    this.clientForm.patchValue(client);
    this.displayUpdateDialog = true;
  }

  closeUpdateDialog() {
    this.displayUpdateDialog = false;
    this.clientForm.reset({
      id: '',
      name: '',
      primaryContact: null,
      email: '',
      secondaryContact: null,
      location: '',
      notes: '',
      organizationId: '',
    });
  }

  updateClient() {
    if (this.clientForm.valid) {
      // Call your service here to update the client
      const organizationId = this.fetchOrganizationId();

      const clientData: Client = {
        ...this.clientForm.value,
        primaryContact: this.clientForm.value.primaryContact.toString(),
        organizationId,
      };

      from(this.clientService.updateClient(clientData)).subscribe({
        next: (response: ClientResponse) => {
          this.clientForm.reset();
          this.displayUpdateDialog = false;
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Client updated successfully' });
          this.fetchClients(); // Fetch the updated list of clients
        },
        error: error => {
          this.messageService.add({ severity: 'error', detail: 'Error while creating client: ' + error.error.message });

          console.log('ERROR', error);
        },
      });
    }
  }

  confirmDelete(client: Client) {
    this.confirmationService.confirm({
      message: `Are you sure you want to delete ${client.name}?`,
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        if (client.id) this.deleteClient(client.id);
      },
    });
  }

  deleteClient(clientId: string) {
    // Call your service here to delete the client
    this.clientService.deleteClient(clientId).subscribe({
      next: (response: ClientResponse) => {
        this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Client deleted successfully' });
        this.fetchClients(); // Fetch the updated list of clients
      },
      error: error => {
        this.messageService.add({ severity: 'error', detail: 'Error while creating client: ' + error.error.message });
        console.log('ERROR', error);
      },
    });
  }
  pageChange(event: TableLazyLoadEvent) {
    if (event.first === 0) {
      this.page = 1;
      this.fetchClients();
    } else {
      if (event.first && event.rows) {
        this.page = event.first / event.rows + 1;
        this.fetchClients();
      }
    }
  }
  openAddDialog() {
    this.addClientComponent.resetForm();
    this.addClientComponent.visible = true;
  }
}
