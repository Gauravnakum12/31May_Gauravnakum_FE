import {  Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DndDirective } from '../../../common/Directive/drang.drop.directive';
import { ActionIconsComponent } from '../../../common/components/action-icons/action-icons.component';
@Component({
  selector: 'app-upload-event-img',
  imports: [CommonModule, ButtonModule, ProgressSpinnerModule, DndDirective, ActionIconsComponent],
  standalone: true,
  templateUrl: './upload-event-img.component.html',
  styleUrl: './upload-event-img.component.scss',
})
export class UploadEventImgComponent {
  selectedFile = '';
  @Input() Type: 'Inventory' | 'Artist' | 'Vendor' = 'Inventory';
  @Input() imageUrl !: string | null ;
  @Input() title: string | null = '';
  @Input() instruction: string | null = '';
  deleteImg(){
    alert('img deleted')
  }
  // @Output() EditImageUrl = new EventEmitter<string>();
  // @Output() DeleteImageUrl =  new EventEmitter<string>();
  

  showProgress = false;
  constructor() {
  }

}
