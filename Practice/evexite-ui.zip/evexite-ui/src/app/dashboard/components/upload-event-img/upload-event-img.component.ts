import { UploadMediaService } from './../../../common/services/upload.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DndDirective } from '../../../common/Directive/drang.drop.directive';
import { ActionIconsComponent } from '../../../common/components/action-icons/action-icons.component';
@Component({
  selector: 'app-upload-event-img',
  imports: [CommonModule, ButtonModule, ProgressSpinnerModule, DndDirective, ActionIconsComponent],
  standalone: true,
  templateUrl: './upload-event-img.component.html',
  styleUrl: './upload-event-img.component.scss',
})
export class UploadEventImgComponent {
  selectedFile = '';
  @Input() Type: 'Inventory' | 'Artist' | 'Vendor' = 'Inventory';
  @Input() imageUrl: string | null = '';
  @Input() title: string | null = '';
  @Input() instruction: string | null = '';
  @Output() imageUrlChanged = new EventEmitter<string>();
  @Output() sidebarToggle = new EventEmitter<boolean>();
  @Output() selectedFileData: string | null = '';
  showProgress = false;

  constructor(private uploadMediaService: UploadMediaService) {
    this.selectedFile = this.imageUrl ?? '';
  }

  onClickSidebarOpen() {
    this.sidebarToggle.emit(true);
  }

  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = e => (this.selectedFile = reader.result as string);

      reader.readAsDataURL(file);
      this.showProgress = true;
      this.uploadImage(file);
    }
  }

  onFileDropped(event: FileList) {
    const file = event[0];
    this.showProgress = true;
    this.uploadImage(file);
  }
  removeFile() {
    this.selectedFile = '';
    this.imageUrl = '';
    this.imageUrlChanged.emit(this.imageUrl);
  }

  uploadImage(file: File) {
    this.uploadMediaService.uploadFile(file, this.Type).subscribe(
      data => {
        this.showProgress = false;
        this.imageUrl = data.url;
        this.imageUrlChanged.emit(this.imageUrl);
      },
      error => {
        this.showProgress = false;
        this.selectedFile = '';
        console.error('Error uploading file:', error);
      }
    );
  }
}
