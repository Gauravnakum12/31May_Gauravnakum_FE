import { UploadMediaService } from './../../../common/services/upload.service';
import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DndDirective } from '../../../common/Directive/drang.drop.directive';
@Component({
  selector: 'app-image-uploader',
  standalone: true,
  imports: [CommonModule, ButtonModule, ProgressSpinnerModule, DndDirective],
  template: `
    <div
      class="border-solid border-1	border-round border-400 w-full h-full flex align-items-center justify-content-center relative "
      appDnd
      (fileDropped)="onFileDropped($event)">
      <div class="progress-overlay flex align-items-center justify-content-center" *ngIf="showProgress">
        <p-progressSpinner styleClass="w-4rem h-4rem" strokeWidth="3" animationDuration="0.5s"></p-progressSpinner>
      </div>

      <div
        class="image-action-overlay flex align-items-center justify-content-center gap-3"
        *ngIf="(selectedFile || imageUrl) && !showProgress">
        <p-button type="button" class="btn" icon="pi pi-pencil" (onClick)="file.click()"></p-button>
        <p-button type="button" class="btn" icon="pi pi-trash" severity="danger" (onClick)="removeFile()"></p-button>
      </div>
      <img [src]="imageUrl || selectedFile" *ngIf="selectedFile || imageUrl" class="image-preview" />
      <div
        class="camera-container flex align-items-center justify-content-center"
        *ngIf="!(selectedFile || imageUrl)"
        (click)="file.click()">
        <i class="pi pi-camera text-primary" style="font-size: 2rem"></i>
      </div>
      <input type="file" accept="image/*" (change)="onFileSelected($event)" class="hidden" #file />
    </div>
  `,
  styleUrl: './image-uploader.component.scss',
  changeDetection: ChangeDetectionStrategy.Default,
})
export class ImageUploaderComponent {
  selectedFile = '';
  @Input() Type: 'Inventory' | 'Artist' | 'Vendor' = 'Inventory';
  @Input() imageUrl: string | null = '';
  @Output() imageUrlChanged = new EventEmitter<string>();
  showProgress = false;

  constructor(private uploadMediaService: UploadMediaService) {
    this.selectedFile = this.imageUrl ?? '';
  }
  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = e => (this.selectedFile = reader.result as string);

      reader.readAsDataURL(file);
      this.showProgress = true;
      this.uploadImage(file);
    }
  }

  onFileDropped(event: FileList) {
    const file = event[0];
    // const reader = new FileReader();
    // reader.onload = e => (this.selectedFile = reader.result as string);

    // reader.readAsDataURL(file);
    this.showProgress = true;
    this.uploadImage(file);
  }
  removeFile() {
    this.selectedFile = '';
    this.imageUrl = '';
    this.imageUrlChanged.emit(this.imageUrl);
  }

  uploadImage(file: File) {
    this.uploadMediaService.uploadFile(file, this.Type).subscribe(
      data => {
        this.showProgress = false;
        this.imageUrl = data.url;
        this.imageUrlChanged.emit(this.imageUrl);
      },
      error => {
        this.showProgress = false;
        this.selectedFile = '';
        console.error('Error uploading file:', error);
      }
    );
  }
}
