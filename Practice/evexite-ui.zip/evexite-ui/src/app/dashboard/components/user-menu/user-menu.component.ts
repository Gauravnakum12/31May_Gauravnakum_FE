import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AuthService } from '../../../common/services/auth.service';
import { Router } from '@angular/router';
import { ChangePasswordComponent } from '../change-password/change-password.component';

@Component({
  selector: 'app-user-menu',
  standalone: false,
  template: `<p-avatar
      [label]="userInitial"
      styleClass="mr-2 cursor-pointer"
      size="large"
      shape="circle"
      (click)="menu.toggle($event)"></p-avatar>
    <p-menu #menu [model]="items" [popup]="true"></p-menu>
    <app-change-password #changePasswordComponent></app-change-password>`,
  styles: `
  :host {
  display: block;
}
`,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserMenuComponent {
  items: MenuItem[] = [
    {
      label: 'Logout',
      command: () => {
        this.logout();
      },
    },
    {
      label: 'Change Password',
      command: () => {
        this.changePassword();
      },
    },
  ];
  userInitial = '';
  @ViewChild('changePasswordComponent') changePasswordComponent: ChangePasswordComponent | undefined;
  constructor(
    private _authService: AuthService,
    private _router: Router
  ) {
    this.userInitial = _authService.CurrentUser.email?.charAt(0) || 'E';
  }
  logout() {
    this._authService.signOut();
  }

  changePassword() {
    if (this.changePasswordComponent) {
      this.changePasswordComponent.openModal();
    }
  }
}
