import { ChangeDetectorRef, Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { AuthService } from '../../../common/services/auth.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [DialogModule, ReactiveFormsModule, ButtonModule, InputTextModule, ToastModule, NgIf],
  template: `
    <p-dialog
      header="Change Password"
      [modal]="true"
      [(visible)]="visible"
      [style]="{ width: '30dvw' }"
      [baseZIndex]="10000"
      [draggable]="false"
      [resizable]="false"
      [closable]="true">
      <form [formGroup]="changePassForm" class="mt-3 mb-3">
        <label for="currentPassword" class="block text-900 font-medium mb-2">Current Password</label>
        <input
          id="currentPassword"
          type="text"
          placeholder="Enter current password"
          pInputText
          class="w-full mb-3"
          formControlName="currentPassword" />
        <label for="newPassword" class="block text-900 font-medium mb-2 ">New Password</label>
        <input id="newPassword" type="text" placeholder="Enter new password" pInputText class="w-full mb-3" formControlName="newPassword" />
        <div class="w-full flex align-items-center justify-content-end gap-2">
          <p-button
            label="Cancel"
            [raised]="true"
            [outlined]="true"
            severity="secondary"
            (onClick)="visible = false"
            class="mr-2"></p-button>
          <p-button label="Save" [raised]="true" type="submit" (onClick)="changePassword()" [disabled]="!changePassForm.valid"></p-button>
        </div>
      </form>
    </p-dialog>
    <p-toast>
      <ng-template let-message pTemplate="message">
        <div class="flex flex-column w-full toast-{{ message.severity }}">
          <div class="flex align-items-center gap-3">
            <div style="height: 24px; width: 24px">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 12 12"
                fill="none"
                *ngIf="message.severity === 'success'">
                <path
                  d="M6 0C2.69147 0 0 2.69147 0 6C0 9.30853 2.69147 12 6 12C9.30853 12 12 9.30853 12 6C12 2.69147 9.30853 0 6 0ZM9.04102 4.72852L5.79098 7.97845C5.69348 8.07595 5.56549 8.12503 5.4375 8.12503C5.30951 8.12503 5.18152 8.07595 5.08402 7.97845L3.45905 6.35348C3.26348 6.15802 3.26348 5.84198 3.45905 5.64652C3.65452 5.45095 3.97045 5.45095 4.16602 5.64652L5.4375 6.918L8.33405 4.02155C8.52952 3.82598 8.84545 3.82598 9.04102 4.02155C9.23648 4.21702 9.23648 4.53295 9.04102 4.72852Z"
                  fill="#42B073" />
              </svg>

              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 12 11"
                fill="none"
                *ngIf="message.severity === 'error'">
                <path
                  d="M11.7596 8.27276L7.55552 0.911548C6.86883 -0.304501 5.13236 -0.304501 4.44814 0.911548L0.241563 8.27276C-0.445124 9.48881 0.40953 10.9995 1.79525 10.9995H10.1911C11.5768 10.9995 12.4463 9.47383 11.7596 8.27276ZM5.99936 9.36646C5.63379 9.36646 5.32996 9.05933 5.32996 8.68977C5.32996 8.32021 5.63379 8.01307 5.99936 8.01307C6.36493 8.01307 6.66876 8.32021 6.65393 8.70725C6.67123 9.05933 6.35011 9.36646 5.99936 9.36646ZM6.60947 4.99168C6.57983 5.51605 6.54772 6.03793 6.51808 6.56231C6.50326 6.7321 6.50326 6.88692 6.50326 7.05422C6.48844 7.33139 6.27354 7.54613 5.99936 7.54613C5.72518 7.54613 5.51275 7.34637 5.49546 7.0692C5.451 6.25268 5.40407 5.45113 5.3596 4.63461C5.34478 4.41986 5.32996 4.20262 5.31267 3.98788C5.31267 3.6333 5.51028 3.34115 5.83139 3.24876C6.15251 3.17135 6.47115 3.32617 6.60947 3.6333C6.65641 3.74067 6.67123 3.84804 6.67123 3.9729C6.65641 4.31499 6.62429 4.65458 6.60947 4.99168Z"
                  fill="#F64B1D" />
              </svg>
            </div>

            <div>
              <p class="m-0 font-bold">
                {{ message.summary }}
              </p>
              <span class="text-sm font-medium">{{ message.detail }}</span>
            </div>
          </div>
        </div>
      </ng-template>
    </p-toast>
  `,
  styles: ``,
})
export class ChangePasswordComponent {
  changePassForm = new FormGroup({
    currentPassword: new FormControl('', [Validators.required]),
    newPassword: new FormControl('', [Validators.required]),
  });
  visible = false;
  constructor(
    private _authService: AuthService,
    private _messageService: MessageService,
    private _cd: ChangeDetectorRef
  ) {}
  openModal() {
    this.visible = true;
    this.changePassForm.reset();
  }

  changePassword() {
    let data = { ...this.changePassForm.value };
    if (data.currentPassword !== data.newPassword) {
      this._authService.changePassword(data).subscribe(
        res => {
          this._messageService.add({ severity: 'success', summary: 'Success', detail: 'Password changed successfully' });
          this.visible = false;
          this._cd.detectChanges();
        },
        error => {
          this._messageService.add({ severity: 'error', summary: 'Error', detail: 'Error While changing password' });
        }
      );
    } else {
      this._messageService.add({ severity: 'error', summary: 'Error', detail: 'Current password and new password should not be same' });
    }
  }
}
