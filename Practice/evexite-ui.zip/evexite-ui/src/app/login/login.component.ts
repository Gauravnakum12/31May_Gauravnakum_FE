import { Component, OnInit } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../common/services/auth.service';
import { Router } from '@angular/router';
import { LoginResponse } from '../common/models';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ButtonModule, CheckboxModule, InputTextModule, ReactiveFormsModule, ToastModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent implements OnInit {
  isPasswordVisible = false;
  constructor(
    private _loginService: AuthService,
    private _router: Router,
    private messageService: MessageService
  ) {}

  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }
  loginForm = new FormGroup({
    email: new FormControl('', [Validators.email, Validators.required]),
    password: new FormControl('', [Validators.required]),
  });

  loginUser() {
    const creds = { ...this.loginForm.value };

    if (creds.email && creds.password) {
      this._loginService.signIn(creds.email, creds.password).subscribe(
        (data: LoginResponse) => this.handleLoginSuccess(data),
        error => this.handleLoginError(error)
      );
    }
  }

  private handleLoginSuccess(data: any): void {
    this._loginService.CurrentUser = data.user;
    this._router.navigate(['app']);
  }

  private handleLoginError(error: any): void {
    this.messageService.add({ severity: 'error', summary: 'Login Failed', detail: 'Invalid email or password.' });
    console.error('Error during login:', error);
  }

  isLoginDisabled(): boolean {
    return this.loginForm.invalid;
  }

  ngOnInit() {
    let result = this._loginService.CurrentUser;
    if (result?.id) {
      this._router.navigate(['app']);
    }
  }
}
