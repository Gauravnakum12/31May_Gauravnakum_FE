import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'combineValues',
  standalone: true,
  pure: true,
})
export class CombineValuesPipe implements PipeTransform {
  transform(array: { value: string }[] | undefined): string {
    if (!array || array.length === 0) {
      return '';
    }

    // Extracting values and joining them with '/'
    return array.map(item => item.value).join(' / ');
  }
}
