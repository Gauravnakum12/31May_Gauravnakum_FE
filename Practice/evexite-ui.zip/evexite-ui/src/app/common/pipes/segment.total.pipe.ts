import { Pipe, PipeTransform } from '@angular/core';
import { EventAreaGroup, EventAreaInventory, EventSegment, ThemeAreaGroup, ThemeAreaInventory, ThemeAreaSegment } from '../models';

@Pipe({
  name: 'segmentTotalPrice',
  pure: false,
  standalone: true,
})
export class SegmentTotalPricePipe implements PipeTransform {
  transform(themeSegment: ThemeAreaSegment | EventSegment): number | string {
    let total = 0;

    for (let areaGroup of themeSegment.areaGroups) {
      let inventories: (ThemeAreaInventory | EventAreaInventory)[];

      if ('areaInventories' in areaGroup) {
        inventories = areaGroup.areaInventories;
        for (let item of inventories) {
          if (typeof item.rate !== 'number' || typeof item.unit !== 'number') {
            return ''; // return empty string for invalid input
          }
          total += item.rate * item.unit;
        }
      } else {
        total += areaGroup.roundOffAmount;
      }
    }

    return total;
  }
}
