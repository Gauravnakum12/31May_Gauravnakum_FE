import { Pipe, PipeTransform } from '@angular/core';
import { EventAreaGroup, EventSegment, ThemeAreaInventory } from '../models';

@Pipe({
  name: 'grandTotal',
  pure: false,
  standalone: true,
})
export class EventTotalPipe implements PipeTransform {
  transform(segments: EventSegment[]): number | string {
    let total = 0;
    segments.forEach(segment => {
      segment.areaGroups.forEach(areaGroup => {
        total += areaGroup.roundOffAmount;
      });
    });
    return total;
  }
}
