import { Pipe, PipeTransform } from '@angular/core';
import { ThemeAreaInventory } from '../models';

@Pipe({
  name: 'multiplyTheme',
  pure: false,
  standalone: true,
})
export class MultiplyThemePipe implements PipeTransform {
  transform(themeAreaInventory: ThemeAreaInventory): number | string {
    if (!themeAreaInventory || typeof themeAreaInventory.rate !== 'number' || typeof themeAreaInventory.unit !== 'number') {
      return ''; // return empty string for invalid input
    }
    return themeAreaInventory.rate * themeAreaInventory.unit;
  }
}
