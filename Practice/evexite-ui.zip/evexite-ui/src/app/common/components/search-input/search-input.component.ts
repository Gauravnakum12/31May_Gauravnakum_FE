import { Component, EventEmitter, Output } from '@angular/core';
import { DebounceDirective } from '../../Directive/debounce.directive';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-search-input',
  standalone: true,
  imports: [DebounceDirective, InputTextModule],
  templateUrl: './search-input.component.html',
  styleUrl: './search-input.component.scss',
})
export class SearchInputComponent {
  @Output() searchTerm: EventEmitter<string> = new EventEmitter();
}
