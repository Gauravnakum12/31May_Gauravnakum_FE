import { Component, Input } from '@angular/core';
import { EventSegment } from '../../../models';

@Component({
  selector: 'app-area-group',
  standalone: true,
  imports: [],
  templateUrl: './area-group.component.html',
  styleUrl: './area-group.component.scss'
})
export class AreaGroupComponent {
  @Input() currentActiveSegment!: null | EventSegment;
}
