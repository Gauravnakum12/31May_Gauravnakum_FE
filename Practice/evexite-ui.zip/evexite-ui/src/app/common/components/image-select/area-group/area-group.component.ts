import { Component, Input, SimpleChanges, OnChanges, Output, EventEmitter } from '@angular/core';
import { EventAreaGroup, EventSegment, EventAreaInventory } from '../../../models';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-area-group',
  standalone: true,
  imports: [NgClass],
  templateUrl: './area-group.component.html',
  styleUrls: ['./area-group.component.scss'],
})
export class AreaGroupComponent implements OnChanges {
  @Input() currentActiveSegment!: null | EventSegment;
  @Output() selectedImageChange = new EventEmitter<string>();
  currentActiveArea!: null | EventAreaGroup;
  currentActiveInventory!: null | EventAreaInventory;
  activeArea = true;
  activeInventory = false;
  selectedImage: string | undefined = '';

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes['currentActiveSegment'].previousValue != null &&
      changes['currentActiveSegment'].currentValue.id !== changes['currentActiveSegment'].previousValue.id
    ) {
      this.backToSegment();
    }
  }
  resetSelectedImage() {
    this.selectedImage = '';
  }
  resetAreaGroup() {
    this.selectedImage = undefined;
    this.backToSegment();
  }

  backToSegment() {
    this.activeArea = true;
    this.activeInventory = false;
    this.currentActiveArea = null;
    this.currentActiveInventory = null;
  }

  backToArea() {
    this.activeInventory = false;
  }

  openArea(area: EventAreaGroup) {
    this.activeArea = false;
    this.currentActiveArea = area;
  }

  openInventories(inventory: EventAreaInventory) {
    this.currentActiveInventory = inventory;
    this.activeInventory = true;
  }

  onSelectImage(image: string | undefined) {
    this.selectedImage = image;
    this.selectedImageChange.emit(this.selectedImage);
  }
}
