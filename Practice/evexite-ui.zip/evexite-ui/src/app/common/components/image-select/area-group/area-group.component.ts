
import { Component, Input } from '@angular/core';
import { EventAreaGroup, EventSegment, EventAreaInventory } from '../../../models';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-area-group',
  standalone: true,
  imports: [NgClass],
  templateUrl: './area-group.component.html',
  styleUrl: './area-group.component.scss'
})

export class AreaGroupComponent {

  @Input() currentActiveSegment!: null | EventSegment;
  @Input() resetActiveArea = false;
  currentActiveArea!: null | EventAreaGroup;
  currentActiveInventory!: null | EventAreaInventory;
  activeArea = true;
  activeInventory = false;
  selectedImage!: string | undefined;

  ngOnChanges() {
    if (this.resetActiveArea) {
      this.activeArea = true;
      this.activeInventory = false;
    }
  }

  backToSegment() {
    this.activeArea = true;
    this.activeInventory = false;
  }
  backToArea() {
    this.activeInventory = false;
  }
  openArea(area: EventAreaGroup) {
    this.activeArea = false;
    this.currentActiveArea = area;
  }
  openInventories(inventory: EventAreaInventory) {
    this.currentActiveInventory = inventory;
    this.activeInventory = true;
  }
  onSelectImage(image: string | undefined) {
    this.selectedImage = image;
    // alert(this.selectedImage)
  }
}