import { Component } from '@angular/core';

@Component({
  selector: 'app-item-group',
  standalone: true,
  imports: [],
  templateUrl: './item-group.component.html',
  styleUrl: './item-group.component.scss'
})
export class ItemGroupComponent {

}
