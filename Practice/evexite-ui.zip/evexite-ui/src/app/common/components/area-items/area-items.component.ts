import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ThemeAreaGroup, Theme, ThemeAreaInventory, ThemeAreaSegment, EventAreaGroup } from '../../models';
import { ThemeService } from '../../services/theme.service';
import { UploadMediaService } from '../../services/upload.service';
import { MessageService } from 'primeng/api';
import { DecimalPipe, NgFor, NgIf } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MultiplyThemeAreaPipe } from '../../pipes/area.total.pipe';
import { FormsModule } from '@angular/forms';
import { MultiplyThemePipe } from '../../pipes/area-item.total.pipe';
import { ActionIconsComponent } from '../action-icons/action-icons.component';
import { InputNumberModule } from 'primeng/inputnumber';
import { EventSegmentService } from '../../services/event.segment.service';
import { InputTextareaModule } from 'primeng/inputtextarea';

@Component({
  selector: 'app-area-items',
  standalone: true,
  imports: [
    NgIf,
    ButtonModule,
    InputTextModule,
    InputNumberModule,
    MultiplyThemeAreaPipe,
    DecimalPipe,
    NgFor,
    FormsModule,
    MultiplyThemePipe,
    ActionIconsComponent,
    InputTextareaModule,
  ],
  templateUrl: './area-items.component.html',
  styleUrl: './area-items.component.scss',
})
export class AreaItemsComponent {
  @Input() currentArea!: ThemeAreaGroup;
  @Input() currentEventArea!: EventAreaGroup;

  @Output() closeModal: EventEmitter<any> = new EventEmitter<any>();
  @Output() saveCurrentArea: EventEmitter<ThemeAreaGroup> = new EventEmitter<ThemeAreaGroup>();
  isItemImageUploaded = false;
  currentImageUploadIndex = -1;
  isAreaImageUploaded = false;
  constructor(
    private _themeService: ThemeService,
    private _eventSegmentService: EventSegmentService,
    private _uploadMediaService: UploadMediaService,
    private _messageService: MessageService
  ) {}

  addThemeArea() {
    this.currentArea.areaInventories.push({
      name: 'Default Item',
      size: '',
      rate: 0,
      unit: 1,
      createdAt: new Date(),
      images: [],
    });
  }
  onGroupNameBlur(areaGroup: ThemeAreaGroup) {
    if (!areaGroup.name) {
      areaGroup.name = 'Default Group';
    }
  }
  addItem() {
    if (this.currentArea && 'areaInventories' in this.currentArea) {
      this.currentArea.areaInventories.push({
        name: '',
        size: '',
        rate: 0,
        unit: 1,
        quantity: 1,
        createdAt: new Date(),
        images: [],
      });
    } else if (this.currentEventArea && 'eventInventories' in this.currentEventArea) {
      this.currentEventArea.eventInventories.push({
        name: '',
        size: '',
        rate: 0,
        unit: 1,
        quantity: 1,
        images: [],
      });
    }
  }

  updateUnit(size: string, areaInventories: ThemeAreaInventory) {
    const numbers = size.split(/['\"xX* ]+/).map(Number);
    if (!isNaN(numbers[0]) && !isNaN(numbers[1]) && numbers[1] > 0) {
      areaInventories.unit = numbers[0] * numbers[1] * (areaInventories.quantity ? areaInventories.quantity : 1);
    } else if (!isNaN(numbers[0])) {
      areaInventories.unit = numbers[0] * (areaInventories.quantity ? areaInventories.quantity : 1);
    } else {
      areaInventories.unit = 1;
    }
  }

  updateUnitFromQuantity(areaInventories: ThemeAreaInventory, event: any) {
    this.updateUnit(areaInventories.size, areaInventories);
  }

  removeInventoryFromArea(index: number, areaGroup: ThemeAreaGroup | EventAreaGroup, item: ThemeAreaInventory) {
    if ('areaInventories' in areaGroup) {
      areaGroup.areaInventories.splice(index, 1);
    }
    if ('eventInventories' in areaGroup) {
      areaGroup.eventInventories.splice(index, 1);
    }

    if (item.id) {
      if (this.currentArea) {
        this._themeService.deleteThemeAreaInventory(item.id).subscribe(
          res => {},
          err => {
            console.error('Error deleting theme area inventory:', err);
          }
        );
      } else if (this.currentEventArea) {
        this._eventSegmentService.deleteEventAreaInventory(item.id).subscribe(
          res => {},
          err => {
            console.error('Error deleting event area inventory:', err);
          }
        );
      }
    }
  }

  onFileSelected(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImage(file);
    }
  }

  uploadImage(file: File) {
    this.isAreaImageUploaded = true;
    this._uploadMediaService.uploadFile(file, 'Theme').subscribe(
      response => {
        if (this.currentArea) {
          this.currentArea.images.push(response.url);
        } else if (this.currentEventArea) {
          this.currentEventArea.images.push(response.url);
        }
        this.isAreaImageUploaded = false;
      },
      err => {
        this._messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
        this.isAreaImageUploaded = false;
      }
    );
  }

  deleteImage(index: number) {
    if (this.currentArea) {
      this.currentArea.images.splice(index, 1);
    } else if (this.currentEventArea) {
      this.currentEventArea.images.splice(index, 1);
    }
  }
  cancelArea() {
    this.closeModal.emit();
  }
  saveArea() {
    this.saveCurrentArea.emit(this.currentArea || this.currentEventArea);
  }

  onFileSelectedItem(index: number, area: ThemeAreaInventory, event: any) {
    this.isItemImageUploaded = true;
    this.currentImageUploadIndex = index;
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadImageInventory(area, file);
    }
  }

  uploadImageInventory(area: ThemeAreaInventory, file: File) {
    this._uploadMediaService.uploadFile(file, 'Theme').subscribe(
      response => {
        area.images.push(response.url);
        this.isItemImageUploaded = false;
        this.currentImageUploadIndex = -1;
      },
      err => {
        this._messageService.add({ severity: 'error', summary: 'Error', detail: 'Error while uploading image' });
        this.isItemImageUploaded = false;
        this.currentImageUploadIndex = -1;
      }
    );
  }

  deleteImageInventory(areaGroup: ThemeAreaInventory, index: number) {
    areaGroup.images.splice(index, 1);
  }

  updateRoundOffAmount() {
    let total = 0;
    for (let item of this.currentEventArea.eventInventories) {
      if (typeof item.rate === 'number' || typeof item.unit === 'number') {
        total += item.rate * item.unit;
      }
    }
    this.currentEventArea.roundOffAmount = total;
  }
}
