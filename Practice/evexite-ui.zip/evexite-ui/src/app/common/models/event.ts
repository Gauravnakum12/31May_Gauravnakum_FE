import { Artist, Client, VendorResponse } from './all';
import { Inventory, InventoryVariantGroup } from './inventory';

export enum EventStatusType {
  CONFIRMED = 'CONFIRMED',
  DRAFT = 'DRAFT',
  CANCELLED = 'CANCELLED',
}

export enum EventThirdPartyConfirmationStatusType {
  PENDING = 'PENDING',
  REQUESTED = 'REQUESTED',
  CONFIRMED = 'CONFIRMED',
  REJECTED = 'REJECTED',
  CANCELLED = 'CANCELLED',
}

export enum EventType {
  SOCIAL = 'SOCIAL',
  CORPORATE = 'CORPORATE',
  SPECIAL = 'SPECIAL',
}
export interface IEvent {
  clientId?: string;
  createdAt?: string;
  date?: Date;
  description?: string;
  id?: string;
  name?: string;
  type: EventType;
  organizationId?: string;
  status?: EventStatusType;
  totalMembers?: number;
  updatedAt?: string;
  venue?: string;
  client?: Client;
  eventArtists?: Array<EventArtist & { artist: Artist }>;
  eventVendors?: Array<EventVendor & { vendor: VendorResponse }>;
  eventSegments: EventSegment[];
}

export interface EventSegment {
  id?: string;
  name: string;
  areaGroups: EventAreaGroup[];
  image: string;
  createdAt?: Date;
}

export interface EventArtist {
  artistId?: string;
  createdAt?: string;
  eventId?: string;
  flightTicketDetails?: string;
  hotelDetails?: string;
  id?: string;
  logisticsDetails?: string;
  notes?: string;
  organizationId?: string;
  status?: EventThirdPartyConfirmationStatusType;
  updatedAt?: string;
}

export interface EventAreaGroup {
  id?: string;
  name: string;
  eventInventories: EventAreaInventory[];
  roundOffAmount: number;
  images: string[];
  notes: string;
  createdAt?: Date;
  index?: number;
}

export interface EventAreaInventory {
  id?: string;
  size: string;
  rate: number;
  unit: number;
  name: string;
  quantity?: number;
  images: string[];
}
export interface EventVendor {
  createdAt?: string;
  eventId?: string;
  id?: string;
  notes?: string;
  organizationId?: string;
  status?: EventThirdPartyConfirmationStatusType;
  updatedAt?: string;
  vendorId?: string;
}
