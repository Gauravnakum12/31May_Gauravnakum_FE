export interface Theme {
  id?: string;
  name: string;
  organizationId: string;
  segments: ThemeAreaSegment[];
  segmentCount?: number;
  inventoryCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface ThemeAreaSegment {
  id?: string;
  name: string;
  themeId?: string;
  image?: string;
  areaGroups: ThemeAreaGroup[];
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ThemeAreaGroup {
  id?: string;
  name: string;
  theme?: Theme;
  areaInventories: ThemeAreaInventory[];
  themeId?: string;
  images: string[];
  createdAt?: Date;
  updatedAt?: Date;
  index?: number;
}

export interface ThemeAreaInventory {
  id?: string;
  quantity?: number;
  size: string;
  rate: number;
  unit: number;
  name: string;
  createdAt?: Date;
  updatedAt?: Date;
  images: string[];
}
