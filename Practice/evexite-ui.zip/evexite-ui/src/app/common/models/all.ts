// Enum Types
export enum ArtistType {
  ANCHOR = 'ANCHOR',
  FILLER = 'FILLER',
  SINGER = 'SINGER',
  DANCER = 'DANCER',
  DJ = 'DJ',
  COMEDIAN = 'COMEDIAN',
  MAGICIAN = 'MAGICIAN',
  OTHER = 'OTHER',
}

export enum Role {
  OWNER = 'OWNER',
  MANAGER = 'MANAGER',
  PRODUCTION_MANAGER = 'PRODUCTION_MANAGER',
  WAREHOUSE_MANAGER = 'WAREHOUSE_MANAGER',
  ACCOUNTANT = 'ACCOUNTANT',
}

export enum Unit {
  KG = 'KG',
  METER = 'METER',
  LITRE = 'LITRE',
  FEET = 'FEET',
  QUANTITY = 'QUANTITY',
}

export enum VendorType {
  FLORIST = 'FLORIST',
  CATERER = 'CATERER',
  LIGHTING = 'LIGHTING',
  AMBIENT_LIGHTING = 'AMBIENT_LIGHTING',
  LED_SCREEN = 'LED_SCREEN',
  LED_MAPPING = 'LED_MAPPING',
  SOUND = 'SOUND',
  DJ = 'DJ',
  OTHER = 'OTHER',
  PHOTOGRAPHER = 'PHOTOGRAPHER',
}

// Table Interfaces

export interface Artist {
  createdAt?: string;
  id?: string;
  location?: string;
  name?: string;
  notes?: string;
  image?: string;
  organizationId?: string;
  primaryContact?: string;
  secondaryContact?: string;
  type?: ArtistType;
  updatedAt?: string;
}

export interface Client {
  id?: string;
  name?: string;
  email?: string;
  primaryContact?: string;
  secondaryContact?: string;
  location?: string;
  notes?: string;
  organizationId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface PaginationInfo {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface CommonPaginationResponse {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  message: string;
}

export interface GetAllClientsResponse {
  paginationInfo: PaginationInfo;
  message: string;
  clients: Client[];
}

export interface ClientResponse {
  message: string;
  client: Client;
}

export interface CommonPaginationParams {
  page?: number;
  limit?: number;
  search?: string;
}

export interface Organization {
  createdAt?: string;
  description?: string;
  id?: string;
  logo?: string;
  name?: string;
  updatedAt?: string;
}

export interface Staff {
  createdAt?: string;
  email?: string;
  id?: string;
  name?: string;
  organizationId?: string;
  password?: string;
  primaryContact?: string;
  role?: Role;
  secondaryContact?: string;
  updatedAt?: string;
}

export interface VendorResponse {
  id: string;
  name?: string;
  type?: VendorType;
  preferredLanguage?: string;
  primaryContact?: string;
  secondaryContact?: string;
  location?: string;
  notes?: string;
  organizationId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface WhatsappCloudConfig {
  accessToken?: string;
  appId?: string;
  businessAccountId?: string;
  businessId?: string;
  callbackUrl?: string;
  createdAt?: string;
  id?: string;
  number?: string;
  organizationId?: string;
  phoneNumberId?: string;
  templateSyncToken?: string;
  updatedAt?: string;
  verifyToken?: string;
}

interface Identity {
  created_at: string;
  email: string;
  id: string;
  identity_data: {
    email: string;
    email_verified: boolean;
    phone_verified: boolean;
    sub: string;
  };
  identity_id: string;
  last_sign_in_at: string;
  provider: string;
  updated_at: string;
  user_id: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  primaryContact: string;
  secondaryContact: string;
  role: string;
  verified: boolean;
  registerCode: number;
  organizationId: string;
  createdAt: string;
  updatedAt: string;
}

export interface LoginResponse {
  message: string;
  accessToken: string;
  user: User;
}

export interface CommonPaginationResponse {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  message: string;
}
