export interface Inventory {
  code?: string | null;
  createdAt?: string;
  description: string | null;
  id: string;
  image?: string | null;
  location: string | null;
  name: string;
  organizationId?: string;
  price?: number | null;
  quantity?: number | null;
  updatedAt?: string;
  inventoryVariantGroups?: Array<InventoryVariantGroup>;
  inventoryVariants?: Array<InventoryVariant>;
}

export interface InventoryVariant {
  createdAt?: string;
  id?: string;
  inventoryId?: string;
  name: string;
  organizationId?: string;
  updatedAt?: string;
  inventoryVariantValues: Array<InventoryVariantValue>;
}

export interface InventoryVariantGroup {
  code?: string | null;
  createdAt?: string;
  id?: string;
  inventoryId?: string;
  organizationId?: string;
  price: number;
  quantity: number;
  inventoryVariantValues?: Array<InventoryVariantValue>;
  updatedAt?: string;
}

export interface InventoryVariantValue {
  createdAt?: string;
  id?: string;
  inventoryvariantId?: string;
  organizationId?: string;
  updatedAt?: string;
  value: string;
}
