import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  let result = authService.CurrentUser;
  if (result.id) {
    return true;
  } else {
    authService.signOut();
  }

  // Redirect to the login page
  return false;
};
