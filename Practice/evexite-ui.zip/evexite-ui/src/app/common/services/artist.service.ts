import { Injectable } from '@angular/core';
import { Artist, CommonPaginationParams, CommonPaginationResponse } from '../models';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ArtistService {
  ARTIST_URL = environment.API_URL + '/artist';
  constructor(private http: HttpClient) {}

  getAllArtists(params: CommonPaginationParams = {}): Observable<CommonPaginationResponse & { artists: Artist[] }> {
    const { page = 1, limit = 10, search = '' } = params;
    const url = `${this.ARTIST_URL}/list?page=${page}&limit=${limit}&search=${search}`;
    return this.http.get<CommonPaginationResponse & { artists: Artist[] }>(url);
  }

  createArtist(artist: Artist): Observable<{ message: string; artists: Artist }> {
    return this.http.post<{ message: string; artists: Artist }>(this.ARTIST_URL, artist);
  }

  updateArtist(artist: Artist): Observable<{ message: string; artists: Artist }> {
    return this.http.put<{ message: string; artists: Artist }>(this.ARTIST_URL + '/' + artist.id, artist);
  }

  deleteArtist(artistId: string): Observable<{ message: string; artists: Artist }> {
    return this.http.delete<{ message: string; artists: Artist }>(this.ARTIST_URL + '/' + artistId);
  }
}
