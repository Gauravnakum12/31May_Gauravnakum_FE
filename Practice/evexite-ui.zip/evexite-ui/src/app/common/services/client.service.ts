import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Client, ClientResponse, GetAllClientsResponse, CommonPaginationParams, CommonPaginationResponse } from '../models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ClientService {
  constructor(private http: HttpClient) {}

  getAllClients(params: CommonPaginationParams = {}): Observable<CommonPaginationResponse & { clients: Client[] }> {
    const { page = 1, limit = 10, search = '' } = params;
    const url = `${environment.API_URL}/client/list?page=${page}&limit=${limit}&search=${search}`;
    return this.http.get<CommonPaginationResponse & { clients: Client[] }>(url);
  }

  searchClients(searchTerm: string): Observable<GetAllClientsResponse> {
    const url = `${environment.API_URL}/client/list?search=${searchTerm}`;
    return this.http.get<GetAllClientsResponse>(url);
  }

  createClient(clientData: Client): Observable<ClientResponse> {
    const apiUrl = `${environment.API_URL}/client`;
    return this.http.post<ClientResponse>(apiUrl, clientData);
  }

  getClientById(clientId: any) {
    return this.http.get<ClientResponse>(`${environment.API_URL}/client/${clientId}`);
  }

  updateClient(clientData: Client) {
    return this.http.put<ClientResponse>(`${environment.API_URL}/client/${clientData.id}`, clientData);
  }

  deleteClient(clientId: string) {
    return this.http.delete<ClientResponse>(`${environment.API_URL}/client/${clientId}`);
  }
}
