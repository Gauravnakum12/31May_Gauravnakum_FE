import { Injectable } from '@angular/core';
import { EventArtist, IEvent } from '../models';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EventArtistService {
  API_URL = `${environment.API_URL}/event/`;

  constructor(private http: HttpClient) {}

  createEventArtist(eventId: string, artist: EventArtist): Observable<{ message: string; event: IEvent }> {
    return this.http.post<{ message: string; event: IEvent }>(this.API_URL + eventId + '/artist', artist);
  }

  updateEventArtist(eventId: string, artist: EventArtist, eventArtistId: string): Observable<{ message: string; event: IEvent }> {
    return this.http.put<{ message: string; event: IEvent }>(this.API_URL + eventId + '/artist/' + eventArtistId, artist);
  }

  deleteEventArtist(eventArtistId: string) {
    return this.http.delete<{ message: string }>(this.API_URL + 'artist/' + eventArtistId);
  }
}
