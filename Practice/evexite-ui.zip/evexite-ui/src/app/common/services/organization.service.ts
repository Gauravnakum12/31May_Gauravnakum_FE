import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class OrganizationService {
  get CurrentOrganization(): string {
    return localStorage.getItem('organizationId') || '';
  }
  set CurrentOrganization(id: string) {
    localStorage.setItem('organizationId', id);
  }
}
