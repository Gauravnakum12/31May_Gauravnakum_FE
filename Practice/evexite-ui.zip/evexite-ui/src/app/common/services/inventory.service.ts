import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { CommonPaginationParams, CommonPaginationResponse } from '../models';
import { Inventory, InventoryVariant } from '../models/inventory';

@Injectable({
  providedIn: 'root',
})
export class InventoryService {
  API_URL = `${environment.API_URL}/inventory`;
  constructor(private http: HttpClient) {}

  getAllInventory(params: CommonPaginationParams = {}) {
    const { page = 1, limit = 10, search = '' } = params;

    return this.http.get<CommonPaginationResponse & { inventories: Inventory[] }>(this.API_URL + '/list', {
      params: {
        page: page.toString(),
        limit: limit.toString(),
        search,
      },
    });
  }

  getAllInventoryGroups(params: CommonPaginationParams = {}) {
    const { page = 1, limit = 10, search = '' } = params;

    return this.http.get<CommonPaginationResponse & { inventories: Inventory[] }>(this.API_URL + '/list/group-data', {
      params: {
        page: page.toString(),
        limit: limit.toString(),
        search,
      },
    });
  }

  createInventory(stock: any) {
    return this.http.post<{ message: string; inventory: Inventory }>(this.API_URL, stock);
  }

  getInventory(id: string) {
    return this.http.get<{ message: string; inventory: Inventory }>(this.API_URL + '/' + id);
  }

  updateInventory(stock: any) {
    return this.http.put<{ message: string; inventory: Inventory }>(this.API_URL, stock);
  }

  deleteInventory(stockId: string) {
    return this.http.delete<{ message: string; inventory: Inventory }>(this.API_URL + `/${stockId}`);
  }

  createInventoryVariant(stock: any) {
    return this.http.put<{ message: string; inventoryVariant: InventoryVariant }>(this.API_URL + '/batch-upsert/' + stock.id, stock);
  }
}
