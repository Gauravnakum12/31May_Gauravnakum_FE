import { Injectable } from '@angular/core';
import { EventAreaGroup, EventSegment, IEvent } from '../models';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { BehaviorSubject, finalize, Observable, tap } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class EventSegmentService {
  API_URL = `${environment.API_URL}/event/`;
  isLoading$ = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient) {}

  createEventAreaGroups(eventId: string, segmentId: string, area: { eventInventoryGroups: Array<EventAreaGroup> }) {
    this.isLoading$.next(true);
    return this.http
      .post<{ message: string; event: IEvent }>(this.API_URL + eventId + '/eventSegment/' + segmentId + '/eventGroup', area)
      .pipe(
        tap(() => {
          this.isLoading$.next(false);
        }),
        finalize(() => {
          this.isLoading$.next(false);
        })
      );
  }

  updateEventAreaGroup(eventId: string, area: { eventInventoryGroup: EventAreaGroup }): Observable<{ message: string; event: IEvent }> {
    this.isLoading$.next(true);
    return this.http.put<{ message: string; event: IEvent }>(this.API_URL + eventId + '/eventSegment/eventGroup', area).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  createEventSegment(eventId: string, segment: { eventSegment: EventSegment }) {
    this.isLoading$.next(true);
    return this.http.post<{ message: string; eventSegment: EventSegment }>(this.API_URL + eventId + '/eventSegment', segment).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  updateEventSegment(eventId: string, segmentId: string, segment: { eventSegment: EventSegment }) {
    this.isLoading$.next(true);
    return this.http
      .put<{ message: string; eventSegment: EventSegment }>(this.API_URL + eventId + '/eventSegment/' + segmentId, segment)
      .pipe(
        tap(() => {
          this.isLoading$.next(false);
        }),
        finalize(() => {
          this.isLoading$.next(false);
        })
      );
  }

  updateEventSegments(eventId: string, segments: { eventSegments: Array<EventSegment> }) {
    this.isLoading$.next(true);
    return this.http.put<{ message: string; event: IEvent }>(this.API_URL + eventId + '/bulk-eventSegment', segments).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteEventAreaGroup(id: string) {
    this.isLoading$.next(true);
    return this.http.delete<{ message: string }>(this.API_URL + `eventInventoryGroup/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteEventAreaInventory(id: string) {
    this.isLoading$.next(true);
    return this.http.delete<{ message: string }>(this.API_URL + `eventInventory/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteEventSegment(id: string) {
    this.isLoading$.next(true);
    return this.http.delete<{ message: string }>(this.API_URL + `eventSegment/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }
}
