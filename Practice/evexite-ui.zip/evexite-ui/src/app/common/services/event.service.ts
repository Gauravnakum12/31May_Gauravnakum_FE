import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { CommonPaginationParams, CommonPaginationResponse, IEvent, QuotationSheetData } from '../models';
import { BehaviorSubject, finalize, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EventService {
  API_URL = `${environment.API_URL}/event`;
  isLoading$ = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient) { }

  getAllEvents(params: CommonPaginationParams = {}): Observable<CommonPaginationResponse & { events: IEvent[] }> {
    this.isLoading$.next(true);
    const { page = 1, limit = 10, search = '' } = params;
    return this.http
      .get<CommonPaginationResponse & { events: IEvent[] }>(this.API_URL + '/list', {
        params: {
          page: page.toString(),
          limit: limit.toString(),
          search,
        },
      })
      .pipe(
        tap(() => {
          this.isLoading$.next(false);
        }),
        finalize(() => {
          this.isLoading$.next(false);
        })
      );
  }

  createEvent(event: IEvent): Observable<{ message: string; event: IEvent }> {
    this.isLoading$.next(true);
    return this.http.post<{ message: string; event: IEvent }>(this.API_URL, event).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  fetchEventById(eventId: string): Observable<{ message: string; event: IEvent }> {
    this.isLoading$.next(true);
    return this.http.get<{ message: string; event: IEvent }>(this.API_URL + '/' + eventId).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }


  updateEvent(event: IEvent): Observable<{ message: string; event: IEvent }> {
    this.isLoading$.next(true);
    return this.http.put<{ message: string; event: IEvent }>(this.API_URL + '/' + event.id, event).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteEvent(eventId: string): Observable<{ message: string }> {
    this.isLoading$.next(true);
    return this.http.delete<{ message: string }>(this.API_URL + '/' + eventId).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }
  downloadProductionSheet(eventId: string): Observable<{ message: string; url: string }> {
    this.isLoading$.next(true);
    return this.http.post<{ message: string; url: string }>(this.API_URL + '/' + eventId + '/production-sheet/', {}).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  updateQuotationSheet(quotationSheetData: QuotationSheetData): Observable<{ quotationSheetData: QuotationSheetData }> {
    this.isLoading$.next(true);
    return this.http.put<{ message: string; quotationSheetData: QuotationSheetData }>(this.API_URL + quotationSheetData.id + '/quotation-sheet', quotationSheetData).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  downloadQuotationSheet(eventId: string): Observable<{ message: string; url: string }> {
    this.isLoading$.next(true);
    return this.http.post<{ message: string; url: string }>(this.API_URL + '/' + eventId + '/quotation-sheet/', {}).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }
}
