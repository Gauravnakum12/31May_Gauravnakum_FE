import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { CommonPaginationParams, CommonPaginationResponse } from '../models';
import { Inventory, InventoryVariant } from '../models/inventory';
import { Theme } from '../models/theme';
import { BehaviorSubject, finalize, tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  API_URL = `${environment.API_URL}/theme`;

  isLoading$ = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient) {}

  getAllTheme(params: CommonPaginationParams = {}) {
    const { page = 1, limit = 10, search = '' } = params;

    return this.http.get<CommonPaginationResponse & { themes: Theme[] }>(this.API_URL + '/list', {
      params: {
        page: page.toString(),
        limit: limit.toString(),
        search,
      },
    });
  }

  createTheme(stock: any) {
    this.isLoading$.next(true);
    return this.http.post<{ message: string; theme: Theme }>(this.API_URL, stock).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  getTheme(id: string) {
    this.isLoading$.next(true);

    return this.http.get<{ message: string; theme: Theme }>(this.API_URL + '/' + id).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  updateTheme(stock: Theme) {
    this.isLoading$.next(true);
    return this.http.put<{ message: string; theme: Theme }>(this.API_URL + '/' + stock.id, stock).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteTheme(stockId: string) {
    this.isLoading$.next(true);

    return this.http.delete<{ message: string; theme: Theme }>(this.API_URL + `/${stockId}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteThemeAreaGroup(id: string) {
    this.isLoading$.next(true);

    return this.http.delete<{ message: string; theme: Theme }>(this.API_URL + `/themeAreaGroup/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }
  deleteThemeSegment(id: string) {
    this.isLoading$.next(true);

    return this.http.delete<{ message: string; theme: Theme }>(this.API_URL + `/themeSegment/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }

  deleteThemeAreaInventory(id: string) {
    this.isLoading$.next(true);

    return this.http.delete<{ message: string; theme: Theme }>(this.API_URL + `/themeAreaInventory/${id}`).pipe(
      tap(() => {
        this.isLoading$.next(false);
      }),
      finalize(() => {
        this.isLoading$.next(false);
      })
    );
  }
}
