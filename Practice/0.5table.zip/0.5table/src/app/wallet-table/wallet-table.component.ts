import { Component, inject  } from '@angular/core';
import { TableDataService } from './table-data.service';
import { Transaction } from './table.wallet';
import { NgClass, NgFor } from '@angular/common';
import { DecimalPipe, DatePipe } from '@angular/common';
@Component({
  selector: 'app-wallet-table',
  standalone: true,
  imports: [NgClass, NgFor, DatePipe],
  templateUrl: './wallet-table.component.html',
  styleUrl: './wallet-table.component.scss',
  providers: [DecimalPipe, DatePipe,]
})
export class WalletTableComponent {
  private WalletService = inject(TableDataService);
  transactions: Array<Transaction> = this.WalletService.transactionsSignal();
  CurrentExpandedRow: number | null = null;

  constructor(private decimalPipe: DecimalPipe, private datePipe: DatePipe) { }

  toggleRow(index: number): void {
    this.CurrentExpandedRow = (this.CurrentExpandedRow === index ? null : index);
  }

}
