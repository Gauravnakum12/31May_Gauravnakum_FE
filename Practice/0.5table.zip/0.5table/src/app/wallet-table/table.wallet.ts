export interface TransactionItem {
    TransactionType:string
      hash?: string;
      withdrawalAddress?: string;
      feesPaid?: string;
    }
    
    export interface Transaction {
      type: string;
      amount: number;
      date: Date;
      status: string;
      transactionItems: TransactionItem[];
    }
    