import { Injectable } from '@angular/core';
import { signal } from '@angular/core';
import { Transaction } from './table.wallet';
@Injectable({
  providedIn: 'root'
})
export class TableDataService {

  private staticData: Transaction[] = [
    {
      "type": "Transfer",
      "amount": 25.1212,
      "date": new Date('December 17, 1995 03:24:00'),
      "status": "Filled",
      "transactionItems": []
    },
    {
      "type": "Deposit",
      "amount": 2000000.1212,
      "date": new Date(),
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "xACcBKuZsyx7wCvUexxpeXUWcaRt",
          "withdrawalAddress": "B-509,Decora 9Square Nana Mava Road, Rajkot 360003, Gujarat, India.",
        }

      ]
    },
    {
      "type": "Deposit",
      "amount": 2000000.1212,
      "date": new Date(),
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "xACcBKuZsyx7wCvUexxpeXUWcaRt",
          "withdrawalAddress": "B-509,Decora 9Square Nana Mava Road, Rajkot 360003, Gujarat, India.",
        }

      ]
    },

    {
      "type": "Transfer",
      "amount": 7500.1212,
      "date": new Date(),
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Transfer",
      "amount": 3000.1212,
      "date": new Date(),
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": " xACcBKuZsyx7wCvUexxpeXUWcaRtxACcBKuZsyx7wCvUexxpeXUWcaRt",
          "withdrawalAddress": "Reliance Mega Mall, 150 Feet Ring Road, Rajkot - 360005 (Opposite Big Bazar, Near Nana Mauva Circle)",
        }
      ]
    },
    {
      "type": "Withdrawal",
      "amount": 50.1212,
      "date": new Date(),
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Deposit",
      "amount": 4000,
      "date": new Date(),
      "status": "Filled",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Withdrawal",
      "amount": 250000,
      "date": new Date(),
      "status": "Filled",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },
    {
      "type": "Deposit",
      "amount": 10000000,
      "date": new Date(),
      "status": "Completed",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "jkl012",
          "withdrawalAddress": "addr4",
        }
      ]
    },

    {
      "type": "Transfer",
      "amount": 300000000,
      "date": new Date(),
      "status": "Pending",
      "transactionItems": [
        {
          "TransactionType": "crowds",
          "feesPaid": "400",
          "hash": "xACcBKuZsyx7wCvUexxpeXUWcaRtxACcBKuZsyx7wCvUexxpeXUWcaRtxACcBKuZsyx7wCvUexxpeXUWcaRtxACcBKuZsyx7wCvUexxpeXUWcaRt",
          "withdrawalAddress": " Crystal Mall Rajkot, Kalavad Rd, Opposite Rani Tower, Ghanshyam Nagar - 2 East, Rajkot, Gujarat 360005",
        }
      ]
    },
  ];
  transactionsSignal = signal<Transaction[]>(this.staticData);
}
