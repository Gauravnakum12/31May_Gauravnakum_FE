import { Component } from '@angular/core';

@Component({
  selector: 'app-popup-box',
  standalone: true,
  imports: [],
  templateUrl: './popup-box.component.html',
  styleUrl: './popup-box.component.scss'
})
export class PopupBoxComponent {

}
