import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ButtonModule } from 'primeng/button';
@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule,ButtonModule ],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
  
})
export class TableComponent {

}
